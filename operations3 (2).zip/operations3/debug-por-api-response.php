<?php
/**
 * Debug POR API Response
 * Check what the API is actually returning
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
$_SESSION['user'] = [
    'id' => 'admin',
    'name' => 'System Admin',
    'email' => 'admin@example.com',
    'role' => 'admin'
];

require_once 'config/database.php';
$db = getDB();

echo "DEBUG: POR API RESPONSE\n";
echo str_repeat("=", 80) . "\n\n";

// Find a receiving without POR
$stmt = $db->query("
    SELECT r.id
    FROM receivings r
    LEFT JOIN proof_of_receiving por ON r.id = por.receiving_id
    WHERE por.id IS NULL
    LIMIT 1
");
$receiving = $stmt->fetch();

if (!$receiving) {
    echo "No receivings available without POR. Using existing receiving.\n";
    $stmt = $db->query("SELECT id FROM receivings LIMIT 1");
    $receiving = $stmt->fetch();
}

$receivingId = $receiving['id'];
echo "Testing with Receiving ID: $receivingId\n\n";

// Simulate the actual AJAX call
$url = 'http://localhost/operations2/api/por.php';
$data = [
    'action' => 'create-from-receiving',
    'receiving_id' => $receivingId
];

echo "REQUEST:\n";
echo "URL: $url\n";
echo "Method: POST\n";
echo "Data: " . json_encode($data) . "\n\n";

// Make the request
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Cookie: PHPSESSID=' . session_id()
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "RESPONSE:\n";
echo "HTTP Code: $httpCode\n";
echo "Response Length: " . strlen($response) . " bytes\n\n";

echo "RAW RESPONSE:\n";
echo str_repeat("-", 80) . "\n";
echo $response . "\n";
echo str_repeat("-", 80) . "\n\n";

// Try to parse as JSON
$json = json_decode($response, true);
if ($json === null) {
    echo "✗ FAILED TO PARSE AS JSON\n";
    echo "JSON Error: " . json_last_error_msg() . "\n\n";
    
    // Check if it's HTML
    if (strpos($response, '<') === 0 || strpos($response, '<!DOCTYPE') !== false) {
        echo "⚠ Response appears to be HTML (PHP error page)\n";
        echo "First 500 characters:\n";
        echo substr($response, 0, 500) . "\n";
    }
} else {
    echo "✓ Valid JSON Response:\n";
    print_r($json);
}

echo "\n" . str_repeat("=", 80) . "\n";
