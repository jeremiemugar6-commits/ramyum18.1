<?php
/**
 * Database Configuration Verification Script
 * Verifies that the centralized database configuration is working correctly
 */

require_once __DIR__ . '/config/database.php';

ini_set('display_errors', 1);
ini_set('error_reporting', E_ALL);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Configuration Verification - RAMYUM</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1000px; margin: 0 auto; padding: 20px; }
        .success { background: #d4edda; color: #155724; padding: 10px; border-radius: 4px; margin: 10px 0; }
        .error { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 4px; margin: 10px 0; }
        .info { background: #d1ecf1; color: #0c5460; padding: 10px; border-radius: 4px; margin: 10px 0; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        pre { background: #f8f9fa; padding: 15px; border-radius: 4px; overflow-x: auto; }
        h1 { color: #FF7A00; }
    </style>
</head>
<body>
    <h1>🔍 Database Configuration Verification</h1>

    <?php
    echo "<h2>Configuration Details</h2>";
    echo "<div class='info'>";
    echo "<strong>Database Host:</strong> " . DB_HOST . "<br>";
    echo "<strong>Database Name:</strong> " . DB_NAME . "<br>";
    echo "<strong>Database User:</strong> " . DB_USER . "<br>";
    echo "<strong>Character Set:</strong> " . DB_CHARSET . "<br>";
    echo "</div>";

    // Test database connection
    echo "<h2>Connection Test</h2>";
    try {
        $db = getDB();
        echo "<div class='success'>✅ Successfully connected to database using getDB() function</div>";
        
        // Test the alias function
        try {
            $db2 = get_database_connection();
            echo "<div class='success'>✅ Backward compatibility function get_database_connection() works correctly</div>";
        } catch (Exception $e) {
            echo "<div class='error'>❌ Error with get_database_connection(): " . $e->getMessage() . "</div>";
        }
        
        // Show database information
        $result = $db->query("SELECT DATABASE() as current_db, VERSION() as mysql_version")->fetch();
        echo "<div class='info'>";
        echo "<strong>Connected Database:</strong> " . $result['current_db'] . "<br>";
        echo "<strong>MySQL Version:</strong> " . $result['mysql_version'];
        echo "</div>";
        
    } catch (Exception $e) {
        echo "<div class='error'>❌ Database connection failed: " . $e->getMessage() . "</div>";
        echo "<div class='info'>Please ensure your database server is running and the database exists.</div>";
        exit;
    }

    // Test table structure
    echo "<h2>Table Structure Verification</h2>";
    try {
        $tables = $db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        echo "<div class='success'>✅ Found " . count($tables) . " tables in database</div>";
        
        echo "<h3>Database Tables:</h3>";
        echo "<table>";
        echo "<tr><th>Table Name</th><th>Record Count</th><th>Engine</th></tr>";
        
        foreach ($tables as $table) {
            try {
                $count = $db->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
                $engine = $db->query("SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '$table'")->fetchColumn();
                echo "<tr><td>$table</td><td>$count</td><td>$engine</td></tr>";
            } catch (Exception $e) {
                echo "<tr><td>$table</td><td>Error</td><td>Unknown</td></tr>";
            }
        }
        echo "</table>";
        
    } catch (Exception $e) {
        echo "<div class='error'>❌ Error checking tables: " . $e->getMessage() . "</div>";
    }

    // Test stock_transfer_audit table structure (most important fix)
    echo "<h2>Stock Transfer Audit Table Verification</h2>";
    try {
        $columns = $db->query("SHOW COLUMNS FROM stock_transfer_audit")->fetchAll();
        echo "<div class='success'>✅ stock_transfer_audit table exists with correct structure</div>";
        
        echo "<h3>Table Structure:</h3>";
        echo "<table>";
        echo "<tr><th>Field</th><th>Type</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
        
        $expectedColumns = ['id', 'transfer_id', 'action_type', 'user_id', 'user_name', 'details', 'ip_address', 'created_at'];
        $foundColumns = array_column($columns, 'Field');
        
        foreach ($columns as $col) {
            $isExpected = in_array($col['Field'], $expectedColumns);
            $rowClass = $isExpected ? '' : ' style="background-color: #fff3cd;"';
            echo "<tr$rowClass>";
            echo "<td>{$col['Field']}</td>";
            echo "<td>{$col['Type']}</td>";
            echo "<td>{$col['Key']}</td>";
            echo "<td>{$col['Default']}</td>";
            echo "<td>{$col['Extra']}</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // Check for old problematic columns
        $hasOldColumns = array_intersect(['action', 'performed_by', 'performed_by_name'], $foundColumns);
        if (empty($hasOldColumns)) {
            echo "<div class='success'>✅ Old problematic columns (action, performed_by, performed_by_name) not found - structure is correct!</div>";
        } else {
            echo "<div class='error'>❌ Old problematic columns still exist: " . implode(', ', $hasOldColumns) . "</div>";
        }
        
        // Check for new required columns
        $hasNewColumns = array_intersect(['action_type', 'user_id', 'user_name'], $foundColumns);
        if (count($hasNewColumns) === 3) {
            echo "<div class='success'>✅ All new required columns (action_type, user_id, user_name) are present!</div>";
        } else {
            echo "<div class='error'>❌ Missing required columns. Run migration script.</div>";
        }
        
    } catch (Exception $e) {
        echo "<div class='error'>❌ Error checking stock_transfer_audit table: " . $e->getMessage() . "</div>";
        echo "<div class='info'>This table may not exist yet. Run the migration script to create it.</div>";
    }

    // Test sample queries
    echo "<h2>Sample Data Verification</h2>";
    try {
        // Test users table
        $userCount = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
        echo "<div class='info'>Users in system: $userCount</div>";
        
        if ($userCount > 0) {
            $sampleUsers = $db->query("SELECT id, name, email, role FROM users LIMIT 3")->fetchAll();
            echo "<h3>Sample Users:</h3>";
            echo "<table>";
            echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th></tr>";
            foreach ($sampleUsers as $user) {
                echo "<tr><td>{$user['id']}</td><td>{$user['name']}</td><td>{$user['email']}</td><td>{$user['role']}</td></tr>";
            }
            echo "</table>";
        }
        
        // Test products if they exist
        if (in_array('products', $tables)) {
            $productCount = $db->query("SELECT COUNT(*) FROM products")->fetchColumn();
            echo "<div class='info'>Products in catalog: $productCount</div>";
        }
        
        // Test locations if they exist
        if (in_array('locations', $tables)) {
            $locationCount = $db->query("SELECT COUNT(*) FROM locations")->fetchColumn();
            echo "<div class='info'>Locations configured: $locationCount</div>";
        }
        
    } catch (Exception $e) {
        echo "<div class='error'>❌ Error checking sample data: " . $e->getMessage() . "</div>";
    }

    // Configuration status summary
    echo "<h2>📋 Configuration Status Summary</h2>";
    echo "<div class='info'>";
    echo "<strong>✅ Database Configuration Updated</strong><br>";
    echo "• Database name changed from 'ramyum_db' to 'ram_yum_inventory'<br>";
    echo "• Backward compatibility function added for legacy files<br>";
    echo "• Connection testing successful<br><br>";
    
    echo "<strong>Next Steps:</strong><br>";
    echo "1. If this is a fresh installation, run migration script<br>";
    echo "2. Test all application functionality<br>";
    echo "3. Verify stock transfer operations<br>";
    echo "4. Check user authentication and authorization<br>";
    echo "5. Clean up old SQL files after testing";
    echo "</div>";
    ?>

</body>
</html>