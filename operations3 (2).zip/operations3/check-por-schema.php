<?php
/**
 * Debug POR Creation Error
 * Find exact database error
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/database.php';
require_once 'includes/functions.php';

$db = getDB();

echo "POR CREATION DEBUG\n";
echo str_repeat("=", 80) . "\n\n";

// 1. Check if tables exist
echo "1. CHECKING TABLES...\n";
echo str_repeat("-", 80) . "\n";

$tables = ['proof_of_receiving', 'proof_of_receiving_items', 'receivings', 'purchase_orders'];
foreach ($tables as $table) {
    $stmt = $db->query("SHOW TABLES LIKE '$table'");
    if ($stmt->rowCount() > 0) {
        echo "✓ Table '$table' exists\n";
    } else {
        echo "✗ Table '$table' MISSING!\n";
    }
}

// 2. Check proof_of_receiving schema
echo "\n2. PROOF_OF_RECEIVING SCHEMA:\n";
echo str_repeat("-", 80) . "\n";
try {
    $stmt = $db->query("DESCRIBE proof_of_receiving");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($columns as $col) {
        echo sprintf("%-30s %-20s %s %s\n", 
            $col['Field'], 
            $col['Type'], 
            $col['Null'] === 'NO' ? 'NOT NULL' : 'NULL',
            $col['Key'] ? "[$col[Key]]" : ""
        );
    }
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}

// 3. Check proof_of_receiving_items schema
echo "\n3. PROOF_OF_RECEIVING_ITEMS SCHEMA:\n";
echo str_repeat("-", 80) . "\n";
try {
    $stmt = $db->query("DESCRIBE proof_of_receiving_items");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($columns as $col) {
        echo sprintf("%-30s %-20s %s %s\n", 
            $col['Field'], 
            $col['Type'], 
            $col['Null'] === 'NO' ? 'NOT NULL' : 'NULL',
            $col['Key'] ? "[$col[Key]]" : ""
        );
    }
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}

// 4. Check receivings table structure
echo "\n4. RECEIVINGS TABLE:\n";
echo str_repeat("-", 80) . "\n";
try {
    $stmt = $db->query("SELECT id, data FROM receivings LIMIT 1");
    $receiving = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($receiving) {
        echo "✓ Has receiving records\n";
        echo "Sample ID: " . $receiving['id'] . "\n";
        $data = json_decode($receiving['data'], true);
        echo "\nReceiving Data Structure:\n";
        print_r($data);
    } else {
        echo "⚠ No receiving records found\n";
    }
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}

// 5. Try to simulate POR creation
echo "\n5. SIMULATING POR CREATION...\n";
echo str_repeat("-", 80) . "\n";

try {
    // Get a receiving record
    $stmt = $db->query("SELECT id, data FROM receivings LIMIT 1");
    $receiving = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$receiving) {
        throw new Exception("No receiving records found");
    }
    
    $receivingData = json_decode($receiving['data'], true);
    echo "Receiving ID: " . $receiving['id'] . "\n";
    echo "PO ID: " . ($receivingData['poId'] ?? 'MISSING') . "\n";
    echo "PO Number: " . ($receivingData['poNumber'] ?? 'MISSING') . "\n";
    echo "Supplier ID: " . ($receivingData['supplierId'] ?? 'MISSING') . "\n";
    echo "Supplier: " . ($receivingData['supplier'] ?? 'MISSING') . "\n";
    echo "Items count: " . count($receivingData['items'] ?? []) . "\n";
    
    // Check if POR already exists
    $checkStmt = $db->prepare("SELECT id FROM proof_of_receiving WHERE receiving_id = ?");
    $checkStmt->execute([$receiving['id']]);
    if ($checkStmt->fetch()) {
        echo "\n⚠ POR already exists for this receiving\n";
    } else {
        echo "\n✓ No existing POR for this receiving\n";
    }
    
    // Generate test POR data
    $porId = generate_id('por');
    $porNumber = 'POR-TEST-' . date('YmdHis');
    
    echo "\nTest POR Data:\n";
    echo "  POR ID: $porId\n";
    echo "  POR Number: $porNumber\n";
    
    // Test INSERT (without commit)
    $db->beginTransaction();
    
    try {
        $stmt = $db->prepare("
            INSERT INTO proof_of_receiving (
                id, por_number, purchase_order_id, po_number, receiving_id,
                supplier_id, supplier_name, received_by, received_by_name,
                receiving_date, receiving_time, inspection_status, status,
                total_items, total_ordered, total_received, total_accepted, total_rejected,
                total_value, remarks
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $params = [
            $porId,
            $porNumber,
            $receivingData['poId'] ?? null,
            $receivingData['poNumber'] ?? null,
            $receiving['id'],
            $receivingData['supplierId'] ?? null,
            $receivingData['supplier'] ?? null,
            'admin',
            'Test User',
            $receivingData['receivedDate'] ?? date('Y-m-d H:i:s'),
            date('H:i:s'),
            'Pending',
            'Draft',
            count($receivingData['items'] ?? []),
            0.00,
            0.00,
            0.00,
            0.00,
            0.00,
            'Test POR'
        ];
        
        echo "\nAttempting INSERT with params:\n";
        foreach ($params as $i => $param) {
            echo sprintf("  [%d] %s\n", $i, var_export($param, true));
        }
        
        $stmt->execute($params);
        
        echo "\n✓ INSERT successful (test transaction)\n";
        $db->rollBack();
        echo "✓ Transaction rolled back (test only)\n";
        
    } catch (PDOException $e) {
        $db->rollBack();
        echo "\n✗ INSERT FAILED!\n";
        echo "PDO Error: " . $e->getMessage() . "\n";
        echo "Error Code: " . $e->getCode() . "\n";
        echo "SQL State: " . $e->errorInfo[0] . "\n";
        throw $e;
    }
    
} catch (Exception $e) {
    echo "\n✗ SIMULATION FAILED!\n";
    echo "Error: " . $e->getMessage() . "\n";
    if (isset($e->errorInfo)) {
        echo "SQL State: " . $e->errorInfo[0] . "\n";
        echo "Error Code: " . $e->errorInfo[1] . "\n";
        echo "Error Message: " . $e->errorInfo[2] . "\n";
    }
}

echo "\n" . str_repeat("=", 80) . "\n";
echo "DEBUG COMPLETE\n";
