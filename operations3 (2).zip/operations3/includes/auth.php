<?php
/**
 * Session-based authentication for the RAM-YUM PHP backend.
 * Replaces the original app's client-only localStorage "session token".
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/mail.php';
require_once __DIR__ . '/functions.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

const MAX_LOGIN_ATTEMPTS = 5;
const LOCKOUT_MINUTES    = 15;

const OTP_LENGTH         = 6;
const OTP_TTL_MINUTES    = 5;
const OTP_MAX_ATTEMPTS   = 5;
const OTP_RESEND_COOLDOWN_SECONDS = 60;

/**
 * Generates a fresh numeric OTP for the given user, invalidates any
 * previous unconsumed codes for that user/purpose, and stores a hash
 * of the new code (never the plaintext) in the otp_codes table.
 * Returns the plaintext code so the caller can deliver it (email/SMS).
 */
function generate_and_store_otp(string $userId, string $purpose = 'login'): string
{
    $db = getDB();

    // Invalidate any previous outstanding codes for this user/purpose.
    $db->prepare('DELETE FROM otp_codes WHERE user_id = ? AND purpose = ? AND consumed_at IS NULL')
       ->execute([$userId, $purpose]);

    $code = str_pad((string) random_int(0, (10 ** OTP_LENGTH) - 1), OTP_LENGTH, '0', STR_PAD_LEFT);

    $stmt = $db->prepare(
        'INSERT INTO otp_codes (id, user_id, code_hash, purpose, expires_at) VALUES (?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL ' . OTP_TTL_MINUTES . ' MINUTE))'
    );
    $stmt->execute([generate_id('otp'), $userId, password_hash($code, PASSWORD_DEFAULT), $purpose]);

    return $code;
}

/**
 * Returns the number of seconds the caller must still wait before a
 * new OTP may be requested for this user/purpose (0 if none).
 */
function otp_resend_wait_seconds(string $userId, string $purpose = 'login'): int
{
    $db = getDB();
    $stmt = $db->prepare('SELECT created_at FROM otp_codes WHERE user_id = ? AND purpose = ? ORDER BY created_at DESC LIMIT 1');
    $stmt->execute([$userId, $purpose]);
    $row = $stmt->fetch();
    if (!$row) {
        return 0;
    }
    $elapsed = time() - strtotime($row['created_at']);
    return max(0, OTP_RESEND_COOLDOWN_SECONDS - $elapsed);
}

/**
 * Sends an OTP code to the user's email via PHPMailer over SMTP (see
 * config/mail.php for credentials, sourced from .env). Never throws —
 * on any failure (or when SMTP isn't configured) this returns false so
 * the caller can fall back to OTP_DEMO_MODE for local/dev testing.
 */
function send_otp_email(string $email, string $name, string $code): bool
{
    return send_otp_email_smtp($email, $name, $code, OTP_TTL_MINUTES);
}

/**
 * Verifies a submitted OTP code against the latest unconsumed code on
 * file for the user/purpose. Returns one of:
 *   'ok'            — code valid, not expired, under attempt limit; now consumed.
 *   'no_pending'    — no outstanding (unconsumed) code exists for this user.
 *   'expired'       — the latest code exists but its TTL has passed.
 *   'max_attempts'  — the attempt limit was already reached; a new code is required.
 *   'invalid'       — the code was wrong (attempt counter incremented).
 *
 * Never reveals which of these apply for a user_id that doesn't match
 * the session's pending user, since the caller only ever calls this
 * with the session's own otp_pending_user_id.
 */
function verify_otp_reason(string $userId, string $code, string $purpose = 'login'): string
{
    $db = getDB();
    $stmt = $db->prepare(
        'SELECT * FROM otp_codes WHERE user_id = ? AND purpose = ? AND consumed_at IS NULL ORDER BY created_at DESC LIMIT 1'
    );
    $stmt->execute([$userId, $purpose]);
    $row = $stmt->fetch();

    if (!$row) {
        return 'no_pending';
    }

    if ((int) $row['attempts'] >= OTP_MAX_ATTEMPTS) {
        return 'max_attempts';
    }

    if (strtotime($row['expires_at']) < time()) {
        return 'expired';
    }

    if (!password_verify($code, $row['code_hash'])) {
        $db->prepare('UPDATE otp_codes SET attempts = attempts + 1 WHERE id = ?')->execute([$row['id']]);
        return 'invalid';
    }

    $db->prepare('UPDATE otp_codes SET consumed_at = NOW() WHERE id = ?')->execute([$row['id']]);
    return 'ok';
}

/**
 * Back-compat boolean wrapper around verify_otp_reason().
 */
function verify_otp(string $userId, string $code, string $purpose = 'login'): bool
{
    return verify_otp_reason($userId, $code, $purpose) === 'ok';
}

/**
 * Returns true if a user is currently logged in.
 */
function is_logged_in(): bool
{
    return !empty($_SESSION['user_id']);
}

/**
 * Fetches the full current user record (minus password hash) from the DB,
 * or null if not logged in / user no longer exists.
 */
function current_user(): ?array
{
    if (!is_logged_in()) {
        return null;
    }
    $db = getDB();
    $stmt = $db->prepare('SELECT id, name, email, username, role, verified, profile_picture, created_at FROM users WHERE id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    return $user ?: null;
}

/**
 * Redirects to the login page (for full page loads) if not authenticated.
 * Call this at the top of any protected .php page.
 */
function require_login_page(): array
{
    $user = current_user();
    if (!$user) {
        header('Location: index.php');
        exit;
    }
    return $user;
}

/**
 * For API endpoints: responds with 401 JSON if not authenticated.
 */
function require_login_api(): array
{
    $user = current_user();
    if (!$user) {
        json_error('Not authenticated. Please log in.', 401);
    }
    return $user;
}

/**
 * For API endpoints: responds with 403 JSON if not an admin.
 */
function require_admin_api(): array
{
    $user = require_login_api();
    if ($user['role'] !== 'admin') {
        json_error('Administrator access required.', 403);
    }
    return $user;
}

/**
 * For API endpoints: responds with 403 JSON unless the user is an
 * admin or manager. Used to gate features like AI Analytics that
 * should stay out of reach for staff-level accounts.
 */
function require_manager_api(): array
{
    $user = require_login_api();
    if (!in_array($user['role'], ['admin', 'manager'], true)) {
        json_error('Admin or Manager access required.', 403);
    }
    return $user;
}

/**
 * Checks whether an identifier (username) is currently locked out due to
 * too many failed login attempts. Returns [locked(bool), remainingMinutes].
 */
function check_lockout(string $identifier): array
{
    $db = getDB();
    $stmt = $db->prepare('SELECT attempt_count, last_attempt FROM login_attempts WHERE identifier = ?');
    $stmt->execute([$identifier]);
    $row = $stmt->fetch();

    if (!$row) {
        return [false, 0];
    }

    $elapsedMinutes = (time() - strtotime($row['last_attempt'])) / 60;

    if ($row['attempt_count'] >= MAX_LOGIN_ATTEMPTS && $elapsedMinutes < LOCKOUT_MINUTES) {
        return [true, (int) ceil(LOCKOUT_MINUTES - $elapsedMinutes)];
    }

    return [false, 0];
}

/**
 * Records a failed login attempt for brute-force protection.
 */
function record_failed_login(string $identifier): void
{
    $db = getDB();
    $stmt = $db->prepare(
        'INSERT INTO login_attempts (identifier, attempt_count, last_attempt) VALUES (?, 1, NOW())
         ON DUPLICATE KEY UPDATE
            attempt_count = IF(TIMESTAMPDIFF(MINUTE, last_attempt, NOW()) > ' . LOCKOUT_MINUTES . ', 1, attempt_count + 1),
            last_attempt = NOW()'
    );
    $stmt->execute([$identifier]);
}

/**
 * Clears recorded failed login attempts after a successful login.
 */
function clear_login_attempts(string $identifier): void
{
    $db = getDB();
    $stmt = $db->prepare('DELETE FROM login_attempts WHERE identifier = ?');
    $stmt->execute([$identifier]);
}
