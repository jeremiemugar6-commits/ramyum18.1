<?php
/**
 * Stock Status Helper
 * Centralized logic for automatic stock status calculation
 * Based on current stock quantity
 */

/**
 * Get automatic stock status based on current quantity
 * 
 * Rules:
 * - 0 = Out of Stock
 * - 1-20 = Low Stock
 * - 21-100 = In Stock
 * - 101+ = Overstock / High Stock
 * 
 * @param int|float $currentStock Current stock quantity
 * @return string Stock status
 */
function getStockStatus($currentStock) {
    // Convert to numeric, handle null/invalid values
    $stock = floatval($currentStock);
    
    // Handle negative stock as Out of Stock
    if ($stock <= 0) {
        return 'Out of Stock';
    } elseif ($stock < 21) {
        // 1-20.999... = Low Stock
        return 'Low Stock';
    } elseif ($stock <= 100) {
        // 21-100 = In Stock
        return 'In Stock';
    } else {
        // 101+ = Overstock
        return 'Overstock';
    }
}

/**
 * Get stock status badge HTML with appropriate styling
 * 
 * @param int|float $currentStock Current stock quantity
 * @return string HTML badge
 */
function getStockStatusBadge($currentStock) {
    $status = getStockStatus($currentStock);
    $badgeClass = getStockStatusBadgeClass($status);
    $emoji = getStockStatusEmoji($status);
    
    return "<span class=\"stock-badge {$badgeClass}\">{$emoji} {$status}</span>";
}

/**
 * Get CSS class for stock status badge
 * 
 * @param string $status Stock status
 * @return string CSS class
 */
function getStockStatusBadgeClass($status) {
    switch ($status) {
        case 'Out of Stock':
            return 'badge-out-of-stock';
        case 'Low Stock':
            return 'badge-low-stock';
        case 'In Stock':
            return 'badge-in-stock';
        case 'Overstock':
            return 'badge-overstock';
        default:
            return 'badge-default';
    }
}

/**
 * Get emoji for stock status
 * 
 * @param string $status Stock status
 * @return string Emoji
 */
function getStockStatusEmoji($status) {
    switch ($status) {
        case 'Out of Stock':
            return '🔴';
        case 'Low Stock':
            return '🟠';
        case 'In Stock':
            return '🟢';
        case 'Overstock':
            return '🔵';
        default:
            return '⚪';
    }
}

/**
 * Get stock status for product data (from JSON)
 * Automatically calculates from stock field
 * 
 * @param array $productData Product data array
 * @return string Stock status
 */
function getProductStockStatus($productData) {
    $stock = $productData['stock'] ?? 0;
    return getStockStatus($stock);
}

/**
 * Update product with automatic stock status
 * Adds 'status' field based on 'stock' field
 * 
 * @param array $productData Product data array
 * @return array Updated product data
 */
function enrichProductWithStatus($productData) {
    $productData['status'] = getProductStockStatus($productData);
    return $productData;
}
?>
