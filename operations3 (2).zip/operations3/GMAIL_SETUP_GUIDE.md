# Gmail SMTP Configuration Guide

Your application is now configured to use Gmail as the email provider. Follow these steps to complete the setup:

## Step 1: Enable 2-Step Verification (Required)

1. Go to your [Google Account Settings](https://myaccount.google.com/)
2. Click on "Security" in the left sidebar
3. Under "Signing in to Google", click on "2-Step Verification"
4. Follow the prompts to enable 2-Step Verification using your phone

## Step 2: Generate App Password

1. Once 2-Step Verification is enabled, go to [App passwords](https://myaccount.google.com/apppasswords)
2. You may need to sign in again
3. Under "Select app", choose "Mail" or "Other (Custom name)"
4. If you choose "Other", enter "RAMYUM System" as the name
5. Click "Generate"
6. Google will display a 16-character password (like: `abcd efgh ijkl mnop`)
7. **Copy this password immediately** - you won't be able to see it again

## Step 3: Update Your .env File

Edit the `.env` file in your project root and replace the placeholders:

```env
SMTP_USERNAME=your-actual-gmail@gmail.com
SMTP_PASSWORD=your-16-character-app-password
SMTP_FROM_EMAIL=your-actual-gmail@gmail.com
```

**Example:**
```env
SMTP_USERNAME=john.doe@gmail.com
SMTP_PASSWORD=abcd efgh ijkl mnop
SMTP_FROM_EMAIL=john.doe@gmail.com
```

## Step 4: Test the Configuration

You can test your email configuration by:

1. Using the existing `test-email.php` file (if available)
2. Or attempting a login with OTP to see if emails are sent

## Gmail SMTP Settings Summary

- **Host**: smtp.gmail.com
- **Port**: 587
- **Encryption**: TLS
- **Authentication**: Yes (using App Password)

## Security Notes

- ✅ **DO**: Use App Passwords (16 characters)
- ❌ **DON'T**: Use your regular Gmail password
- ✅ **DO**: Keep your `.env` file secure and never commit it to version control
- ✅ **DO**: Enable 2-Step Verification on your Google account

## Troubleshooting

### "Invalid credentials" error:
- Make sure you're using an App Password, not your regular password
- Verify 2-Step Verification is enabled
- Double-check the email address is correct

### "Less secure app access" error:
- This shouldn't happen with App Passwords, but if it does:
- Go to [Less secure app access](https://myaccount.google.com/lesssecureapps)
- Turn it ON (though App Passwords are preferred)

### Emails not being delivered:
- Check your Gmail's "Sent" folder
- Check recipient's spam/junk folder
- Verify the FROM email matches your SMTP username

## Alternative Email Providers

If you encounter issues with Gmail, consider these alternatives:
- **SendGrid**: Professional transactional email service
- **Mailgun**: Developer-friendly email API
- **Amazon SES**: Cost-effective email service
- **Outlook**: Microsoft's email service

---
**Note**: This file contains setup instructions and can be deleted after configuration is complete.