# Purchase Order Status Workflow Implementation Plan

## Current System Analysis

Based on the existing codebase:
- POs stored in `purchase_orders` table with JSON `data` field
- Current status values found: "Draft", "Approved", "Pending", "Completed"
- Receivings linked to POs via `poId` in JSON data
- POR table links to POs via `purchase_order_id`

## Implementation Strategy

### Phase 1: Database & Backend (Core Logic)
1. ✅ Standardize status values in PO data
2. ✅ Create status management functions
3. ✅ Implement transition validation
4. ✅ Add approval workflow
5. ✅ Calculate received quantities
6. ✅ Auto-update to FULLY_RECEIVED

### Phase 2: API Updates
1. ✅ Add status filter endpoints
2. ✅ Add submit/approve/cancel actions
3. ✅ Add status transition validation
4. ✅ Update receiving integration

### Phase 3: UI Updates
1. ✅ Add status filter tabs
2. ✅ Update status badges
3. ✅ Add action buttons per status
4. ✅ Update PO forms

### Phase 4: Integration & Testing
1. ✅ Test all transitions
2. ✅ Test receiving integration
3. ✅ Test POR creation
4. ✅ Audit log verification

## Status Definitions

```
DRAFT          - Being prepared, fully editable
PENDING        - Submitted, awaiting approval
APPROVED       - Approved, can receive
FULLY_RECEIVED - All items received
CANCELLED      - Order cancelled
```

## Transition Rules

```
DRAFT → PENDING (submit)
DRAFT → CANCELLED (cancel draft)
PENDING → APPROVED (approve)
PENDING → CANCELLED (reject)
APPROVED → FULLY_RECEIVED (auto, when all received)
APPROVED → CANCELLED (cancel if no receipts)
```

## Files to Create/Modify

### New Files
- `includes/po-status-workflow.php` - Status management functions
- `api/po-workflow.php` - Status workflow API
- `database/po-status-migration.sql` - Status standardization
- `PO_WORKFLOW_IMPLEMENTATION.md` - Documentation

### Modified Files
- `api/data.php` - Add status filters
- `modules/purchase-orders/purchase-orders.js` - UI updates
- `modules/purchase-orders/purchase-orders.html` - Status tabs

## Next Steps

1. Create status workflow functions
2. Create workflow API
3. Update data.php API
4. Update UI
5. Test complete workflow
