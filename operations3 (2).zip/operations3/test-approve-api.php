<?php
/**
 * Quick Test for Approve Transfer API
 * This simulates what the JavaScript would send
 */

// Simulate being logged in as admin
session_start();

// You need to set this to your actual admin user ID
// Check your users table for a valid admin user
$_SESSION['user_id'] = 'usr_test_admin';  // Replace with actual admin user ID

// Simulate POST request
$_SERVER['REQUEST_METHOD'] = 'POST';
$_GET['action'] = 'approve';

// Simulate JSON input
$jsonInput = json_encode([
    'transferId' => 'st_1791102011929_b9a789',  // Your actual transfer ID
    'approvalRemarks' => 'Test approval from PHP'
]);

// Capture the JSON input
$GLOBALS['_test_json_input'] = $jsonInput;

echo "=== Testing Approve Transfer API ===\n\n";
echo "Transfer ID: st_1791102011929_b9a789\n";
echo "Remarks: Test approval from PHP\n\n";
echo "Response:\n";
echo "-----------------------------------\n";

// Include the API file (it will execute and output JSON)
require_once 'api/stock-transfers.php';
