<?php
require_once 'config/database.php';

$db = getDB();

echo "TRANSFER_PROOF TABLE:\n";
$cols = $db->query('DESCRIBE transfer_proof')->fetchAll();
foreach($cols as $c) {
    echo "  {$c['Field']} - {$c['Type']}\n";
}

echo "\nTRANSFER_PROOF_ITEMS TABLE:\n";
$cols2 = $db->query('DESCRIBE transfer_proof_items')->fetchAll();
foreach($cols2 as $c) {
    echo "  {$c['Field']} - {$c['Type']}\n";
}

echo "\nSTOCK_TRANSFERS TABLE:\n";
$cols3 = $db->query('DESCRIBE stock_transfers')->fetchAll();
foreach($cols3 as $c) {
    echo "  {$c['Field']} - {$c['Type']}\n";
}
