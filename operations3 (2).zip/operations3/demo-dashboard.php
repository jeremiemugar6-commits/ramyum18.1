<?php
/**
 * RAM-YUM Capstone Demonstration Dashboard
 * Comprehensive view for pre-oral defense presentation
 */

require_once __DIR__ . '/includes/auth.php';

// Only allow in demo mode
if (!DEMO_INTEGRATION_MODE) {
    header('Location: index.php');
    exit();
}

require_login();

$demoConfig = getDemoConfig();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RAM-YUM Capstone Demonstration</title>
    <link rel="stylesheet" href="assets/css/main.css">
    <style>
        .demo-header {
            background: linear-gradient(135deg, #E53935, #D32F2F);
            color: white;
            padding: 30px;
            text-align: center;
            margin-bottom: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }
        
        .demo-header h1 {
            font-size: 2.5rem;
            margin-bottom: 8px;
            font-weight: 700;
        }
        
        .demo-subtitle {
            font-size: 1.2rem;
            opacity: 0.9;
            margin-bottom: 20px;
        }
        
        .demo-badge {
            background: rgba(255,255,255,0.2);
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.9rem;
            display: inline-block;
        }
        
        .workflow-demo {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .workflow-step {
            background: white;
            padding: 24px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            border: 2px solid transparent;
            transition: all 0.3s ease;
            cursor: pointer;
            position: relative;
        }
        
        .workflow-step:hover {
            border-color: #E53935;
            transform: translateY(-2px);
        }
        
        .workflow-step.active {
            border-color: #10B981;
            background: linear-gradient(135deg, #ECFDF5, #D1FAE5);
        }
        
        .step-number {
            position: absolute;
            top: -10px;
            left: 20px;
            background: #E53935;
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 0.9rem;
        }
        
        .step-title {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 8px;
            padding-top: 10px;
        }
        
        .step-description {
            color: #6B7280;
            margin-bottom: 16px;
        }
        
        .step-status {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9rem;
            font-weight: 500;
        }
        
        .status-complete { color: #10B981; }
        .status-active { color: #F59E0B; }
        .status-pending { color: #6B7280; }
        
        .demo-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 16px;
            margin-bottom: 30px;
        }
        
        .action-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            text-align: center;
            transition: all 0.2s;
        }
        
        .action-card:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
        }
        
        .action-icon {
            font-size: 2.5rem;
            margin-bottom: 12px;
        }
        
        .action-title {
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 8px;
        }
        
        .action-btn {
            background: #E53935;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            text-decoration: none;
            display: inline-block;
            margin-top: 12px;
            transition: all 0.2s;
        }
        
        .action-btn:hover {
            background: #D32F2F;
            transform: translateY(-1px);
        }
        
        .action-btn.secondary {
            background: #6B7280;
        }
        
        .action-btn.secondary:hover {
            background: #4B5563;
        }
        
        .metrics-overview {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 30px;
        }
        
        .metric-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .metric-value {
            font-size: 2.2rem;
            font-weight: 700;
            margin-bottom: 4px;
        }
        
        .metric-label {
            color: #6B7280;
            font-size: 0.9rem;
            font-weight: 500;
        }
        
        .demo-footer {
            background: #F9FAFB;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            margin-top: 30px;
        }
    </style>
</head>
<body>
    <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 20px;">
        <div class="demo-header">
            <h1>🍜 RAM-YUM Operations System</h1>
            <p class="demo-subtitle">BSIT Capstone Project Demonstration</p>
            <span class="demo-badge"><?= htmlspecialchars($demoConfig['message']) ?></span>
        </div>

        <!-- Workflow Steps Overview -->
        <div class="workflow-demo">
            <div class="workflow-step active" onclick="navigateToModule('purchase-orders')">
                <div class="step-number">1</div>
                <div class="step-title">Purchase Orders</div>
                <div class="step-description">Create and manage vendor purchase orders with proper PO numbering and approval workflow</div>
                <div class="step-status status-complete">
                    ✅ Complete - Ready for Demo
                </div>
            </div>
            
            <div class="workflow-step active" onclick="navigateToModule('receiving')">
                <div class="step-number">2</div>
                <div class="step-title">Receiving</div>
                <div class="step-description">Process incoming deliveries with partial receiving support and goods receipt numbering</div>
                <div class="step-status status-complete">
                    ✅ Complete - Ready for Demo
                </div>
            </div>
            
            <div class="workflow-step active" onclick="navigateToModule('inventory')">
                <div class="step-number">3</div>
                <div class="step-title">Inventory Updates</div>
                <div class="step-description">Automatic stock updates with comprehensive movement logging and audit trails</div>
                <div class="step-status status-complete">
                    ✅ Complete - Ready for Demo
                </div>
            </div>
            
            <div class="workflow-step active" onclick="navigateToModule('reports')">
                <div class="step-number">4</div>
                <div class="step-title">Reports & Analytics</div>
                <div class="step-description">Comprehensive reporting with workflow analysis and audit trail documentation</div>
                <div class="step-status status-complete">
                    ✅ Complete - Ready for Demo
                </div>
            </div>
        </div>

        <!-- System Metrics -->
        <div class="metrics-overview" id="metricsOverview">
            <div class="metric-card">
                <div class="metric-value" style="color: #3B82F6;" id="totalPOs">--</div>
                <div class="metric-label">Purchase Orders</div>
            </div>
            <div class="metric-card">
                <div class="metric-value" style="color: #10B981;" id="completedPOs">--</div>
                <div class="metric-label">Completed POs</div>
            </div>
            <div class="metric-card">
                <div class="metric-value" style="color: #F59E0B;" id="totalReceivings">--</div>
                <div class="metric-label">Receiving Records</div>
            </div>
            <div class="metric-card">
                <div class="metric-value" style="color: #E53935;" id="totalProducts">--</div>
                <div class="metric-label">Products</div>
            </div>
            <div class="metric-card">
                <div class="metric-value" style="color: #8B5CF6;" id="totalMovements">--</div>
                <div class="metric-label">Stock Movements</div>
            </div>
        </div>

        <!-- Demo Actions -->
        <div class="demo-actions">
            <div class="action-card">
                <div class="action-icon">📊</div>
                <div class="action-title">Full System Access</div>
                <div style="color: #6B7280; margin-bottom: 8px;">Access the complete RAM-YUM dashboard</div>
                <a href="dashboard.php" class="action-btn">Open Dashboard</a>
            </div>
            
            <div class="action-card">
                <div class="action-icon">🧪</div>
                <div class="action-title">Workflow Testing</div>
                <div style="color: #6B7280; margin-bottom: 8px;">Test the complete PO → Receiving → Inventory workflow</div>
                <a href="test-workflow.php" class="action-btn secondary">Run Tests</a>
            </div>
            
            <div class="action-card">
                <div class="action-icon">⚙️</div>
                <div class="action-title">Demo Setup</div>
                <div style="color: #6B7280; margin-bottom: 8px;">Load demo data and configure the system</div>
                <a href="setup-demo.php" class="action-btn secondary">Setup Demo</a>
            </div>
            
            <div class="action-card">
                <div class="action-icon">🔧</div>
                <div class="action-title">Module Validation</div>
                <div style="color: #6B7280; margin-bottom: 8px;">Validate JavaScript modules and dependencies</div>
                <a href="validate-modules.html" class="action-btn secondary">Validate</a>
            </div>
        </div>

        <!-- Demo Footer -->
        <div class="demo-footer">
            <h3 style="margin-bottom: 12px; color: #1F2937;">Ready for Capstone Demonstration</h3>
            <p style="color: #6B7280; margin-bottom: 16px;">
                The RAM-YUM system demonstrates a complete Purchase Order → Receiving → Inventory workflow 
                with comprehensive reporting and audit trail capabilities.
            </p>
            <p style="color: #6B7280; font-size: 0.9rem;">
                <strong>Key Features:</strong> PO Management, Partial Receiving, Stock Movement Logging, 
                Status Workflow, Audit Trails, Comprehensive Reports, Philippine Peso Currency, 
                Korean/Japanese Product Catalog
            </p>
        </div>
    </div>

    <script type="module">
        // Load system metrics
        async function loadMetrics() {
            try {
                const response = await fetch('api/reports.php?action=workflow_summary');
                const result = await response.json();
                
                if (result.success) {
                    const data = result.data;
                    document.getElementById('totalPOs').textContent = data.totalPOs || 0;
                    document.getElementById('completedPOs').textContent = data.completedPOs || 0;
                    document.getElementById('totalReceivings').textContent = data.totalReceivings || 0;
                    
                    // Load additional metrics
                    const inventoryResponse = await fetch('api/reports.php?action=inventory_metrics');
                    const inventoryResult = await inventoryResponse.json();
                    
                    if (inventoryResult.success) {
                        const invData = inventoryResult.data;
                        document.getElementById('totalProducts').textContent = invData.totalProducts || 0;
                        document.getElementById('totalMovements').textContent = invData.movementCount || 0;
                    }
                }
            } catch (error) {
                console.error('Failed to load metrics:', error);
            }
        }

        // Navigation function
        function navigateToModule(module) {
            const url = `dashboard.php#${module}`;
            window.open(url, '_blank');
        }

        // Make function globally available
        window.navigateToModule = navigateToModule;

        // Load metrics on page load
        document.addEventListener('DOMContentLoaded', loadMetrics);
    </script>
</body>
</html>