<?php
require_once __DIR__ . '/../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$pendingUserId = $_SESSION['otp_pending_user_id'] ?? null;
if (!$pendingUserId) {
    json_error('No pending login. Please log in again.', 400);
}

$input = get_json_input();
$code  = trim((string) ($input['code'] ?? ''));

if ($code === '') {
    json_error('Verification code is required.');
}

$db = getDB();
$stmt = $db->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
$stmt->execute([$pendingUserId]);
$user = $stmt->fetch();

if (!$user) {
    unset($_SESSION['otp_pending_user_id']);
    json_error('Session expired. Please log in again.', 401);
}

$reason = verify_otp_reason($pendingUserId, $code);

if ($reason !== 'ok') {
    switch ($reason) {
        case 'expired':
            log_security_event('OTP_EXPIRED', $user['id'], $user['username']);
            json_error('This code has expired. Please request a new one.', 401);
            break;
        case 'max_attempts':
            log_security_event('OTP_MAX_ATTEMPTS_REACHED', $user['id'], $user['username']);
            json_error('Too many incorrect attempts. Please request a new code.', 401);
            break;
        case 'no_pending':
            unset($_SESSION['otp_pending_user_id']);
            json_error('No active verification code. Please log in again.', 400);
            break;
        default: // 'invalid'
            log_security_event('OTP_FAILED', $user['id'], $user['username']);
            json_error('Incorrect code. Please try again.', 401);
    }
}

// Code verified — now establish the real authenticated session.
session_regenerate_id(true);
unset($_SESSION['otp_pending_user_id']);
$_SESSION['user_id']  = $user['id'];
$_SESSION['username'] = $user['username'];
$_SESSION['role']     = $user['role'];

log_security_event('LOGIN_SUCCESS', $user['id'], $user['username']);

unset($user['password_hash']);
json_response(['success' => true, 'user' => $user]);
