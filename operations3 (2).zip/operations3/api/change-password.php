<?php
require_once __DIR__ . '/../includes/auth.php';

$user = require_login_api();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = get_json_input();
$currentPassword = (string) ($input['currentPassword'] ?? '');
$newPassword = (string) ($input['newPassword'] ?? '');

if ($currentPassword === '' || $newPassword === '') {
    json_error('Current and new password are required.');
}
if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/', $newPassword)) {
    json_error('New password must be 8+ characters and include uppercase, lowercase, and a number.');
}

$db = getDB();
$stmt = $db->prepare('SELECT password_hash FROM users WHERE id = ?');
$stmt->execute([$user['id']]);
$row = $stmt->fetch();

if (!$row || !password_verify($currentPassword, $row['password_hash'])) {
    json_error('Current password is incorrect.', 401);
}

$newHash = password_hash($newPassword, PASSWORD_BCRYPT);
$update = $db->prepare('UPDATE users SET password_hash = ? WHERE id = ?');
$update->execute([$newHash, $user['id']]);

log_security_event('PASSWORD_CHANGED', $user['id'], $user['username']);

json_response(['success' => true]);
