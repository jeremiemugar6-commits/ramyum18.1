<?php
/**
 * AI Inventory Analytics — Demand Prediction Endpoint
 *
 * Implements a simple Linear Regression model (Y = b0 + b1X) over each
 * product's monthly "Stock Out" movement history to:
 *   - predict next month's demand (Y)
 *   - classify a demand trend (Increasing / Decreasing / Stable)
 *   - recommend a restock quantity
 *   - report an accuracy score (R^2 of the fitted line)
 *
 * Results are cached in the inventory_predictions table (one row per
 * product, upserted on every run) so the dashboard can load instantly
 * without recomputing the model on every page view.
 *
 * Restricted to Admin and Manager roles.
 *
 * Usage:
 *   GET  api/ai-predictions.php                -> latest cached predictions (product-enriched)
 *   POST api/ai-predictions.php?action=run      -> re-run the model for all products, cache, and return results
 */

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/regression.php';

$user = require_manager_api();

$db     = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

/**
 * Sums a product's stock field, which is normally a plain number but
 * may be a per-location object (see reports.js / inventory.js).
 */
function total_stock($stockField): float
{
    if (is_array($stockField)) {
        return (float) array_sum($stockField);
    }
    return (float) ($stockField ?? 0);
}

/**
 * Re-runs the regression model for every product and upserts one row
 * per product into inventory_predictions (latest prediction only).
 */
function run_predictions(PDO $db): array
{
    $products = array_map(
        fn($r) => json_decode($r['data'], true),
        $db->query('SELECT data FROM products')->fetchAll()
    );

    $movements = array_map(
        fn($r) => json_decode($r['data'], true),
        $db->query('SELECT data FROM inventory_movements')->fetchAll()
    );

    // Aggregate "Stock Out" quantities per product, per calendar month —
    // this is our proxy for historical demand/consumption.
    $byProduct = [];
    foreach ($movements as $m) {
        if (($m['type'] ?? '') !== 'Stock Out' || empty($m['productId']) || empty($m['date'])) {
            continue;
        }
        $month = substr($m['date'], 0, 7); // 'YYYY-MM'
        $pid   = $m['productId'];
        $byProduct[$pid][$month] = ($byProduct[$pid][$month] ?? 0) + (float) ($m['quantity'] ?? 0);
    }

    $upsert = $db->prepare(
        'INSERT INTO inventory_predictions
            (prediction_id, product_id, prediction_date, historical_quantity, predicted_quantity, demand_status, recommended_stock, accuracy_score)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
            prediction_date = VALUES(prediction_date),
            historical_quantity = VALUES(historical_quantity),
            predicted_quantity = VALUES(predicted_quantity),
            demand_status = VALUES(demand_status),
            recommended_stock = VALUES(recommended_stock),
            accuracy_score = VALUES(accuracy_score),
            created_at = CURRENT_TIMESTAMP'
    );

    $nextMonth = date('Y-m-01', strtotime('first day of next month'));
    $results   = [];

    foreach ($products as $product) {
        $pid = $product['id'] ?? null;
        if (!$pid) {
            continue;
        }

        $history = $byProduct[$pid] ?? [];
        ksort($history); // chronological order by 'YYYY-MM' key

        $quantities = array_values($history);
        $n = count($quantities);
        $x = $n > 0 ? range(0, $n - 1) : [];

        $historicalTotal = array_sum($quantities);
        $fit = LinearRegression::fit($x, $quantities);
        $predicted = $n > 0 ? max(0, LinearRegression::predict($fit['b0'], $fit['b1'], $n)) : 0;

        // Classify trend relative to the average historical demand,
        // ignoring small slopes that are just noise.
        $avg = $n > 0 ? $historicalTotal / $n : 0;
        $slopeThreshold = max(1, $avg * 0.05);

        if ($n < 2) {
            $trend = 'Stable';
        } elseif ($fit['b1'] > $slopeThreshold) {
            $trend = 'Increasing';
        } elseif ($fit['b1'] < -$slopeThreshold) {
            $trend = 'Decreasing';
        } else {
            $trend = 'Stable';
        }

        $reorderLevel = (float) ($product['reorderLevel'] ?? 10);
        // Recommended stock = predicted demand plus a 20% safety buffer,
        // never lower than the product's configured reorder level.
        $recommended = max($predicted * 1.2, $reorderLevel);
        $accuracy = round($fit['r2'] * 100, 2);

        $predictionId = generate_id('pred');
        $upsert->execute([
            $predictionId,
            $pid,
            $nextMonth,
            round($historicalTotal, 2),
            round($predicted, 2),
            $trend,
            round($recommended, 2),
            $accuracy,
        ]);

        $results[] = [
            'prediction_id'       => $predictionId,
            'product_id'          => $pid,
            'product_name'        => $product['name'] ?? 'Unknown Product',
            'sku'                 => $product['sku'] ?? '',
            'current_stock'       => total_stock($product['stock'] ?? 0),
            'reorder_level'       => $reorderLevel,
            'prediction_date'     => $nextMonth,
            'historical_quantity' => round($historicalTotal, 2),
            'predicted_quantity'  => round($predicted, 2),
            'demand_status'       => $trend,
            'recommended_stock'   => round($recommended, 2),
            'accuracy_score'      => $accuracy,
            'data_points'         => $n,
        ];
    }

    usort($results, fn($a, $b) => $b['predicted_quantity'] <=> $a['predicted_quantity']);

    return $results;
}

/**
 * Returns cached predictions enriched with current product info,
 * without re-running the model.
 */
function fetch_cached_predictions(PDO $db): array
{
    $rows = $db->query('SELECT * FROM inventory_predictions ORDER BY predicted_quantity DESC')->fetchAll();
    if (empty($rows)) {
        return [];
    }

    $products = [];
    foreach ($db->query('SELECT data FROM products')->fetchAll() as $r) {
        $p = json_decode($r['data'], true);
        if (!empty($p['id'])) {
            $products[$p['id']] = $p;
        }
    }

    $results = [];
    foreach ($rows as $row) {
        $product = $products[$row['product_id']] ?? null;
        $results[] = [
            'prediction_id'       => $row['prediction_id'],
            'product_id'          => $row['product_id'],
            'product_name'        => $product['name'] ?? 'Unknown Product',
            'sku'                 => $product['sku'] ?? '',
            'current_stock'       => total_stock($product['stock'] ?? 0),
            'reorder_level'       => (float) ($product['reorderLevel'] ?? 10),
            'prediction_date'     => $row['prediction_date'],
            'historical_quantity' => (float) $row['historical_quantity'],
            'predicted_quantity'  => (float) $row['predicted_quantity'],
            'demand_status'       => $row['demand_status'],
            'recommended_stock'   => (float) $row['recommended_stock'],
            'accuracy_score'      => (float) $row['accuracy_score'],
            'created_at'          => $row['created_at'],
        ];
    }

    return $results;
}

if ($method === 'POST' && $action === 'run') {
    $results = run_predictions($db);
    log_security_event('AI_PREDICTIONS_GENERATED', $user['id'], $user['username'], ['count' => count($results)]);
    json_response(['success' => true, 'data' => $results]);
}

if ($method === 'GET') {
    json_response(['success' => true, 'data' => fetch_cached_predictions($db)]);
}

json_error('Unsupported request.', 405);
