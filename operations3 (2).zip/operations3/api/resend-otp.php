<?php
require_once __DIR__ . '/../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$pendingUserId = $_SESSION['otp_pending_user_id'] ?? null;
if (!$pendingUserId) {
    json_error('No pending login. Please log in again.', 400);
}

$wait = otp_resend_wait_seconds($pendingUserId);
if ($wait > 0) {
    json_error("Please wait {$wait} second(s) before requesting another code.", 429);
}

$db = getDB();
$stmt = $db->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
$stmt->execute([$pendingUserId]);
$user = $stmt->fetch();

if (!$user) {
    unset($_SESSION['otp_pending_user_id']);
    json_error('Session expired. Please log in again.', 401);
}

$otpCode = generate_and_store_otp($user['id']);
$mailed  = send_otp_email($user['email'], $user['name'], $otpCode);
log_security_event('OTP_RESENT', $user['id'], $user['username'], ['mailed' => $mailed]);

$response = [
    'success'     => true,
    'maskedEmail' => mask_email($user['email']),
];

if (defined('OTP_DEMO_MODE') && OTP_DEMO_MODE === true) {
    $response['debugCode'] = $otpCode;
}

json_response($response);
