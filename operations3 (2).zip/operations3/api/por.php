<?php
/**
 * Proof of Receiving (POR) API
 * Comprehensive API for managing POR records and inventory updates
 * 
 * Workflow: PO → Receiving → Inspection → POR → Inventory Update
 */

require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

$currentUser = require_login_api();
$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];

// Get action from query string for GET requests, or from JSON body for POST requests
// IMPORTANT: Store input as php://input can only be read once
$jsonInput = null;
if ($method === 'POST' || $method === 'PUT' || $method === 'DELETE') {
    $jsonInput = get_json_input();
    $action = $jsonInput['action'] ?? $_GET['action'] ?? '';
} else {
    $action = $_GET['action'] ?? '';
}

// Role-based access control
$userRole = $currentUser['role'] ?? 'staff';
$canManage = $userRole === 'admin' || $userRole === 'manager';

try {
    switch ($method) {
        case 'GET':
            handleGet($db, $action, $currentUser);
            break;
        case 'POST':
            handlePost($db, $action, $currentUser, $jsonInput);
            break;
        case 'PUT':
            handlePut($db, $action, $currentUser, $jsonInput);
            break;
        case 'DELETE':
            handleDelete($db, $action, $currentUser, $jsonInput);
            break;
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

// ==========================================
// GET HANDLERS
// ==========================================

function handleGet($db, $action, $currentUser) {
    switch ($action) {
        case 'list':
            listPORs($db, $currentUser);
            break;
        case 'get':
        case 'details':
            getPORDetails($db, $_GET['id'] ?? '');
            break;
        case 'by-po':
            getPORsByPurchaseOrder($db, $_GET['poId'] ?? $_GET['po_id'] ?? '');
            break;
        case 'by-supplier':
            getPORsBySupplier($db, $_GET['supplierId'] ?? $_GET['supplier_id'] ?? '');
            break;
        case 'pending-inspection':
            getPendingInspectionPORs($db);
            break;
        case 'available_receivings':
            getAvailableReceivings($db);
            break;
        case 'summary':
            getPORSummary($db);
            break;
        case 'stats':
            getPORStats($db);
            break;
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
}

// ==========================================
// POST HANDLERS
// ==========================================

function handlePost($db, $action, $currentUser, $input = null) {
    // Store input globally so functions can access it
    global $cachedInput;
    $cachedInput = $input;
    
    switch ($action) {
        case 'create':
            createPOR($db, $currentUser);
            break;
        case 'create-from-receiving':
            createPORFromReceiving($db, $currentUser);
            break;
        case 'complete':
            completePOR($db, $currentUser);
            break;
        case 'upload-evidence':
            uploadEvidence($db, $currentUser);
            break;
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
}

// ==========================================
// PUT HANDLERS
// ==========================================

function handlePut($db, $action, $currentUser, $input = null) {
    // Store input globally so functions can access it
    global $cachedInput;
    $cachedInput = $input;
    
    switch ($action) {
        case 'update':
            updatePOR($db, $currentUser);
            break;
        case 'update-inspection':
            updateInspectionStatus($db, $currentUser);
            break;
        case 'archive':
            archivePOR($db, $currentUser);
            break;
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
}

// ==========================================
// DELETE HANDLERS
// ==========================================

function handleDelete($db, $action, $currentUser, $input = null) {
    global $canManage;
    global $cachedInput;
    $cachedInput = $input;
    
    if (!$canManage) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'Unauthorized']);
        return;
    }
    
    switch ($action) {
        case 'cancel':
            cancelPOR($db, $currentUser);
            break;
        case 'delete':
            deletePOR($db, $currentUser);
            break;
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
}

// ==========================================
// CORE FUNCTIONS
// ==========================================

/**
 * List all PORs with filters
 */
function listPORs($db, $currentUser) {
    $filters = [];
    $params = [];
    
    // Filter by status
    if (!empty($_GET['status'])) {
        $filters[] = "status = ?";
        $params[] = $_GET['status'];
    }
    
    // Filter by supplier
    if (!empty($_GET['supplierId'])) {
        $filters[] = "supplier_id = ?";
        $params[] = $_GET['supplierId'];
    }
    
    // Filter by date range
    if (!empty($_GET['dateFrom'])) {
        $filters[] = "receiving_date >= ?";
        $params[] = $_GET['dateFrom'];
    }
    if (!empty($_GET['dateTo'])) {
        $filters[] = "receiving_date <= ?";
        $params[] = $_GET['dateTo'] . ' 23:59:59';
    }
    
    $whereClause = !empty($filters) ? 'WHERE ' . implode(' AND ', $filters) : '';
    
    // Sort by newest first (most recent POR records on top)
    $query = "SELECT * FROM proof_of_receiving $whereClause 
              ORDER BY created_at DESC, receiving_date DESC";
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    
    $pors = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get items for each POR and resolve the REAL inspection status
    // (a blank/legacy stored value must never be shown as "Pending")
    foreach ($pors as &$por) {
        $por['items'] = getPORItems($db, $por['id']);
        $por = normalizePORRow($por);
        
        // Parse evidence files JSON
        if (!empty($por['evidence_files'])) {
            $por['evidence_files'] = json_decode($por['evidence_files'], true);
        } else {
            $por['evidence_files'] = [];
        }
    }
    unset($por);
    
    // Filters that depend on the resolved inspection status / free text
    $wantInspection = !empty($_GET['inspection_status'])
        ? normalize_por_inspection_status($_GET['inspection_status'])
        : null;
    $search = strtolower(trim($_GET['search'] ?? ''));
    if ($wantInspection !== null || $search !== '') {
        $pors = array_values(array_filter($pors, function ($por) use ($wantInspection, $search) {
            if ($wantInspection !== null && $por['inspection_status'] !== $wantInspection) {
                return false;
            }
            if ($search !== '') {
                $hay = strtolower(($por['por_number'] ?? '') . ' ' . ($por['po_number'] ?? '') . ' ' . ($por['supplier_name'] ?? ''));
                if (strpos($hay, $search) === false) {
                    return false;
                }
            }
            return true;
        }));
    }
    
    json_response([
        'success' => true,
        'data' => $pors,
        'count' => count($pors)
    ]);
}

/**
 * Get POR details by ID
 */
function getPORDetails($db, $porId) {
    if (empty($porId)) {
        json_error('POR ID required');
    }
    
    $stmt = $db->prepare("SELECT * FROM proof_of_receiving WHERE id = ?");
    $stmt->execute([$porId]);
    $por = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$por) {
        json_error('POR not found', 404);
    }
    
    // Get items + resolve real inspection status
    $por['items'] = getPORItems($db, $porId);
    $por = normalizePORRow($por);
    
    // Parse evidence files
    if (!empty($por['evidence_files'])) {
        $por['evidence_files'] = json_decode($por['evidence_files'], true);
    } else {
        $por['evidence_files'] = [];
    }
    
    // Get related PO data
    $por['purchase_order'] = getPurchaseOrderData($db, $por['purchase_order_id']);
    
    json_response([
        'success' => true,
        'data' => $por
    ]);
}

/**
 * Get POR items
 */
function getPORItems($db, $porId) {
    $stmt = $db->prepare("SELECT * FROM proof_of_receiving_items WHERE por_id = ? ORDER BY created_at");
    $stmt->execute([$porId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Get PORs by Purchase Order
 */
function getPORsByPurchaseOrder($db, $poId) {
    if (empty($poId)) {
        json_error('Purchase Order ID required');
    }
    
    $stmt = $db->prepare("SELECT * FROM proof_of_receiving WHERE purchase_order_id = ? ORDER BY receiving_date DESC");
    $stmt->execute([$poId]);
    $pors = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($pors as &$por) {
        $por['items'] = getPORItems($db, $por['id']);
        $por = normalizePORRow($por);
    }
    unset($por);
    
    json_response([
        'success' => true,
        'data' => $pors
    ]);
}

/**
 * Get PORs by Supplier
 */
function getPORsBySupplier($db, $supplierId) {
    if (empty($supplierId)) {
        json_error('Supplier ID required');
    }
    
    $stmt = $db->prepare("SELECT * FROM proof_of_receiving WHERE supplier_id = ? ORDER BY receiving_date DESC LIMIT 50");
    $stmt->execute([$supplierId]);
    $pors = array_map('normalizePORRow', $stmt->fetchAll(PDO::FETCH_ASSOC));
    
    json_response([
        'success' => true,
        'data' => $pors
    ]);
}

/**
 * Get pending inspection PORs
 */
function getPendingInspectionPORs($db) {
    $stmt = $db->query("
        SELECT * FROM proof_of_receiving 
        WHERE status <> 'Cancelled'
        ORDER BY receiving_date ASC
    ");
    $pors = [];
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $por) {
        $por = normalizePORRow($por);
        // Only genuinely awaiting inspection (resolved status, not the raw column)
        if (in_array($por['inspection_status'], ['Pending', 'In Progress'], true)) {
            $por['items'] = getPORItems($db, $por['id']);
            $pors[] = $por;
        }
    }
    
    json_response([
        'success' => true,
        'data' => $pors
    ]);
}

/**
 * Get POR summary statistics
 */
function getPORSummary($db) {
    $counts = countPORsByInspection($db);
    
    $stmt = $db->query("
        SELECT 
            COUNT(*) as total_pors,
            SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END) as completed,
            SUM(CASE WHEN status = 'Draft' THEN 1 ELSE 0 END) as draft,
            COALESCE(SUM(total_accepted), 0) as total_accepted_qty,
            COALESCE(SUM(total_rejected), 0) as total_rejected_qty,
            COALESCE(SUM(total_value), 0) as total_value
        FROM proof_of_receiving
        WHERE status <> 'Archived'
    ");
    $summary = $stmt->fetch(PDO::FETCH_ASSOC);
    $summary['pending_inspection'] = $counts['pending'];
    $summary['passed'] = $counts['passed'];
    $summary['partial'] = $counts['damaged'];
    $summary['failed'] = $counts['failed'];
    
    json_response([
        'success' => true,
        'data' => $summary
    ]);
}

/**
 * Count PORs per inspection status tab (uses the RESOLVED status so a
 * blank/legacy stored value is counted under its real result).
 */
function countPORsByInspection($db) {
    $counts = ['all' => 0, 'pending' => 0, 'passed' => 0, 'failed' => 0, 'damaged' => 0];
    $stmt = $db->query("
        SELECT status, inspection_status, total_received, total_accepted, total_rejected
        FROM proof_of_receiving
        WHERE status NOT IN ('Archived', 'Cancelled')
    ");
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $counts['all']++;
        switch (resolve_por_inspection_status($row)) {
            case 'Passed':  $counts['passed']++;  break;
            case 'Failed':  $counts['failed']++;  break;
            case 'Partial': $counts['damaged']++; break;
            default:        $counts['pending']++; break; // Pending / In Progress
        }
    }
    return $counts;
}

/**
 * Tab counts for the POR screen
 */
function getPORStats($db) {
    json_response([
        'success' => true,
        'data' => countPORsByInspection($db)
    ]);
}

/**
 * Create new POR manually
 */
function createPOR($db, $currentUser) {
    $input = get_json_input();
    
    // Validation
    validatePORInput($input);
    
    try {
        $db->beginTransaction();
        
        // Generate POR number
        $porNumber = generatePORNumber($db);
        $porId = generate_id('por');
        
        // Get PO data
        $poData = getPurchaseOrderData($db, $input['purchase_order_id']);
        if (!$poData) {
            throw new Exception('Purchase Order not found');
        }
        
        // Calculate totals
        $totals = calculatePORTotals($input['items']);
        
        // Insert POR record
        $stmt = $db->prepare("
            INSERT INTO proof_of_receiving (
                id, por_number, purchase_order_id, po_number, 
                supplier_id, supplier_name, received_by, received_by_name,
                receiving_date, receiving_time, inspection_status, status,
                total_items, total_ordered, total_received, total_accepted, total_rejected,
                total_value, inspection_notes, remarks
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $porId,
            $porNumber,
            $input['purchase_order_id'],
            $poData['poNumber'] ?? $input['po_number'] ?? '',
            $poData['supplierId'] ?? $input['supplier_id'] ?? '',
            $poData['supplierName'] ?? $poData['supplier_name'] ?? $input['supplier_name'] ?? '',
            $currentUser['id'],
            $currentUser['name'],
            $input['receiving_date'],
            $input['receiving_time'] ?? date('H:i:s'),
            normalize_por_inspection_status($input['inspection_status'] ?? '') ?? 'Pending',
            'Draft',
            count($input['items']),
            $totals['ordered'],
            $totals['received'],
            $totals['accepted'],
            $totals['rejected'],
            $totals['value'],
            $input['inspection_notes'] ?? null,
            $input['remarks'] ?? null
        ]);
        
        // Insert items
        insertPORItems($db, $porId, $input['items']);
        
        $db->commit();
        
        json_response([
            'success' => true,
            'data' => [
                'por_id' => $porId,
                'por_number' => $porNumber
            ],
            'message' => "POR $porNumber created successfully"
        ]);
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

/**
 * Create POR from existing receiving record
 */
function createPORFromReceiving($db, $currentUser) {
    $input = get_json_input();
    
    if (empty($input['receiving_id'])) {
        json_error('Receiving ID required');
    }
    
    try {
        $db->beginTransaction();
        
        // Get receiving data (from receivings table or JSON storage)
        $receivingData = getReceivingData($db, $input['receiving_id']);
        if (!$receivingData) {
            throw new Exception('Receiving record not found');
        }
        
        // Check if POR already exists for this receiving
        $checkStmt = $db->prepare("SELECT id FROM proof_of_receiving WHERE receiving_id = ?");
        $checkStmt->execute([$input['receiving_id']]);
        if ($checkStmt->fetch()) {
            throw new Exception('POR already exists for this receiving record');
        }
        
        // Generate POR number
        $porNumber = generatePORNumber($db);
        $porId = generate_id('por');
        
        // Calculate totals from receiving data
        $totals = calculateReceivingTotals($receivingData);
        
        // Insert POR record
        $stmt = $db->prepare("
            INSERT INTO proof_of_receiving (
                id, por_number, purchase_order_id, po_number, receiving_id,
                supplier_id, supplier_name, received_by, received_by_name,
                receiving_date, receiving_time, inspection_status, status,
                total_items, total_ordered, total_received, total_accepted, total_rejected,
                total_value, remarks
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $porId,
            $porNumber,
            $receivingData['poId'],
            $receivingData['poNumber'],
            $input['receiving_id'],
            $receivingData['supplierId'],
            $receivingData['supplierName'],
            $currentUser['id'],
            $currentUser['name'],
            $receivingData['receivedDate'] ?? date('Y-m-d H:i:s'),
            date('H:i:s', strtotime($receivingData['receivedDate'] ?? 'now')),
            'Pending',
            'Draft',
            count($receivingData['items'] ?? []),
            $totals['ordered'],
            $totals['received'],
            $totals['accepted'],
            $totals['rejected'],
            $totals['value'],
            $receivingData['remarks'] ?? null
        ]);
        
        // Convert receiving items to POR items format
        $porItems = convertReceivingItemsToPOR($receivingData['items'] ?? []);
        insertPORItems($db, $porId, $porItems);
        
        $db->commit();
        
        json_response([
            'success' => true,
            'data' => [
                'por_id' => $porId,
                'por_number' => $porNumber
            ],
            'message' => "POR $porNumber created from receiving record"
        ]);
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

/**
 * Complete POR and update inventory
 */
function completePOR($db, $currentUser) {
    global $canManage;
    
    if (!$canManage) {
        http_response_code(403);
        json_error('Only admin/manager can complete POR');
    }
    
    $input = get_json_input();
    $porId = $input['por_id'] ?? '';
    
    if (empty($porId)) {
        json_error('POR ID required');
    }
    
    try {
        $db->beginTransaction();
        
        // Get POR
        $stmt = $db->prepare("SELECT * FROM proof_of_receiving WHERE id = ?");
        $stmt->execute([$porId]);
        $por = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$por) {
            throw new Exception('POR not found');
        }
        
        if ($por['status'] === 'Completed') {
            throw new Exception('POR already completed');
        }
        
        if ($por['inventory_updated']) {
            throw new Exception('Inventory already updated for this POR');
        }
        
        // Get items
        $items = getPORItems($db, $porId);
        
        // Update inventory (ACCEPTED QUANTITY ONLY)
        updateInventoryFromPOR($db, $items, $por, $currentUser);
        
        // Keep the REAL inspection result (Passed/Partial/Failed). Older code
        // overwrote it with 'Completed', which the UI then showed as Pending.
        $finalInspection = normalize_por_inspection_status($por['inspection_status'] ?? '');
        if ($finalInspection === null || in_array($finalInspection, ['Pending', 'In Progress'], true)) {
            $finalInspection = derive_por_inspection_status(
                (float)$por['total_received'],
                (float)$por['total_accepted'],
                (float)$por['total_rejected']
            );
        }
        
        // Update POR status
        $updateStmt = $db->prepare("
            UPDATE proof_of_receiving 
            SET status = 'Completed',
                inspection_status = ?,
                inventory_updated = 1,
                inventory_updated_at = NOW(),
                completed_by = ?,
                completed_by_name = ?,
                completed_at = NOW(),
                updated_at = NOW()
            WHERE id = ?
        ");
        $updateStmt->execute([
            $finalInspection,
            $currentUser['id'],
            $currentUser['name'],
            $porId
        ]);
        
        // Log audit trail
        logAuditEvent($db, 'POR_COMPLETED', $currentUser, [
            'por_id' => $porId,
            'por_number' => $por['por_number'],
            'total_accepted' => $por['total_accepted']
        ]);
        
        $db->commit();
        
        json_response([
            'success' => true,
            'message' => "POR {$por['por_number']} completed and inventory updated"
        ]);
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

/**
 * Update POR
 */
function updatePOR($db, $currentUser) {
    $input = get_json_input();
    $porId = $input['por_id'] ?? '';
    
    if (empty($porId)) {
        json_error('POR ID required');
    }
    
    try {
        $db->beginTransaction();
        
        // Check if POR is completed
        $stmt = $db->prepare("SELECT status FROM proof_of_receiving WHERE id = ?");
        $stmt->execute([$porId]);
        $por = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$por) {
            throw new Exception('POR not found');
        }
        
        if ($por['status'] === 'Completed') {
            throw new Exception('Cannot edit completed POR');
        }
        
        // Update POR fields
        $updateFields = [];
        $params = [];
        
        if (isset($input['inspection_notes'])) {
            $updateFields[] = "inspection_notes = ?";
            $params[] = $input['inspection_notes'];
        }
        
        if (isset($input['remarks'])) {
            $updateFields[] = "remarks = ?";
            $params[] = $input['remarks'];
        }
        
        $explicitStatus = null;
        if (isset($input['inspection_status'])) {
            $explicitStatus = normalize_por_inspection_status($input['inspection_status']);
            if ($explicitStatus === null) {
                throw new Exception('Invalid inspection status: ' . $input['inspection_status']);
            }
            $updateFields[] = "inspection_status = ?";
            $params[] = $explicitStatus;
        }
        
        if (!empty($updateFields)) {
            $updateFields[] = "updated_at = NOW()";
            $params[] = $porId;
            
            $updateStmt = $db->prepare("
                UPDATE proof_of_receiving 
                SET " . implode(', ', $updateFields) . "
                WHERE id = ?
            ");
            $updateStmt->execute($params);
        }
        
        // Update items if provided
        if (isset($input['items'])) {
            updatePORItems($db, $porId, $input['items'], $explicitStatus === null);
        }
        
        $db->commit();
        
        json_response([
            'success' => true,
            'message' => 'POR updated successfully'
        ]);
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

/**
 * Cancel POR
 */
function cancelPOR($db, $currentUser) {
    $input = get_json_input();
    $porId = $input['por_id'] ?? '';
    $reason = $input['reason'] ?? '';
    
    if (empty($porId)) {
        json_error('POR ID required');
    }
    
    if (empty($reason)) {
        json_error('Cancellation reason required');
    }
    
    try {
        $db->beginTransaction();
        
        $stmt = $db->prepare("SELECT * FROM proof_of_receiving WHERE id = ?");
        $stmt->execute([$porId]);
        $por = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$por) {
            throw new Exception('POR not found');
        }
        
        if ($por['status'] === 'Completed') {
            throw new Exception('Cannot cancel completed POR');
        }
        
        if ($por['inventory_updated']) {
            throw new Exception('Cannot cancel POR - inventory already updated');
        }
        
        $updateStmt = $db->prepare("
            UPDATE proof_of_receiving 
            SET status = 'Cancelled',
                cancelled_by = ?,
                cancelled_by_name = ?,
                cancelled_at = NOW(),
                cancellation_reason = ?,
                updated_at = NOW()
            WHERE id = ?
        ");
        $updateStmt->execute([
            $currentUser['id'],
            $currentUser['name'],
            $reason,
            $porId
        ]);
        
        $db->commit();
        
        json_response([
            'success' => true,
            'message' => "POR {$por['por_number']} cancelled"
        ]);
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

/**
 * Delete POR (only for pending inspections)
 */
function deletePOR($db, $currentUser) {
    // Get ID from query string for DELETE requests
    $porId = $_GET['id'] ?? '';
    
    if (empty($porId)) {
        json_error('POR ID required');
    }
    
    try {
        $db->beginTransaction();
        
        // Check POR exists and can be deleted
        $stmt = $db->prepare("SELECT * FROM proof_of_receiving WHERE id = ?");
        $stmt->execute([$porId]);
        $por = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$por) {
            throw new Exception('POR not found');
        }
        
        // Only allow deletion of pending inspections
        if (!in_array(resolve_por_inspection_status($por), ['Pending', 'In Progress'], true)) {
            throw new Exception('Can only delete pending inspections');
        }
        
        if ($por['status'] === 'Completed' || $por['inventory_updated']) {
            throw new Exception('Cannot delete completed POR or POR with updated inventory');
        }
        
        // Delete POR items first
        $deleteItems = $db->prepare("DELETE FROM proof_of_receiving_items WHERE por_id = ?");
        $deleteItems->execute([$porId]);
        
        // Delete POR
        $deletePOR = $db->prepare("DELETE FROM proof_of_receiving WHERE id = ?");
        $deletePOR->execute([$porId]);
        
        // Log audit event
        logAuditEvent($db, 'POR_DELETED', $currentUser, [
            'por_id' => $porId,
            'por_number' => $por['por_number']
        ]);
        
        $db->commit();
        
        json_response([
            'success' => true,
            'message' => "POR {$por['por_number']} deleted successfully"
        ]);
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

// ==========================================
// HELPER FUNCTIONS
// ==========================================

/**
 * Generate POR number (POR-YYYY-NNNN)
 */
function generatePORNumber($db) {
    $year = date('Y');
    $stmt = $db->prepare("
        SELECT por_number FROM proof_of_receiving 
        WHERE por_number LIKE ? 
        ORDER BY por_number DESC 
        LIMIT 1
    ");
    $stmt->execute(["POR-$year-%"]);
    $result = $stmt->fetch();
    
    if ($result && preg_match("/POR-$year-(\d{4})/", $result['por_number'], $matches)) {
        $nextNum = intval($matches[1]) + 1;
    } else {
        $nextNum = 1;
    }
    
    return sprintf("POR-%s-%04d", $year, $nextNum);
}

/**
 * Validate POR input
 */
function validatePORInput($input) {
    if (empty($input['purchase_order_id'])) {
        json_error('Purchase Order ID required');
    }
    
    if (empty($input['receiving_date'])) {
        json_error('Receiving date required');
    }
    
    if (empty($input['items']) || !is_array($input['items'])) {
        json_error('Items required');
    }
    
    // Validate each item
    foreach ($input['items'] as $index => $item) {
        if (empty($item['product_id'])) {
            json_error("Item $index: Product ID required");
        }
        
        $received = floatval($item['received_quantity'] ?? 0);
        $accepted = floatval($item['accepted_quantity'] ?? 0);
        $rejected = floatval($item['rejected_quantity'] ?? 0);
        
        if ($received < 0 || $accepted < 0 || $rejected < 0) {
            json_error("Item $index: Quantities cannot be negative");
        }
        
        if ($accepted + $rejected > $received) {
            json_error("Item $index: Accepted + Rejected cannot exceed Received quantity");
        }
    }
}

/**
 * Calculate POR totals
 */
function calculatePORTotals($items) {
    $totals = [
        'ordered' => 0,
        'received' => 0,
        'accepted' => 0,
        'rejected' => 0,
        'value' => 0
    ];
    
    foreach ($items as $item) {
        $totals['ordered'] += floatval($item['ordered_quantity'] ?? 0);
        $totals['received'] += floatval($item['received_quantity'] ?? 0);
        $totals['accepted'] += floatval($item['accepted_quantity'] ?? 0);
        $totals['rejected'] += floatval($item['rejected_quantity'] ?? 0);
        $totals['value'] += floatval($item['accepted_quantity'] ?? 0) * floatval($item['unit_cost'] ?? 0);
    }
    
    return $totals;
}

/**
 * Insert POR items
 */
function insertPORItems($db, $porId, $items) {
    $stmt = $db->prepare("
        INSERT INTO proof_of_receiving_items (
            id, por_id, product_id, product_name, sku, unit,
            ordered_quantity, received_quantity, accepted_quantity, rejected_quantity,
            damaged_quantity, unit_cost, total_cost, batch_number, lot_number,
            expiration_date, manufacturing_date, inspection_result, 
            inspection_notes, rejection_reason, damage_type, remarks
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    foreach ($items as $item) {
        $itemId = generate_id('por_item');
        $accepted = floatval($item['accepted_quantity'] ?? 0);
        $unitCost = floatval($item['unit_cost'] ?? 0);
        
        $stmt->execute([
            $itemId,
            $porId,
            $item['product_id'],
            $item['product_name'],
            $item['sku'] ?? null,
            $item['unit'] ?? 'pcs',
            floatval($item['ordered_quantity'] ?? 0),
            floatval($item['received_quantity'] ?? 0),
            $accepted,
            floatval($item['rejected_quantity'] ?? 0),
            floatval($item['damaged_quantity'] ?? 0),
            $unitCost,
            $accepted * $unitCost,
            $item['batch_number'] ?? null,
            $item['lot_number'] ?? null,
            $item['expiration_date'] ?? null,
            $item['manufacturing_date'] ?? null,
            normalize_por_item_result($item['inspection_result'] ?? 'Pending'),
            $item['inspection_notes'] ?? null,
            $item['rejection_reason'] ?? null,
            $item['damage_type'] ?? null,
            $item['remarks'] ?? null
        ]);
    }
}

/**
 * Update inventory from POR (ACCEPTED QUANTITY ONLY)
 */
function updateInventoryFromPOR($db, $items, $por, $currentUser) {
    foreach ($items as $item) {
        $acceptedQty = floatval($item['accepted_quantity']);
        
        if ($acceptedQty <= 0) {
            continue; // Skip items with no accepted quantity
        }
        
        // Update product stock
        $stmt = $db->prepare("SELECT data FROM products WHERE id = ?");
        $stmt->execute([$item['product_id']]);
        $productResult = $stmt->fetch();
        
        if ($productResult) {
            $productData = json_decode($productResult['data'], true);
            $previousStock = floatval($productData['stock'] ?? 0);
            $newStock = $previousStock + $acceptedQty;
            
            $productData['stock'] = $newStock;
            $productData['status'] = porStockStatus($newStock);
            $productData['lastUpdated'] = date('Y-m-d\TH:i:s.v\Z');
            
            $updateStmt = $db->prepare("UPDATE products SET data = ? WHERE id = ?");
            $updateStmt->execute([json_encode($productData), $item['product_id']]);
            
            // Create inventory movement record
            $movementId = generate_id('inventory_movements');
            $movementData = [
                'id' => $movementId,
                'productId' => $item['product_id'],
                'productName' => $item['product_name'],
                'sku' => $item['sku'],
                'date' => date('Y-m-d\TH:i:s.v\Z'),
                'type' => 'Stock In',
                'referenceType' => 'POR',
                'referenceId' => $por['por_number'],
                'referencePO' => $por['po_number'],
                'quantity' => $acceptedQty,
                'previousBalance' => $previousStock,
                'newBalance' => $newStock,
                'change' => $acceptedQty,
                'reason' => 'Purchase Order Receiving (POR)',
                'notes' => "Accepted from {$por['supplier_name']} - POR: {$por['por_number']}",
                'user' => $currentUser['name'],
                'unitCost' => floatval($item['unit_cost'] ?? 0),
                'batchNumber' => $item['batch_number'],
                'expirationDate' => $item['expiration_date']
            ];
            
            $movementStmt = $db->prepare("INSERT INTO inventory_movements (id, data) VALUES (?, ?)");
            $movementStmt->execute([$movementId, json_encode($movementData)]);
        }
    }
}

/**
 * Get Purchase Order data
 */
function getPurchaseOrderData($db, $poId) {
    $stmt = $db->prepare("SELECT data FROM purchase_orders WHERE id = ?");
    $stmt->execute([$poId]);
    $result = $stmt->fetch();
    
    if ($result) {
        return json_decode($result['data'], true);
    }
    return null;
}

/**
 * Get Receiving data
 */
function getReceivingData($db, $receivingId) {
    $stmt = $db->prepare("SELECT data FROM receivings WHERE id = ?");
    $stmt->execute([$receivingId]);
    $result = $stmt->fetch();
    
    if ($result) {
        return json_decode($result['data'], true);
    }
    return null;
}

/**
 * Calculate totals from receiving data
 */
function calculateReceivingTotals($receivingData) {
    $totals = [
        'ordered' => 0,
        'received' => 0,
        'accepted' => 0,  // Will be same as received initially
        'rejected' => 0,   // Will be 0 initially
        'value' => 0
    ];
    
    foreach ($receivingData['items'] ?? [] as $item) {
        $orderedQty = floatval($item['quantityOrdered'] ?? $item['quantity'] ?? 0);
        $receivedQty = floatval($item['quantityDelivered'] ?? $item['received'] ?? $item['quantityReceived'] ?? 0);
        $unitCost = floatval($item['unitCost'] ?? $item['unit_cost'] ?? 0);
        
        $totals['ordered'] += $orderedQty;
        $totals['received'] += $receivedQty;
        // Initially, all received items are considered accepted (can be changed during inspection)
        $totals['accepted'] += $receivedQty;
        $totals['rejected'] += 0;
        $totals['value'] += $receivedQty * $unitCost;
    }
    
    return $totals;
}

/**
 * Convert receiving items to POR items format
 */
function convertReceivingItemsToPOR($receivingItems) {
    $porItems = [];
    
    foreach ($receivingItems as $item) {
        // Get the received quantity (actual quantity delivered)
        $receivedQty = floatval($item['quantityDelivered'] ?? $item['received'] ?? $item['quantityReceived'] ?? 0);
        
        $porItems[] = [
            'product_id' => $item['productId'] ?? $item['product_id'],
            'product_name' => $item['productName'] ?? $item['product_name'],
            'sku' => $item['sku'] ?? null,
            'unit' => $item['unit'] ?? 'pcs',
            'ordered_quantity' => floatval($item['quantityOrdered'] ?? $item['quantity'] ?? 0),
            'received_quantity' => $receivedQty,
            // IMPORTANT: Start with all received items as accepted (can be changed during inspection)
            'accepted_quantity' => $receivedQty,
            'rejected_quantity' => 0,
            'unit_cost' => floatval($item['unitCost'] ?? $item['unit_cost'] ?? 0),
            'inspection_result' => 'Pending',
            'inspection_notes' => null
        ];
    }
    
    return $porItems;
}

/**
 * Update POR items
 */
function updatePORItems($db, $porId, $items, $deriveStatus = false) {
    foreach ($items as $item) {
        if (!empty($item['id'])) {
            // Update existing item
            $stmt = $db->prepare("
                UPDATE proof_of_receiving_items 
                SET accepted_quantity = ?,
                    rejected_quantity = ?,
                    inspection_result = ?,
                    inspection_notes = ?,
                    updated_at = NOW()
                WHERE id = ? AND por_id = ?
            ");
            $stmt->execute([
                floatval($item['accepted_quantity'] ?? 0),
                floatval($item['rejected_quantity'] ?? 0),
                normalize_por_item_result($item['inspection_result'] ?? 'Pending'),
                $item['inspection_notes'] ?? null,
                $item['id'],
                $porId
            ]);
        }
    }
    
    // Recalculate totals
    $items = getPORItems($db, $porId);
    $totals = calculatePORTotals($items);
    
    $db->prepare("
        UPDATE proof_of_receiving 
        SET total_accepted = ?,
            total_rejected = ?,
            total_value = ?,
            updated_at = NOW()
        WHERE id = ?
    ")->execute([
        $totals['accepted'],
        $totals['rejected'],
        $totals['value'],
        $porId
    ]);
    
    // No explicit status chosen: derive it from the inspected items
    if ($deriveStatus) {
        $hasPendingItem = false;
        foreach ($items as $it) {
            if (normalize_por_item_result($it['inspection_result'] ?? '') === 'Pending') {
                $hasPendingItem = true;
                break;
            }
        }
        $newStatus = $hasPendingItem
            ? 'Pending'
            : derive_por_inspection_status($totals['received'], $totals['accepted'], $totals['rejected']);
        $db->prepare("UPDATE proof_of_receiving SET inspection_status = ? WHERE id = ?")
           ->execute([$newStatus, $porId]);
    }
}

/**
 * Upload evidence file
 */
function uploadEvidence($db, $currentUser) {
    if (!isset($_FILES['file'])) {
        json_error('No file uploaded');
    }
    
    $porId = $_POST['por_id'] ?? '';
    if (empty($porId)) {
        json_error('POR ID required');
    }
    
    $file = $_FILES['file'];
    $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'application/pdf'];
    $maxSize = 5 * 1024 * 1024; // 5MB
    
    if (!in_array($file['type'], $allowedTypes)) {
        json_error('Invalid file type. Only JPG, PNG, WEBP, PDF allowed');
    }
    
    if ($file['size'] > $maxSize) {
        json_error('File too large. Max 5MB');
    }
    
    $uploadDir = __DIR__ . '/../uploads/por-evidence/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = 'por_' . $porId . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $extension;
    $filepath = $uploadDir . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        $fileUrl = '/uploads/por-evidence/' . $filename;
        
        // Add to evidence_files JSON
        $stmt = $db->prepare("SELECT evidence_files FROM proof_of_receiving WHERE id = ?");
        $stmt->execute([$porId]);
        $result = $stmt->fetch();
        
        $evidenceFiles = json_decode($result['evidence_files'] ?? '[]', true);
        $evidenceFiles[] = [
            'filename' => $filename,
            'url' => $fileUrl,
            'type' => $file['type'],
            'uploaded_at' => date('Y-m-d H:i:s'),
            'uploaded_by' => $currentUser['name']
        ];
        
        $updateStmt = $db->prepare("UPDATE proof_of_receiving SET evidence_files = ? WHERE id = ?");
        $updateStmt->execute([json_encode($evidenceFiles), $porId]);
        
        json_response([
            'success' => true,
            'data' => [
                'filename' => $filename,
                'url' => $fileUrl
            ]
        ]);
    } else {
        json_error('Failed to save file');
    }
}

/**
 * Log audit event
 */
function logAuditEvent($db, $action, $user, $details) {
    // If security_logs table exists, use it
    try {
        // security_logs columns: event_type, user_id, username, details, ip_address
        $stmt = $db->prepare("
            INSERT INTO security_logs (event_type, user_id, username, details, ip_address, created_at)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $action,
            $user['id'] ?? null,
            $user['name'] ?? ($user['email'] ?? null),
            json_encode($details),
            $_SERVER['REMOTE_ADDR'] ?? null
        ]);
    } catch (Exception $e) {
        // Ignore if table doesn't exist
        error_log("Audit log failed: " . $e->getMessage());
    }
}

/**
 * Update inspection status
 */
function updateInspectionStatus($db, $currentUser) {
    $input = get_json_input();
    $porId = $input['por_id'] ?? '';
    $status = $input['inspection_status'] ?? '';
    
    if (empty($porId) || empty($status)) {
        json_error('POR ID and inspection status required');
    }
    
    $normalized = normalize_por_inspection_status($status);
    if ($normalized === null) {
        json_error('Invalid inspection status: ' . $status);
    }
    
    $stmt = $db->prepare("
        UPDATE proof_of_receiving 
        SET inspection_status = ?,
            updated_at = NOW()
        WHERE id = ?
    ");
    $stmt->execute([$normalized, $porId]);
    
    json_response([
        'success' => true,
        'message' => 'Inspection status updated'
    ]);
}


/**
 * Get available receivings for POR creation
 * Returns receivings that don't have a POR yet
 */
function getAvailableReceivings($db) {
    try {
        // Get all receivings that don't have a POR yet
        $stmt = $db->query("
            SELECT r.*
            FROM receivings r
            LEFT JOIN proof_of_receiving por ON por.receiving_id = r.id
            WHERE por.id IS NULL
            ORDER BY r.created_at DESC
        ");
        
        $receivings = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Parse JSON data and filter by status = 'Approved' or 'Completed'
        $formattedReceivings = [];
        foreach ($receivings as $r) {
            $data = json_decode($r['data'] ?? '{}', true);
            $status = $data['status'] ?? '';
            
            // Only include approved/completed receivings (ready for POR)
            if ($status === 'Approved' || $status === 'Completed') {
                $formattedReceivings[] = [
                    'id' => $r['id'],
                    'receiving_number' => $data['receivingNumber'] ?? $r['id'],
                    'po_number' => $data['poNumber'] ?? 'N/A',
                    'supplier' => $data['supplier'] ?? $data['supplierName'] ?? 'Unknown',
                    'received_date' => $data['receivedDate'] ?? $r['created_at'],
                    'status' => $status
                ];
            }
        }
        
        json_response([
            'success' => true,
            'data' => $formattedReceivings
        ]);
        
    } catch (Exception $e) {
        json_error('Failed to fetch available receivings: ' . $e->getMessage());
    }
}


/**
 * Archive a POR (soft delete, only for PORs still awaiting inspection).
 * The POR screen calls PUT api/por.php?action=archive&id=...
 */
function archivePOR($db, $currentUser) {
    global $canManage;
    if (!$canManage) {
        json_error('Only admin/manager can archive POR', 403);
    }
    
    $input = get_json_input();
    $porId = $_GET['id'] ?? $input['por_id'] ?? $input['id'] ?? '';
    if (empty($porId)) {
        json_error('POR ID required');
    }
    
    $stmt = $db->prepare("SELECT * FROM proof_of_receiving WHERE id = ?");
    $stmt->execute([$porId]);
    $por = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$por) {
        json_error('POR not found', 404);
    }
    if ($por['status'] === 'Archived') {
        json_error('POR is already archived');
    }
    if ($por['status'] === 'Completed' || $por['inventory_updated']) {
        json_error('Cannot archive a completed POR or one with updated inventory');
    }
    
    $db->prepare("UPDATE proof_of_receiving SET status = 'Archived', updated_at = NOW() WHERE id = ?")
       ->execute([$porId]);
    
    logAuditEvent($db, 'POR_ARCHIVED', $currentUser, [
        'por_id' => $porId,
        'por_number' => $por['por_number']
    ]);
    
    json_response([
        'success' => true,
        'message' => "POR {$por['por_number']} archived"
    ]);
}

/**
 * Attach the resolved (never-blank) inspection status to a POR row, and make
 * sure each item has a valid inspection_result.
 */
function normalizePORRow(array $por): array {
    $por['inspection_status'] = resolve_por_inspection_status($por);
    if (!empty($por['items']) && is_array($por['items'])) {
        foreach ($por['items'] as &$item) {
            $item['inspection_result'] = resolve_por_item_result($item);
        }
        unset($item);
    }
    return $por;
}

/**
 * Stock status label (same thresholds used by the receiving workflow)
 */
function porStockStatus($quantity) {
    if ($quantity <= 0) return 'Out of Stock';
    if ($quantity <= 20) return 'Low Stock';
    if ($quantity <= 100) return 'In Stock';
    return 'Overstock';
}
