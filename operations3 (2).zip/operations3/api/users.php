<?php
/**
 * Admin-only user account management.
 * Mirrors the findAll/create/update/delete interface used by
 * modules/settings/settings.js, backed by the real `users` table
 * with bcrypt password hashing (no plaintext or client-side hashing).
 */

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display errors directly, log them instead
ini_set('log_errors', 1);

// Define constant before try block
define('SAFE_USER_COLUMNS', 'id, name, email, username, role, verified, profile_picture AS profilePicture, created_at AS createdAt');

try {
    require_once __DIR__ . '/../includes/auth.php';

    $admin = require_admin_api();
    $db = getDB();
    $method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $id = $_GET['id'] ?? null;
        if ($id) {
            $stmt = $db->prepare("SELECT " . SAFE_USER_COLUMNS . " FROM users WHERE id = ?");
            $stmt->execute([$id]);
            json_response(['success' => true, 'data' => $stmt->fetch() ?: null]);
        } else {
            $stmt = $db->query("SELECT " . SAFE_USER_COLUMNS . " FROM users ORDER BY created_at ASC");
            json_response(['success' => true, 'data' => $stmt->fetchAll()]);
        }
        break;

    case 'POST':
        $input = get_json_input();
        $name     = trim($input['name'] ?? '');
        $email    = trim($input['email'] ?? '');
        $username = trim($input['username'] ?? '');
        $role     = in_array($input['role'] ?? '', ['admin', 'manager', 'staff'], true) ? $input['role'] : 'staff';
        $password = (string) ($input['password'] ?? '');

        if ($name === '' || $email === '' || $username === '' || $password === '') {
            json_error('Name, email, username, and password are all required.');
        }
        if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/', $password)) {
            json_error('Password must be 8+ characters and include uppercase, lowercase, and a number.');
        }

        $dupe = $db->prepare('SELECT id FROM users WHERE username = ? OR email = ?');
        $dupe->execute([$username, $email]);
        if ($dupe->fetch()) {
            json_error('That username or email is already registered.', 409);
        }

        $id = generate_id('user');
        $hash = password_hash($password, PASSWORD_BCRYPT);

        $stmt = $db->prepare(
            'INSERT INTO users (id, name, email, username, password_hash, role, verified) VALUES (?, ?, ?, ?, ?, ?, 1)'
        );
        $stmt->execute([$id, sanitize_recursive($name), $email, $username, $hash, $role]);

        log_security_event('USER_CREATED', $id, $username, ['createdBy' => $admin['username']]);

        json_response(['success' => true, 'data' => [
            'id' => $id, 'name' => $name, 'email' => $email, 'username' => $username,
            'role' => $role, 'verified' => true,
        ]], 201);
        break;

    case 'PUT':
    case 'PATCH':
        $id = $_GET['id'] ?? null;
        if (!$id) json_error('Missing id for update.');

        $existing = $db->prepare('SELECT * FROM users WHERE id = ?');
        $existing->execute([$id]);
        $existingUser = $existing->fetch();
        if (!$existingUser) json_error('User not found.', 404);

        $input = get_json_input();
        $name     = isset($input['name']) ? trim($input['name']) : $existingUser['name'];
        $email    = isset($input['email']) ? trim($input['email']) : $existingUser['email'];
        $username = isset($input['username']) ? trim($input['username']) : $existingUser['username'];
        $role     = in_array($input['role'] ?? '', ['admin', 'manager', 'staff'], true) ? $input['role'] : $existingUser['role'];
        $password = (string) ($input['password'] ?? '');

        if (($email !== $existingUser['email'] || $username !== $existingUser['username'])) {
            $dupe = $db->prepare('SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?');
            $dupe->execute([$username, $email, $id]);
            if ($dupe->fetch()) json_error('That username or email is already registered.', 409);
        }

        if ($password !== '') {
            if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/', $password)) {
                json_error('Password must be 8+ characters and include uppercase, lowercase, and a number.');
            }
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $db->prepare('UPDATE users SET name=?, email=?, username=?, role=?, password_hash=? WHERE id=?');
            $stmt->execute([sanitize_recursive($name), $email, $username, $role, $hash, $id]);
        } else {
            $stmt = $db->prepare('UPDATE users SET name=?, email=?, username=?, role=? WHERE id=?');
            $stmt->execute([sanitize_recursive($name), $email, $username, $role, $id]);
        }

        log_security_event('USER_UPDATED', $id, $username, ['updatedBy' => $admin['username']]);

        json_response(['success' => true, 'data' => [
            'id' => $id, 'name' => $name, 'email' => $email, 'username' => $username,
            'role' => $role, 'verified' => (bool) $existingUser['verified'],
        ]]);
        break;

    case 'DELETE':
        $id = $_GET['id'] ?? null;
        if (!$id) json_error('Missing id for delete.');
        if ($id === $admin['id']) json_error('You cannot delete your own account.', 400);

        $stmt = $db->prepare('DELETE FROM users WHERE id = ?');
        $stmt->execute([$id]);
        if ($stmt->rowCount() === 0) json_error('User not found.', 404);

        log_security_event('USER_DELETED', $id, null, ['deletedBy' => $admin['username']]);
        json_response(['success' => true]);
        break;

    default:
        json_error('Method not allowed.', 405);
}

} catch (Exception $e) {
    error_log('Users API Error: ' . $e->getMessage() . ' in ' . $e->getFile() . ' line ' . $e->getLine());
    json_error('An error occurred: ' . $e->getMessage(), 500);
}
