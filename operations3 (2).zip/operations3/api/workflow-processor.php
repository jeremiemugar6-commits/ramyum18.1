<?php
/**
 * ========================================================================
 * RAM-YUM COMPLETE OPERATIONAL WORKFLOW PROCESSOR
 * ========================================================================
 * 
 * This script handles the complete end-to-end workflow for:
 * - Purchase Order Creation & Approval
 * - Receiving & Inspection
 * - Proof of Receiving & Stock Increment  
 * - Stock Transfers with Photo Verification
 * - Comprehensive Audit Logging
 * 
 * All operations use SQL Transactions to ensure data integrity.
 * All inputs are sanitized using prepared statements.
 * 
 * @author RAM-YUM Development Team
 * @version 2.0
 */

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

// Require authentication for all operations
$currentUser = require_login_api();
$db = getDB();

$method = $_SERVER['REQUEST_METHOD'];

// Read action from GET or POST body
if ($method === 'POST' || $method === 'PUT') {
    $input = get_json_input();
    $action = $input['action'] ?? $_GET['action'] ?? '';
} else {
    $action = $_GET['action'] ?? '';
}

try {
    switch ($method) {
        case 'POST':
            handlePost($db, $action, $currentUser);
            break;
        case 'PUT':
            handlePut($db, $action, $currentUser);
            break;
        case 'GET':
            handleGet($db, $action, $currentUser);
            break;
        default:
            http_response_code(405);
            json_error('Method not allowed');
    }
} catch (Exception $e) {
    http_response_code(500);
    error_log("Workflow processor error: " . $e->getMessage() . "\n" . $e->getTraceAsString());
    json_error($e->getMessage());
}

// ========================================================================
// HANDLER FUNCTIONS
// ========================================================================

function handlePost($db, $action, $currentUser) {
    switch ($action) {
        case 'create_purchase_order':
            createPurchaseOrder($db, $currentUser);
            break;
        case 'approve_purchase_order':
            approvePurchaseOrder($db, $currentUser);
            break;
        case 'receive_items':
            receiveItems($db, $currentUser);
            break;
        case 'receive_and_inspect_items':
            receiveAndInspectItems($db, $currentUser);
            break;
        case 'create_por_with_stock_update':
            createPORWithStockUpdate($db, $currentUser);
            break;
        case 'create_stock_transfer':
            createStockTransfer($db, $currentUser);
            break;
        case 'verify_transfer_arrival':
            verifyTransferArrival($db, $currentUser);
            break;
        default:
            http_response_code(400);
            json_error('Invalid action: ' . $action);
    }
}

function handlePut($db, $action, $currentUser) {
    switch ($action) {
        case 'update_inspection':
            updateInspection($db, $currentUser);
            break;
        default:
            http_response_code(400);
            json_error('Invalid action: ' . $action);
    }
}

function handleGet($db, $action, $currentUser) {
    switch ($action) {
        case 'pending_deliveries':
            getPendingDeliveries($db);
            break;
        case 'audit_trail':
            getAuditTrail($db);
            break;
        default:
            http_response_code(400);
            json_error('Invalid action: ' . $action);
    }
}

// ========================================================================
// STEP 1: PURCHASE ORDER CREATION & APPROVAL
// ========================================================================

/**
 * Create Purchase Order with automatic price fetching
 * Status: Initially set to 'Pending' (Awaiting approval)
 */
function createPurchaseOrder($db, $currentUser) {
    $input = get_json_input();
    
    // Validate required fields
    if (empty($input['supplier_id']) || empty($input['items']) || !is_array($input['items'])) {
        json_error('Supplier and items are required');
    }
    
    try {
        // START TRANSACTION
        $db->beginTransaction();
        
        // Get supplier details
        $stmt = $db->prepare("SELECT * FROM suppliers WHERE id = ?");
        $stmt->execute([$input['supplier_id']]);
        $supplierRow = $stmt->fetch();
        
        if (!$supplierRow) {
            throw new Exception('Supplier not found');
        }
        
        $supplierData = json_decode($supplierRow['data'], true);
        
        // Generate PO Number
        $poNumber = generatePONumber($db);
        $poId = generate_id('po');
        
        // Process items and fetch prices automatically
        $items = [];
        $subtotal = 0;
        
        foreach ($input['items'] as $item) {
            if (empty($item['product_id']) || empty($item['quantity'])) {
                throw new Exception('Product ID and quantity are required for all items');
            }
            
            // Fetch product details and automatic price
            $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
            $stmt->execute([$item['product_id']]);
            $productRow = $stmt->fetch();
            
            if (!$productRow) {
                throw new Exception("Product not found: {$item['product_id']}");
            }
            
            $productData = json_decode($productRow['data'], true);
            
            // Use provided unit cost or fetch from product
            $unitCost = isset($item['unit_cost']) ? floatval($item['unit_cost']) : floatval($productData['price'] ?? 0);
            $quantity = floatval($item['quantity']);
            $itemTotal = $unitCost * $quantity;
            
            $items[] = [
                'productId' => $item['product_id'],
                'productName' => $productData['productName'] ?? $productData['name'] ?? 'Unknown',
                'sku' => $productData['sku'] ?? '',
                'quantity' => $quantity,
                'unitCost' => $unitCost,
                'subtotal' => $itemTotal,
                'receivedQuantity' => 0,
                'remainingQuantity' => $quantity
            ];
            
            $subtotal += $itemTotal;
        }
        
        // Create PO data
        $poData = [
            'id' => $poId,
            'poNumber' => $poNumber,
            'supplier_name' => $supplierData['company'] ?? $supplierData['name'] ?? 'Unknown',
            'supplierId' => $input['supplier_id'],
            'items' => $items,
            'subtotal' => $subtotal,
            'total' => $subtotal,
            'orderDate' => date('Y-m-d\TH:i:s.v\Z'),
            'expectedDate' => $input['expected_date'] ?? null,
            'status' => 'Pending', // INITIAL STATUS: Awaiting Approval
            'notes' => $input['notes'] ?? '',
            'createdBy' => $currentUser['name'],
            'totalItems' => array_sum(array_column($items, 'quantity')),
            'receivedItems' => 0,
            'remainingItems' => array_sum(array_column($items, 'quantity'))
        ];
        
        // Insert into database
        $stmt = $db->prepare("INSERT INTO purchase_orders (id, data, created_at, updated_at) VALUES (?, ?, NOW(), NOW())");
        $stmt->execute([$poId, json_encode($poData)]);
        
        // LOG AUDIT TRAIL
        logAuditEvent($db, 'PO_CREATED', $currentUser, [
            'po_id' => $poId,
            'po_number' => $poNumber,
            'supplier' => $poData['supplier_name'],
            'total' => $subtotal,
            'status' => 'Pending'
        ]);
        
        // COMMIT TRANSACTION
        $db->commit();
        
        json_response([
            'success' => true,
            'message' => "Purchase Order {$poNumber} created successfully and awaiting approval",
            'data' => [
                'po_id' => $poId,
                'po_number' => $poNumber,
                'status' => 'Pending'
            ]
        ]);
        
    } catch (Exception $e) {
        // ROLLBACK ON ERROR
        $db->rollBack();
        throw $e;
    }
}

/**
 * Approve Purchase Order
 * Transition: 'Pending' → 'Approved' (Ready to receive)
 * Authorization: Admin or Manager only
 */
function approvePurchaseOrder($db, $currentUser) {
    $userRole = $currentUser['role'] ?? 'staff';
    if (!in_array($userRole, ['admin', 'manager'])) {
        json_error('Only admin or manager can approve purchase orders', 403);
    }
    
    $input = get_json_input();
    
    if (empty($input['po_id'])) {
        json_error('Purchase Order ID is required');
    }
    
    try {
        // START TRANSACTION
        $db->beginTransaction();
        
        // Get PO
        $stmt = $db->prepare("SELECT * FROM purchase_orders WHERE id = ?");
        $stmt->execute([$input['po_id']]);
        $poRow = $stmt->fetch();
        
        if (!$poRow) {
            throw new Exception('Purchase Order not found');
        }
        
        $poData = json_decode($poRow['data'], true);
        
        // Validate status
        if ($poData['status'] !== 'Pending') {
            throw new Exception("Cannot approve PO with status: {$poData['status']}");
        }
        
        // Update status to Approved
        $poData['status'] = 'Approved';
        $poData['approvedBy'] = $currentUser['name'];
        $poData['approvedAt'] = date('Y-m-d\TH:i:s.v\Z');
        
        // Update in database
        $stmt = $db->prepare("UPDATE purchase_orders SET data = ?, updated_at = NOW() WHERE id = ?");
        $stmt->execute([json_encode($poData), $input['po_id']]);
        
        // LOG AUDIT TRAIL
        logAuditEvent($db, 'PO_APPROVED', $currentUser, [
            'po_id' => $input['po_id'],
            'po_number' => $poData['poNumber'],
            'approved_by' => $currentUser['name']
        ]);
        
        // COMMIT TRANSACTION
        $db->commit();
        
        json_response([
            'success' => true,
            'message' => "Purchase Order {$poData['poNumber']} approved successfully. It now appears in Pending Deliveries.",
            'data' => [
                'po_number' => $poData['poNumber'],
                'status' => 'Approved'
            ]
        ]);
        
    } catch (Exception $e) {
        // ROLLBACK ON ERROR
        $db->rollBack();
        throw $e;
    }
}

// ========================================================================
// STEP 2: COMBINED RECEIVING & INSPECTION (Single Operation)
// ========================================================================

/**
 * Get list of approved POs ready for receiving (Pending Deliveries)
 */
function getPendingDeliveries($db) {
    try {
        $stmt = $db->query("SELECT * FROM purchase_orders ORDER BY created_at DESC");
        $allPOs = $stmt->fetchAll();
        
        $pendingDeliveries = [];
        
        foreach ($allPOs as $row) {
            $poData = json_decode($row['data'], true);
            
            // Only include Approved POs
            if ($poData['status'] === 'Approved') {
                $pendingDeliveries[] = [
                    'id' => $row['id'],
                    'poNumber' => $poData['poNumber'],
                    'supplier' => $poData['supplier_name'] ?? 'Unknown',
                    'orderDate' => $poData['orderDate'],
                    'expectedDate' => $poData['expectedDate'] ?? null,
                    'totalItems' => $poData['totalItems'],
                    'total' => $poData['total'],
                    'items' => $poData['items']
                ];
            }
        }
        
        json_response([
            'success' => true,
            'data' => $pendingDeliveries
        ]);
        
    } catch (Exception $e) {
        throw $e;
    }
}

/**
 * COMBINED: Receive & Inspect Items with Immediate Stock Update
 * 
 * This single operation handles:
 * 1. Physical inspection of delivered items
 * 2. Recording accepted vs rejected quantities
 * 3. Creating Proof of Receiving (POR)
 * 4. AUTOMATIC inventory stock increment (accepted items only)
 * 5. Comprehensive audit logging
 * 
 * Flow: User inspects items → Records accepted/rejected → Submits → Stock updated immediately
 */
function receiveAndInspectItems($db, $currentUser) {
    $input = get_json_input();
    
    $poId = $input['purchase_order_id'] ?? $input['po_id'] ?? '';
    
    if (empty($poId) || empty($input['items'])) {
        json_error('Purchase order ID and items are required');
    }
    
    try {
        // START TRANSACTION - CRITICAL SECTION
        $db->beginTransaction();
        
        // Get PO
        $stmt = $db->prepare("SELECT * FROM purchase_orders WHERE id = ?");
        $stmt->execute([$poId]);
        $poRow = $stmt->fetch();
        
        if (!$poRow) {
            throw new Exception('Purchase Order not found');
        }
        
        $poData = json_decode($poRow['data'], true);
        
        if ($poData['status'] !== 'Approved') {
            throw new Exception('Only approved POs can be received');
        }
        
        // Generate sequential numbers
        $receivingNumber = generateReceivingNumber($db);
        $porNumber = generatePORNumber($db);
        $receivingId = generate_id('receiving');
        $porId = generate_id('por');
        
        // Process inspection results
        $receivedItems = [];
        $porItems = [];
        $totalOrdered = 0;
        $totalReceived = 0;
        $totalAccepted = 0;
        $totalRejected = 0;
        $totalValue = 0;
        
        foreach ($input['items'] as $item) {
            // Extract quantities
            $orderedQty = floatval($item['ordered_quantity']);
            $receivedQty = floatval($item['received_quantity'] ?? 0);
            $acceptedQty = floatval($item['accepted_quantity'] ?? $receivedQty);
            $rejectedQty = floatval($item['rejected_quantity'] ?? 0);
            $damagedQty = floatval($item['damaged_quantity'] ?? 0);
            $unitCost = floatval($item['unit_cost'] ?? 0);
            
            // Validate: accepted + rejected + damaged should equal received
            if (($acceptedQty + $rejectedQty + $damagedQty) != $receivedQty) {
                throw new Exception("Item {$item['product_name']}: Accepted + Rejected + Damaged must equal Received quantity");
            }
            
            // Canonical item result (Passed/Failed/Partial/Conditional/Pending).
            // If the form did not send one, derive it from the quantities.
            $itemResult = !empty($item['inspection_result'])
                ? normalize_por_item_result($item['inspection_result'])
                : derive_por_item_result([
                    'received_quantity' => $receivedQty,
                    'accepted_quantity' => $acceptedQty,
                    'rejected_quantity' => $rejectedQty
                ]);
            
            // Receiving record item
            $receivedItems[] = [
                'product_id' => $item['product_id'],
                'product_name' => $item['product_name'],
                'sku' => $item['sku'] ?? '',
                'ordered_quantity' => $orderedQty,
                'received_quantity' => $receivedQty,
                'accepted_quantity' => $acceptedQty,
                'rejected_quantity' => $rejectedQty,
                'damaged_quantity' => $damagedQty,
                'unit_cost' => $unitCost,
                'subtotal' => $acceptedQty * $unitCost,
                'inspection_result' => $itemResult,
                'inspection_notes' => $item['inspection_notes'] ?? '',
                'rejection_reason' => $item['rejection_reason'] ?? null,
                'damage_type' => $item['damage_type'] ?? null
            ];
            
            // Collect POR item data (will be inserted AFTER parent POR record)
            $porItems[] = [
                'id' => generate_id('por_item'),
                'product_id' => $item['product_id'],
                'product_name' => $item['product_name'],
                'sku' => $item['sku'] ?? '',
                'unit' => $item['unit'] ?? 'pcs',
                'ordered_quantity' => $orderedQty,
                'received_quantity' => $receivedQty,
                'accepted_quantity' => $acceptedQty,
                'rejected_quantity' => $rejectedQty,
                'damaged_quantity' => $damagedQty,
                'unit_cost' => $unitCost,
                'total_cost' => $acceptedQty * $unitCost,
                'inspection_result' => $itemResult,
                'inspection_notes' => $item['inspection_notes'] ?? null,
                'rejection_reason' => $item['rejection_reason'] ?? null,
                'damage_type' => $item['damage_type'] ?? null,
                'remarks' => $item['remarks'] ?? null,
                'batch_number' => $item['batch_number'] ?? null,
                'lot_number' => $item['lot_number'] ?? null,
                'expiration_date' => $item['expiration_date'] ?? null,
                'manufacturing_date' => $item['manufacturing_date'] ?? null
            ];
            
            // ===== AUTOMATIC STOCK INCREMENT (ACCEPTED ITEMS ONLY) =====
            if ($acceptedQty > 0) {
                // Get product
                $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
                $stmt->execute([$item['product_id']]);
                $productRow = $stmt->fetch();
                
                if ($productRow) {
                    $productData = json_decode($productRow['data'], true);
                    $previousStock = floatval($productData['stock'] ?? 0);
                    $newStock = $previousStock + $acceptedQty;
                    
                    // Update stock count and status
                    $productData['stock'] = $newStock;
                    $productData['status'] = calculateStockStatus($newStock);
                    $productData['lastUpdated'] = date('Y-m-d\TH:i:s.v\Z');
                    
                    $stmt = $db->prepare("UPDATE products SET data = ?, updated_at = NOW() WHERE id = ?");
                    $stmt->execute([json_encode($productData), $item['product_id']]);
                    
                    // Create inventory movement log
                    $movementId = generate_id('inventory_movement');
                    $movementData = [
                        'id' => $movementId,
                        'productId' => $item['product_id'],
                        'productName' => $item['product_name'],
                        'sku' => $item['sku'] ?? '',
                        'date' => date('Y-m-d\TH:i:s.v\Z'),
                        'type' => 'Stock In',
                        'referenceType' => 'POR',
                        'referenceId' => $porNumber,
                        'referencePO' => $poData['poNumber'],
                        'quantity' => $acceptedQty,
                        'previousBalance' => $previousStock,
                        'newBalance' => $newStock,
                        'change' => $acceptedQty,
                        'reason' => 'Purchase Order Receiving - Inspected & Accepted',
                        'notes' => "Supplier: {$poData['supplier_name']} | Rejected: {$rejectedQty} | Damaged: {$damagedQty}",
                        'user' => $currentUser['name'],
                        'unitCost' => $unitCost,
                        'batchNumber' => $item['batch_number'] ?? null,
                        'expirationDate' => $item['expiration_date'] ?? null
                    ];
                    
                    $stmt = $db->prepare("INSERT INTO inventory_movements (id, data, created_at, updated_at) VALUES (?, ?, NOW(), NOW())");
                    $stmt->execute([$movementId, json_encode($movementData)]);
                }
            }
            
            $totalOrdered += $orderedQty;
            $totalReceived += $receivedQty;
            $totalAccepted += $acceptedQty;
            $totalRejected += $rejectedQty;
            $totalValue += $acceptedQty * $unitCost;
        }
        
        // Determine inspection status (canonical: Pending | Passed | Partial | Failed)
        $inspectionStatus = derive_por_inspection_status($totalReceived, $totalAccepted, $totalRejected);
        
        // Create receiving record (historical record)
        $receivingData = [
            'id' => $receivingId,
            'receivingNumber' => $receivingNumber,
            'poId' => $poId,
            'poNumber' => $poData['poNumber'],
            'supplierId' => $poData['supplierId'],
            'supplier' => $poData['supplier_name'],
            'supplierName' => $poData['supplier_name'],
            'receivedDate' => date('Y-m-d\TH:i:s.v\Z'),
            'receivedBy' => $currentUser['name'],
            'totalReceived' => $totalReceived,
            'totalAccepted' => $totalAccepted,
            'totalRejected' => $totalRejected,
            'totalValue' => $totalValue,
            'items' => $receivedItems,
            'inspectionStatus' => $inspectionStatus,
            'notes' => $input['notes'] ?? '',
            'status' => 'Completed',
            'porNumber' => $porNumber // Link to POR
        ];
        
        $stmt = $db->prepare("INSERT INTO receivings (id, data, created_at, updated_at) VALUES (?, ?, NOW(), NOW())");
        $stmt->execute([$receivingId, json_encode($receivingData)]);
        
        // Create POR record
        $stmt = $db->prepare("
            INSERT INTO proof_of_receiving (
                id, por_number, purchase_order_id, po_number, receiving_id,
                supplier_id, supplier_name, received_by, received_by_name,
                receiving_date, receiving_time, inspection_status, status,
                total_items, total_ordered, total_received, total_accepted, total_rejected,
                total_value, inspection_notes, remarks,
                inventory_updated, inventory_updated_at,
                completed_by, completed_by_name, completed_at,
                created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ");
        
        $stmt->execute([
            $porId,
            $porNumber,
            $poId,
            $poData['poNumber'],
            $receivingId,
            $poData['supplierId'],
            $poData['supplier_name'],
            $currentUser['id'],
            $currentUser['name'],
            date('Y-m-d H:i:s'),
            date('H:i:s'),
            $inspectionStatus,
            'Completed', // Immediately completed since inspection done
            count($receivedItems),
            $totalOrdered,
            $totalReceived,
            $totalAccepted,
            $totalRejected,
            $totalValue,
            $input['inspection_notes'] ?? null,
            $input['remarks'] ?? null,
            1, // Inventory updated
            date('Y-m-d H:i:s'),
            $currentUser['id'],
            $currentUser['name'],
            date('Y-m-d H:i:s')
        ]);
        
        // NOW insert POR items (after parent record exists)
        $porItemStmt = $db->prepare("
            INSERT INTO proof_of_receiving_items (
                id, por_id, product_id, product_name, sku, unit,
                ordered_quantity, received_quantity, accepted_quantity, 
                rejected_quantity, damaged_quantity,
                unit_cost, total_cost, 
                inspection_result, inspection_notes, 
                rejection_reason, damage_type, remarks,
                batch_number, lot_number, expiration_date, manufacturing_date,
                created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ");
        
        foreach ($porItems as $porItem) {
            $porItemStmt->execute([
                $porItem['id'],
                $porId,
                $porItem['product_id'],
                $porItem['product_name'],
                $porItem['sku'],
                $porItem['unit'],
                $porItem['ordered_quantity'],
                $porItem['received_quantity'],
                $porItem['accepted_quantity'],
                $porItem['rejected_quantity'],
                $porItem['damaged_quantity'],
                $porItem['unit_cost'],
                $porItem['total_cost'],
                $porItem['inspection_result'],
                $porItem['inspection_notes'],
                $porItem['rejection_reason'],
                $porItem['damage_type'],
                $porItem['remarks'],
                $porItem['batch_number'],
                $porItem['lot_number'],
                $porItem['expiration_date'],
                $porItem['manufacturing_date']
            ]);
        }
        
        // Update PO status
        $poData['status'] = 'Received';
        $poData['receivedItems'] = $totalAccepted;
        $poData['receivedDate'] = date('Y-m-d\TH:i:s.v\Z');
        
        $stmt = $db->prepare("UPDATE purchase_orders SET data = ?, updated_at = NOW() WHERE id = ?");
        $stmt->execute([json_encode($poData), $poId]);
        
        // LOG COMPREHENSIVE AUDIT TRAIL
        logAuditEvent($db, 'ITEMS_RECEIVED_AND_INSPECTED', $currentUser, [
            'receiving_number' => $receivingNumber,
            'por_number' => $porNumber,
            'po_number' => $poData['poNumber'],
            'total_ordered' => $totalOrdered,
            'total_received' => $totalReceived,
            'total_accepted' => $totalAccepted,
            'total_rejected' => $totalRejected,
            'inspection_status' => $inspectionStatus,
            'inventory_updated' => true
        ]);
        
        // COMMIT TRANSACTION
        $db->commit();
        
        // Prepare success message
        $message = "Items received and inspected successfully!";
        $message .= "\nReceiving #: {$receivingNumber}";
        $message .= "\nProof of Receiving #: {$porNumber}";
        $message .= "\nAccepted: {$totalAccepted} items added to inventory";
        if ($totalRejected > 0) {
            $message .= "\nRejected: {$totalRejected} items (not added to inventory)";
        }
        
        json_response([
            'success' => true,
            'message' => $message,
            'data' => [
                'receiving_id' => $receivingId,
                'receiving_number' => $receivingNumber,
                'por_id' => $porId,
                'por_number' => $porNumber,
                'po_number' => $poData['poNumber'],
                'po_status' => $poData['status'],
                'inspection_status' => $inspectionStatus,
                'total_received' => $totalReceived,
                'total_accepted' => $totalAccepted,
                'total_rejected' => $totalRejected,
                'total_damaged' => ($totalReceived - $totalAccepted - $totalRejected),
                'inventory_updated' => true,
                'inspection_results' => $receivedItems
            ]
        ]);
        
    } catch (Exception $e) {
        // ROLLBACK ON ERROR - Prevents partial inventory updates
        $db->rollBack();
        throw $e;
    }
}

// ========================================================================
// STEP 3: PROOF OF RECEIVING MANAGEMENT (View/Edit only)
// ========================================================================

/**
 * Update inspection results (if corrections needed)
 * This is rarely used - only for corrections after initial inspection
 */
function updateInspection($db, $currentUser) {
    $input = get_json_input();
    
    if (empty($input['por_id'])) {
        json_error('POR ID is required');
    }
    
    try {
        $db->beginTransaction();
        
        // Get POR
        $stmt = $db->prepare("SELECT * FROM proof_of_receiving WHERE id = ?");
        $stmt->execute([$input['por_id']]);
        $por = $stmt->fetch();
        
        if (!$por) {
            throw new Exception('POR not found');
        }
        
        if ($por['status'] === 'Cancelled') {
            throw new Exception('Cannot update cancelled POR');
        }
        
        // Update inspection notes only (stock already updated during initial receive)
        $stmt = $db->prepare("
            UPDATE proof_of_receiving 
            SET inspection_notes = ?, remarks = ?, updated_at = NOW()
            WHERE id = ?
        ");
        
        $stmt->execute([
            $input['inspection_notes'] ?? $por['inspection_notes'],
            $input['remarks'] ?? $por['remarks'],
            $input['por_id']
        ]);
        
        logAuditEvent($db, 'POR_UPDATED', $currentUser, [
            'por_id' => $input['por_id'],
            'por_number' => $por['por_number']
        ]);
        
        $db->commit();
        
        json_response([
            'success' => true,
            'message' => 'Inspection notes updated successfully'
        ]);
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

// ========================================================================
// STEP 4: STOCK TRANSFER WITH PHOTO VERIFICATION
// ========================================================================

/**
 * Create Stock Transfer with validation
 */
function createStockTransfer($db, $currentUser) {
    $input = get_json_input();
    
    if (empty($input['source_location']) || empty($input['destination_location']) || empty($input['items'])) {
        json_error('Source, destination, and items are required');
    }
    
    try {
        // START TRANSACTION
        $db->beginTransaction();
        
        // Generate transfer number
        $transferNumber = generateTransferNumber($db);
        $transferId = generate_id('transfer');
        
        // Validate stock availability at source
        foreach ($input['items'] as $item) {
            if (empty($item['product_id']) || empty($item['quantity'])) {
                throw new Exception('Product ID and quantity required for all items');
            }
            
            // Get product current stock
            $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
            $stmt->execute([$item['product_id']]);
            $productRow = $stmt->fetch();
            
            if (!$productRow) {
                throw new Exception("Product not found: {$item['product_id']}");
            }
            
            $productData = json_decode($productRow['data'], true);
            $currentStock = floatval($productData['stock'] ?? 0);
            $transferQty = floatval($item['quantity']);
            
            // VALIDATION: Cannot exceed available stock
            if ($transferQty > $currentStock) {
                throw new Exception("Insufficient stock for {$productData['productName']}. Available: {$currentStock}, Requested: {$transferQty}");
            }
        }
        
        // Get location names
        $stmt = $db->prepare("SELECT * FROM locations WHERE id = ?");
        $stmt->execute([$input['source_location']]);
        $sourceRow = $stmt->fetch();
        $sourceData = $sourceRow ? json_decode($sourceRow['data'], true) : [];
        
        $stmt = $db->prepare("SELECT * FROM locations WHERE id = ?");
        $stmt->execute([$input['destination_location']]);
        $destRow = $stmt->fetch();
        $destData = $destRow ? json_decode($destRow['data'], true) : [];
        
        // Create transfer data
        $transferData = [
            'id' => $transferId,
            'transferNumber' => $transferNumber,
            'sourceLocationId' => $input['source_location'],
            'sourceLocation' => $sourceData['name'] ?? 'Unknown',
            'destinationLocationId' => $input['destination_location'],
            'destinationLocation' => $destData['name'] ?? 'Unknown',
            'items' => array_map(function($item) use ($db) {
                $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
                $stmt->execute([$item['product_id']]);
                $productRow = $stmt->fetch();
                $productData = $productRow ? json_decode($productRow['data'], true) : [];
                
                return [
                    'productId' => $item['product_id'],
                    'productName' => $productData['productName'] ?? 'Unknown',
                    'sku' => $productData['sku'] ?? '',
                    'quantity' => floatval($item['quantity']),
                    'batchNumber' => $item['batch_number'] ?? null
                ];
            }, $input['items']),
            'status' => 'Pending', // Awaiting verification
            'createdBy' => $currentUser['name'],
            'createdAt' => date('Y-m-d\TH:i:s.v\Z'),
            'notes' => $input['notes'] ?? '',
            'verificationPhoto' => null,
            'verifiedBy' => null,
            'verifiedAt' => null
        ];
        
        // Insert transfer
        $stmt = $db->prepare("INSERT INTO stock_transfers (id, data, created_at, updated_at) VALUES (?, ?, NOW(), NOW())");
        $stmt->execute([$transferId, json_encode($transferData)]);
        
        // LOG AUDIT TRAIL
        logAuditEvent($db, 'TRANSFER_CREATED', $currentUser, [
            'transfer_id' => $transferId,
            'transfer_number' => $transferNumber,
            'source' => $transferData['sourceLocation'],
            'destination' => $transferData['destinationLocation'],
            'status' => 'Pending'
        ]);
        
        // COMMIT TRANSACTION
        $db->commit();
        
        json_response([
            'success' => true,
            'message' => "Stock Transfer {$transferNumber} created. Awaiting photo verification at destination.",
            'data' => [
                'transfer_id' => $transferId,
                'transfer_number' => $transferNumber,
                'status' => 'Pending'
            ]
        ]);
        
    } catch (Exception $e) {
        // ROLLBACK ON ERROR
        $db->rollBack();
        throw $e;
    }
}

/**
 * Verify Transfer Arrival with Photo Upload
 * Only after verification will inventory counts change
 */
function verifyTransferArrival($db, $currentUser) {
    $input = get_json_input();
    
    if (empty($input['transfer_id']) || empty($input['verification_photo'])) {
        json_error('Transfer ID and verification photo are required');
    }
    
    try {
        // START TRANSACTION - CRITICAL SECTION
        $db->beginTransaction();
        
        // Get transfer
        $stmt = $db->prepare("SELECT * FROM stock_transfers WHERE id = ?");
        $stmt->execute([$input['transfer_id']]);
        $transferRow = $stmt->fetch();
        
        if (!$transferRow) {
            throw new Exception('Transfer not found');
        }
        
        $transferData = json_decode($transferRow['data'], true);
        
        if ($transferData['status'] !== 'Pending') {
            throw new Exception('Transfer already verified or cancelled');
        }
        
        // Process photo upload (base64 or file path)
        $photoPath = saveVerificationPhoto($input['verification_photo'], $transferData['transferNumber']);
        
        // Update transfer status
        $transferData['status'] = 'Completed';
        $transferData['verificationPhoto'] = $photoPath;
        $transferData['verifiedBy'] = $currentUser['name'];
        $transferData['verifiedAt'] = date('Y-m-d\TH:i:s.v\Z');
        
        // NOW UPDATE INVENTORY COUNTS
        foreach ($transferData['items'] as $item) {
            $productId = $item['productId'];
            $quantity = floatval($item['quantity']);
            
            // Get product
            $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
            $stmt->execute([$productId]);
            $productRow = $stmt->fetch();
            
            if ($productRow) {
                $productData = json_decode($productRow['data'], true);
                $currentStock = floatval($productData['stock'] ?? 0);
                
                // DEDUCT from source (already validated during creation)
                $newStock = $currentStock - $quantity;
                
                $productData['stock'] = $newStock;
                $productData['status'] = calculateStockStatus($newStock);
                $productData['lastUpdated'] = date('Y-m-d\TH:i:s.v\Z');
                
                $stmt = $db->prepare("UPDATE products SET data = ?, updated_at = NOW() WHERE id = ?");
                $stmt->execute([json_encode($productData), $productId]);
                
                // Log inventory movement - Stock Out from source
                $movementId = generate_id('inventory_movement');
                $movementData = [
                    'id' => $movementId,
                    'productId' => $productId,
                    'productName' => $item['productName'],
                    'sku' => $item['sku'],
                    'date' => date('Y-m-d\TH:i:s.v\Z'),
                    'type' => 'Stock Transfer Out',
                    'referenceType' => 'Transfer',
                    'referenceId' => $transferData['transferNumber'],
                    'quantity' => -$quantity,
                    'previousBalance' => $currentStock,
                    'newBalance' => $newStock,
                    'change' => -$quantity,
                    'reason' => "Transfer to {$transferData['destinationLocation']}",
                    'notes' => "Verified with photo",
                    'user' => $currentUser['name']
                ];
                
                $stmt = $db->prepare("INSERT INTO inventory_movements (id, data, created_at, updated_at) VALUES (?, ?, NOW(), NOW())");
                $stmt->execute([$movementId, json_encode($movementData)]);
            }
        }
        
        // Update transfer record
        $stmt = $db->prepare("UPDATE stock_transfers SET data = ?, updated_at = NOW() WHERE id = ?");
        $stmt->execute([json_encode($transferData), $input['transfer_id']]);
        
        // LOG AUDIT TRAIL
        logAuditEvent($db, 'TRANSFER_VERIFIED', $currentUser, [
            'transfer_id' => $input['transfer_id'],
            'transfer_number' => $transferData['transferNumber'],
            'verified_by' => $currentUser['name'],
            'photo_uploaded' => true
        ]);
        
        // COMMIT TRANSACTION
        $db->commit();
        
        json_response([
            'success' => true,
            'message' => "Transfer {$transferData['transferNumber']} verified and inventory updated!",
            'data' => [
                'transfer_number' => $transferData['transferNumber'],
                'status' => 'Completed',
                'verified_by' => $currentUser['name']
            ]
        ]);
        
    } catch (Exception $e) {
        // ROLLBACK ON ERROR
        $db->rollBack();
        throw $e;
    }
}

// ========================================================================
// STEP 5: AUDIT TRAIL & REPORTING
// ========================================================================

/**
 * Get comprehensive audit trail
 */
function getAuditTrail($db) {
    $filters = [];
    $params = [];
    
    if (!empty($_GET['date_from'])) {
        $filters[] = "created_at >= ?";
        $params[] = $_GET['date_from'];
    }
    
    if (!empty($_GET['date_to'])) {
        $filters[] = "created_at <= ?";
        $params[] = $_GET['date_to'] . ' 23:59:59';
    }
    
    if (!empty($_GET['event_type'])) {
        $filters[] = "event_type = ?";
        $params[] = $_GET['event_type'];
    }
    
    $whereClause = !empty($filters) ? 'WHERE ' . implode(' AND ', $filters) : '';
    
    try {
        $stmt = $db->prepare("
            SELECT * FROM security_logs 
            {$whereClause}
            ORDER BY created_at DESC 
            LIMIT 500
        ");
        $stmt->execute($params);
        
        $logs = $stmt->fetchAll();
        
        json_response([
            'success' => true,
            'data' => $logs,
            'count' => count($logs)
        ]);
        
    } catch (Exception $e) {
        throw $e;
    }
}

// ========================================================================
// HELPER FUNCTIONS
// ========================================================================

/**
 * Calculate stock status based on quantity
 */
function calculateStockStatus($quantity) {
    if ($quantity <= 0) return 'Out of Stock';
    if ($quantity <= 20) return 'Low Stock';
    if ($quantity <= 100) return 'In Stock';
    return 'Overstock';
}

/**
 * Generate PO Number
 */
function generatePONumber($db) {
    $year = date('Y');
    $stmt = $db->prepare("
        SELECT data FROM purchase_orders 
        WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.poNumber')) LIKE ? 
        ORDER BY created_at DESC 
        LIMIT 1
    ");
    $stmt->execute(["PO-$year-%"]);
    $result = $stmt->fetch();
    
    $nextNum = 1;
    if ($result) {
        $data = json_decode($result['data'], true);
        if (preg_match("/PO-$year-(\d+)/", $data['poNumber'], $matches)) {
            $nextNum = intval($matches[1]) + 1;
        }
    }
    
    return sprintf("PO-%s-%04d", $year, $nextNum);
}

/**
 * Generate Receiving Number
 */
function generateReceivingNumber($db) {
    $year = date('Y');
    $stmt = $db->prepare("
        SELECT data FROM receivings 
        WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.receivingNumber')) LIKE ? 
        ORDER BY CAST(SUBSTRING_INDEX(JSON_UNQUOTE(JSON_EXTRACT(data, '$.receivingNumber')), '-', -1) AS UNSIGNED) DESC 
        LIMIT 1
    ");
    $stmt->execute(["GR-$year-%"]);
    $result = $stmt->fetch();
    
    $nextNum = 1;
    if ($result) {
        $data = json_decode($result['data'], true);
        if (preg_match("/GR-$year-(\d+)/", $data['receivingNumber'], $matches)) {
            $nextNum = intval($matches[1]) + 1;
        }
    }
    
    return sprintf("GR-%s-%04d", $year, $nextNum);
}

/**
 * Generate POR Number
 */
function generatePORNumber($db) {
    $year = date('Y');
    $stmt = $db->prepare("
        SELECT por_number FROM proof_of_receiving 
        WHERE por_number LIKE ? 
        ORDER BY CAST(SUBSTRING_INDEX(por_number, '-', -1) AS UNSIGNED) DESC 
        LIMIT 1
    ");
    $stmt->execute(["POR-$year-%"]);
    $result = $stmt->fetch();
    
    $nextNum = 1;
    if ($result && preg_match("/POR-$year-(\d+)/", $result['por_number'], $matches)) {
        $nextNum = intval($matches[1]) + 1;
    }
    
    return sprintf("POR-%s-%04d", $year, $nextNum);
}

/**
 * Generate Transfer Number
 */
function generateTransferNumber($db) {
    $year = date('Y');
    $stmt = $db->prepare("
        SELECT data FROM stock_transfers 
        WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.transferNumber')) LIKE ? 
        ORDER BY created_at DESC 
        LIMIT 1
    ");
    $stmt->execute(["ST-$year-%"]);
    $result = $stmt->fetch();
    
    $nextNum = 1;
    if ($result) {
        $data = json_decode($result['data'], true);
        if (preg_match("/ST-$year-(\d+)/", $data['transferNumber'], $matches)) {
            $nextNum = intval($matches[1]) + 1;
        }
    }
    
    return sprintf("ST-%s-%04d", $year, $nextNum);
}

/**
 * Save verification photo
 */
function saveVerificationPhoto($photoData, $transferNumber) {
    $uploadDir = __DIR__ . '/../uploads/transfer-verifications/';
    
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    
    // Handle base64 encoded image
    if (strpos($photoData, 'data:image') === 0) {
        list($type, $data) = explode(';', $photoData);
        list(, $data) = explode(',', $data);
        $data = base64_decode($data);
        
        $extension = 'jpg';
        if (strpos($type, 'png')) $extension = 'png';
        
        $filename = $transferNumber . '_' . time() . '.' . $extension;
        $filepath = $uploadDir . $filename;
        
        file_put_contents($filepath, $data);
        
        return 'uploads/transfer-verifications/' . $filename;
    }
    
    return $photoData;
}


/**
 * Log audit event for tracking changes
 */
function logAuditEvent($db, $action, $user, $details) {
    // If security_logs table exists, use it
    try {
        $stmt = $db->prepare("
            INSERT INTO security_logs (event_type, user_id, username, details, ip_address, created_at)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $action,
            $user['id'] ?? null,
            $user['name'] ?? null,
            json_encode($details),
            $_SERVER['REMOTE_ADDR'] ?? null
        ]);
    } catch (Exception $e) {
        // Ignore if table doesn't exist or other audit errors
        // Don't fail the main transaction due to audit logging
        error_log("Audit log failed: " . $e->getMessage());
    }
}
