<?php
require_once __DIR__ . '/includes/auth.php';
$currentUser = require_login_page();
$transferId = $_GET['id'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Transfer QR Code - RAM-YUM</title>
    <link rel="stylesheet" href="assets/css/main.css">
    <script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>
    <style>
        .qr-container {
            max-width: 800px;
            margin: 40px auto;
            padding: 24px;
            background: var(--bg-primary);
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .qr-header {
            text-align: center;
            margin-bottom: 32px;
        }
        
        .qr-header h1 {
            font-size: 28px;
            color: var(--text-primary);
            margin-bottom: 8px;
        }
        
        .transfer-info {
            background: var(--bg-secondary);
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 24px;
        }
        
        .transfer-info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-top: 16px;
        }
        
        .info-item {
            display: flex;
            flex-direction: column;
        }
        
        .info-label {
            font-size: 12px;
            color: var(--text-secondary);
            text-transform: uppercase;
            font-weight: 600;
            margin-bottom: 4px;
        }
        
        .info-value {
            font-size: 16px;
            color: var(--text-primary);
            font-weight: 500;
        }
        
        .qr-display {
            text-align: center;
            padding: 40px;
            background: white;
            border-radius: 12px;
            margin-bottom: 24px;
        }
        
        #qrcode {
            display: inline-block;
            padding: 20px;
            background: white;
            border-radius: 8px;
        }
        
        .qr-instructions {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 16px;
            margin-bottom: 24px;
            border-radius: 4px;
        }
        
        .qr-instructions h3 {
            margin-top: 0;
            color: #856404;
            font-size: 16px;
        }
        
        .qr-instructions ul {
            margin: 8px 0 0 20px;
            color: #856404;
        }
        
        .action-buttons {
            display: flex;
            gap: 12px;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: var(--primary-orange);
            color: white;
        }
        
        .btn-primary:hover {
            background: var(--primary-red);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255, 122, 0, 0.3);
        }
        
        .btn-secondary {
            background: var(--bg-secondary);
            color: var(--text-primary);
            border: 1px solid var(--border-color);
        }
        
        .btn-secondary:hover {
            background: var(--bg-gray);
        }
        
        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 16px;
        }
        
        .items-table th,
        .items-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }
        
        .items-table th {
            background: var(--bg-secondary);
            font-weight: 600;
            color: var(--text-secondary);
            font-size: 12px;
            text-transform: uppercase;
        }
        
        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .status-in-transit {
            background: #fff3cd;
            color: #856404;
        }
        
        .loading {
            text-align: center;
            padding: 60px;
            color: var(--text-secondary);
        }
        
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 16px;
            border-radius: 8px;
            border-left: 4px solid #f5c6cb;
            margin-bottom: 24px;
        }
        
        @media print {
            .action-buttons, .qr-instructions {
                display: none;
            }
            
            .qr-container {
                box-shadow: none;
            }
        }
    </style>
</head>
<body>
    <div class="qr-container" id="content">
        <div class="loading">
            <p>Loading QR Code...</p>
        </div>
    </div>

    <script type="module">
        import { QRGenerator } from './assets/js/utils/qr-generator.js';

        const transferId = '<?php echo htmlspecialchars($transferId); ?>';

        if (!transferId) {
            showError('No transfer ID provided');
        } else {
            loadTransferQR();
        }

        async function loadTransferQR() {
            try {
                // Get transfer details
                const transferRes = await fetch(`/api/stock-transfers.php?action=transfer&id=${transferId}`);
                const transferData = await transferRes.json();

                if (!transferData.success) {
                    throw new Error(transferData.error || 'Failed to load transfer');
                }

                const transfer = transferData.data;

                // Check if transfer is in correct status
                if (transfer.status !== 'In Transit') {
                    if (transfer.status === 'Approved') {
                        showNeedsQRGeneration(transfer);
                        return;
                    } else if (transfer.status === 'Received') {
                        showAlreadyReceived(transfer);
                        return;
                    } else {
                        showError(`Transfer must be approved before QR code can be generated. Current status: ${transfer.status}`);
                        return;
                    }
                }

                // Get QR token
                const qrRes = await fetch(`/api/stock-transfers.php?action=qr-token&id=${transferId}`);
                const qrData = await qrRes.json();

                if (!qrData.success) {
                    throw new Error(qrData.error || 'Failed to load QR code');
                }

                displayQRCode(transfer, qrData.data);

            } catch (error) {
                console.error('Error loading QR:', error);
                showError(error.message);
            }
        }

        function displayQRCode(transfer, qrData) {
            const html = `
                <div class="qr-header">
                    <h1>Stock Transfer QR Code</h1>
                    <p style="color: var(--text-secondary);">Scan this QR code at destination to confirm receiving</p>
                </div>

                <div class="transfer-info">
                    <h3 style="margin-top:0;">Transfer Details</h3>
                    <div class="transfer-info-grid">
                        <div class="info-item">
                            <span class="info-label">Transfer Number</span>
                            <span class="info-value">${transfer.transferNumber}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Status</span>
                            <span class="status-badge status-in-transit">${transfer.status}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">From</span>
                            <span class="info-value">${transfer.sourceLocationName}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">To</span>
                            <span class="info-value">${transfer.destinationLocationName}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Transfer Date</span>
                            <span class="info-value">${transfer.transferDate}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Total Items</span>
                            <span class="info-value">${transfer.totalItems}</span>
                        </div>
                    </div>

                    <details style="margin-top: 20px;">
                        <summary style="cursor: pointer; font-weight: 600; margin-bottom: 8px;">View Items</summary>
                        <table class="items-table">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>SKU</th>
                                    <th>Quantity</th>
                                    <th>Unit</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${transfer.items.map(item => `
                                    <tr>
                                        <td>${item.productName}</td>
                                        <td>${item.sku}</td>
                                        <td>${item.quantity}</td>
                                        <td>${item.unit}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </details>
                </div>

                <div class="qr-instructions">
                    <h3>📱 How to Use This QR Code</h3>
                    <ul>
                        <li>Print this page or display on screen</li>
                        <li>Attach to physical delivery/shipment</li>
                        <li>At destination, open Receiving module and scan this QR code</li>
                        <li>System will auto-load this transfer for receiving confirmation</li>
                    </ul>
                </div>

                <div class="qr-display">
                    <div id="qrcode"></div>
                    <p style="margin-top: 16px; color: var(--text-secondary); font-size: 14px;">
                        Token: ${qrData.qr_token}
                    </p>
                </div>

                <div class="action-buttons">
                    <button class="btn btn-primary" onclick="window.print()">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M6 9V2h12v7M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/>
                            <path d="M6 14h12v8H6z"/>
                        </svg>
                        Print QR Code
                    </button>
                    <button class="btn btn-secondary" onclick="downloadQR()">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3"/>
                        </svg>
                        Download QR
                    </button>
                    <button class="btn btn-secondary" onclick="window.close()">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M18 6L6 18M6 6l12 12"/>
                        </svg>
                        Close
                    </button>
                </div>
            `;

            document.getElementById('content').innerHTML = html;

            // Generate QR code
            const qrUrl = `${window.location.origin}/receiving.php?token=${qrData.qr_token}`;
            QRGenerator.generateInContainer('qrcode', qrUrl, 256);
        }

        function showNeedsQRGeneration(transfer) {
            const html = `
                <div class="qr-header">
                    <h1>Generate QR Code</h1>
                </div>

                <div class="transfer-info">
                    <h3 style="margin-top:0;">Transfer: ${transfer.transferNumber}</h3>
                    <p>This transfer is approved but QR code has not been generated yet.</p>
                    <div style="margin-top: 20px;">
                        <button class="btn btn-primary" onclick="generateQR()">
                            Generate QR Code
                        </button>
                        <button class="btn btn-secondary" onclick="window.close()">
                            Cancel
                        </button>
                    </div>
                </div>
            `;
            document.getElementById('content').innerHTML = html;
        }

        function showAlreadyReceived(transfer) {
            const html = `
                <div class="qr-header">
                    <h1>Transfer Already Received</h1>
                </div>

                <div class="transfer-info">
                    <h3>Transfer: ${transfer.transferNumber}</h3>
                    <p>This transfer has already been received.</p>
                    <p><strong>Received By:</strong> ${transfer.receivedByName || 'Unknown'}</p>
                    <p><strong>Received At:</strong> ${transfer.receivedAt || 'Unknown'}</p>
                    <div style="margin-top: 20px;">
                        <button class="btn btn-secondary" onclick="window.close()">
                            Close
                        </button>
                    </div>
                </div>
            `;
            document.getElementById('content').innerHTML = html;
        }

        function showError(message) {
            const html = `
                <div class="error-message">
                    <strong>Error:</strong> ${message}
                </div>
                <div class="action-buttons">
                    <button class="btn btn-secondary" onclick="window.close()">Close</button>
                </div>
            `;
            document.getElementById('content').innerHTML = html;
        }

        window.generateQR = async function() {
            try {
                const res = await fetch('/api/stock-transfers.php?action=generate-qr', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ transferId })
                });

                const data = await res.json();
                if (!data.success) {
                    throw new Error(data.error || 'Failed to generate QR code');
                }

                alert('QR code generated successfully!');
                window.location.reload();

            } catch (error) {
                alert('Error: ' + error.message);
            }
        };

        window.downloadQR = function() {
            const canvas = document.querySelector('#qrcode canvas');
            if (canvas) {
                QRGenerator.downloadQRCode(canvas.toDataURL(), `ST-QR-${transferId}.png`);
            }
        };
    </script>
</body>
</html>
