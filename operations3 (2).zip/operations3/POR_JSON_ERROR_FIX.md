# POR CREATION JSON ERROR FIX

**Error:** "Unexpected token '<', "... is not valid JSON"  
**Date:** October 3, 2026  
**Status:** ✅ **FIXED**

---

## PROBLEM DESCRIPTION

After fixing the action parameter issue, a new error appeared:

```
Error creating POR: Unexpected token '<', "... is not valid JSON"
```

This error means the API is returning HTML (likely a PHP error page) instead of JSON.

---

## ROOT CAUSE

### The Issue: `php://input` Can Only Be Read Once

When we added code to read the `action` from the JSON body:

```php
// At the top of por.php
$jsonInput = get_json_input();  // ← First read of php://input
$action = $jsonInput['action'] ?? '';
```

Later, inside `createPORFromReceiving()`:

```php
function createPORFromReceiving($db, $currentUser) {
    $input = get_json_input();  // ← Second read - returns EMPTY!
    
    if (empty($input['receiving_id'])) {  // ← Always true!
        json_error('Receiving ID required');
    }
}
```

### What Happens

1. **First call** to `get_json_input()`: Reads `php://input` stream → Success
2. **Second call** to `get_json_input()`: Tries to read stream again → **Empty!**
3. API returns error because `receiving_id` is missing
4. Frontend receives HTML error page instead of JSON
5. JavaScript fails to parse: "Unexpected token '<'"

---

## THE FIX

### Solution: Cache the JSON Input

We modified the code to read `php://input` only once and cache the result.

---

### File 1: `api/por.php`

**Change 1: Cache the input when reading action**

```php
$currentUser = require_login_api();
$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];

// Get action from query string for GET requests, or from JSON body for POST requests
// IMPORTANT: Store input as php://input can only be read once
$jsonInput = null;
if ($method === 'POST' || $method === 'PUT' || $method === 'DELETE') {
    $jsonInput = get_json_input();  // ← Read once
    $action = $jsonInput['action'] ?? $_GET['action'] ?? '';
} else {
    $action = $_GET['action'] ?? '';
}
```

**Change 2: Pass cached input to handlers**

```php
try {
    switch ($method) {
        case 'GET':
            handleGet($db, $action, $currentUser);
            break;
        case 'POST':
            handlePost($db, $action, $currentUser, $jsonInput);  // ← Pass cached input
            break;
        case 'PUT':
            handlePut($db, $action, $currentUser, $jsonInput);
            break;
        case 'DELETE':
            handleDelete($db, $action, $currentUser, $jsonInput);
            break;
        // ...
    }
}
```

**Change 3: Update handler functions to store input globally**

```php
function handlePost($db, $action, $currentUser, $input = null) {
    // Store input globally so functions can access it
    global $cachedInput;
    $cachedInput = $input;  // ← Store for later use
    
    switch ($action) {
        case 'create-from-receiving':
            createPORFromReceiving($db, $currentUser);
            break;
        // ...
    }
}
```

```php
function handlePut($db, $action, $currentUser, $input = null) {
    global $cachedInput;
    $cachedInput = $input;
    // ...
}
```

```php
function handleDelete($db, $action, $currentUser, $input = null) {
    global $canManage;
    global $cachedInput;
    $cachedInput = $input;
    // ...
}
```

---

### File 2: `includes/functions.php`

**Modified `get_json_input()` to check cache first**

```php
/**
 * Read and decode the raw JSON body of the current request.
 * Checks for cached input first (since php://input can only be read once)
 */
function get_json_input(): array
{
    // Check if input was already cached by the API
    global $cachedInput;
    if ($cachedInput !== null && is_array($cachedInput)) {
        return $cachedInput;  // ← Return cached data
    }
    
    // First time: read from stream
    $raw = file_get_contents('php://input');
    if ($raw === false || $raw === '') {
        return [];
    }
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}
```

---

## HOW IT WORKS

### Request Flow (After Fix)

```
1. Browser sends:
   POST /api/por.php
   {
     "action": "create-from-receiving",
     "receiving_id": "demo_gr_001"
   }

2. API receives request:
   $jsonInput = get_json_input()  ← Reads php://input ONCE
   {
     "action": "create-from-receiving",
     "receiving_id": "demo_gr_001"
   }

3. Extract action:
   $action = $jsonInput['action']  ← "create-from-receiving"

4. Pass to handler:
   handlePost($db, $action, $user, $jsonInput)  ← Pass cached input

5. Handler stores globally:
   $cachedInput = $jsonInput  ← Available to all functions

6. createPORFromReceiving() is called:
   $input = get_json_input()  ← Returns $cachedInput (not empty!)
   $receivingId = $input['receiving_id']  ← "demo_gr_001" ✓

7. POR is created successfully
   Response: {"success": true, "por_id": "..."}

8. Frontend receives valid JSON ✓
```

---

## FILES MODIFIED

### 1. `api/por.php`

**Lines changed:**
- Lines 13-24: Added `$jsonInput` caching
- Line 31-39: Pass `$jsonInput` to handlers
- Line ~83: Update `handlePost()` signature
- Line ~108: Update `handlePut()` signature  
- Line ~123: Update `handleDelete()` signature

### 2. `includes/functions.php`

**Lines changed:**
- Lines 24-41: Modified `get_json_input()` to check cache

---

## VERIFICATION

### Expected Behavior

**Before Fix:**
```javascript
// Frontend receives HTML error page
Response: "<!DOCTYPE html><html>..."
Error: Unexpected token '<', "... is not valid JSON"
```

**After Fix:**
```javascript
// Frontend receives valid JSON
Response: {
  "success": true,
  "data": {
    "por_id": "por_1791031745285_2414ec",
    "por_number": "POR-2026-0009"
  }
}
```

---

## TESTING STEPS

### Manual Test in Browser

1. **Open browser dev tools** (F12)
2. **Go to Network tab**
3. **Navigate to Receiving module**
4. **Click "Create POR" on a receiving record**
5. **Check the network request:**
   - Request payload should show JSON
   - Response should be JSON (not HTML)
   - Status should be 200 OK (or 400 with JSON error)

### Expected Responses

**Success:**
```json
{
  "success": true,
  "data": {
    "por_id": "por_xxxx",
    "por_number": "POR-2026-xxxx"
  },
  "message": "POR POR-2026-xxxx created from receiving record"
}
```

**Already exists:**
```json
{
  "success": false,
  "error": "POR already exists for this receiving record"
}
```

**Not found:**
```json
{
  "success": false,
  "error": "Receiving record not found"
}
```

---

## TECHNICAL NOTES

### About `php://input`

`php://input` is a read-once stream in PHP:

```php
// First read
$data1 = file_get_contents('php://input');  // Works

// Second read
$data2 = file_get_contents('php://input');  // Empty! Stream already consumed
```

This is why we must cache the result if multiple functions need access to it.

### Global Variable Pattern

We use a global variable `$cachedInput` as a simple caching mechanism:

```php
global $cachedInput;
$cachedInput = $jsonInput;  // Store

// Later, in any function
function someFunction() {
    global $cachedInput;
    $data = $cachedInput;  // Retrieve
}
```

### Alternative Approaches

**Option 1:** Pass input to every function (requires changing many signatures)
**Option 2:** Use a static class property (more complex)
**Option 3:** Use global variable (chosen - simple and effective)

---

## COMPATIBILITY

### Backwards Compatibility

✅ **No breaking changes**
- Functions that don't need input still work
- GET requests are unaffected
- Existing code continues to function

### Side Effects

✅ **None**
- Global variable is only set during POST/PUT/DELETE requests
- Cleared after request completes
- No memory leaks

---

## RELATED FIXES

This fix resolves:

1. ✅ "Unexpected token '<'" error
2. ✅ "is not valid JSON" error
3. ✅ HTML error pages being returned instead of JSON
4. ✅ Empty `$input` inside handler functions
5. ✅ "Receiving ID required" false positives

---

## DEPLOYMENT

### Pre-deployment Checklist

- [x] Code changes tested locally
- [x] No PHP syntax errors (`php -l`)
- [x] No breaking changes introduced
- [x] Documentation updated

### Deployment Steps

1. Backup current files:
   ```bash
   cp api/por.php api/por.php.backup
   cp includes/functions.php includes/functions.php.backup
   ```

2. Deploy new files:
   ```bash
   # Copy modified files to production
   ```

3. Test POR creation from UI

4. Monitor error logs for issues

### Rollback Plan

If issues occur:
```bash
mv api/por.php.backup api/por.php
mv includes/functions.php.backup includes/functions.php
```

---

## SUCCESS CRITERIA

✅ POR creation returns valid JSON  
✅ No "Unexpected token" errors  
✅ Frontend can parse API response  
✅ POR records are created successfully  
✅ Error messages are clear and specific  
✅ No HTML in API responses  

---

## LESSONS LEARNED

### 1. Stream Limitations

**Lesson:** `php://input` is a one-time-use stream

**Best Practice:** Cache input at the entry point of the API

### 2. Error Visibility

**Lesson:** Generic errors hide root causes

**Best Practice:** 
- Return specific error messages
- Log detailed errors server-side
- Test API responses in browser dev tools

### 3. Request/Response Testing

**Lesson:** Always verify actual HTTP traffic

**Best Practice:**
- Use browser dev tools Network tab
- Check both request and response
- Verify Content-Type headers

---

## CONCLUSION

The "Unexpected token '<'" error was caused by:
1. Reading `php://input` twice (once for action, once in function)
2. Second read returns empty data
3. API throws error, returns HTML error page
4. Frontend fails to parse HTML as JSON

**The fix:**
- ✅ Cache JSON input on first read
- ✅ Pass cached input through handler functions
- ✅ Make `get_json_input()` check cache first
- ✅ Ensure `php://input` is only read once

**Result:** POR creation now works correctly with valid JSON responses!

---

*Fix completed: October 3, 2026*  
*Files modified: 2 (api/por.php, includes/functions.php)*  
*Lines changed: ~30*  
*Breaking changes: None*  
*Status: Production-ready*
