<?php
/**
 * Simple database connection check
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Database Connection Test</h1>";

// Test database connection
try {
    require_once __DIR__ . '/config/database.php';
    $db = getDB();
    echo "<p style='color: green;'>✓ Database connection successful!</p>";
    
    // Check if users table exists
    $tables = $db->query("SHOW TABLES LIKE 'users'")->fetchAll();
    if (count($tables) > 0) {
        echo "<p style='color: green;'>✓ Users table exists!</p>";
        
        // Count users
        $count = $db->query("SELECT COUNT(*) as count FROM users")->fetch();
        echo "<p>Total users in database: <strong>{$count['count']}</strong></p>";
        
        // Show users (safely, without passwords)
        $users = $db->query("SELECT id, name, email, username, role FROM users ORDER BY created_at ASC")->fetchAll();
        echo "<h2>Users:</h2><ul>";
        foreach ($users as $user) {
            echo "<li>{$user['name']} ({$user['username']}) - Role: {$user['role']}</li>";
        }
        echo "</ul>";
    } else {
        echo "<p style='color: red;'>✗ Users table does not exist!</p>";
        echo "<p>Run the schema.sql file to create the database structure.</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>✗ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}

// Check session
session_start();
echo "<h2>Session Status</h2>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";
