<?php
/**
 * Quick verification that locations are now working
 */

require_once __DIR__ . '/includes/auth.php';
$currentUser = require_login_page();

echo "<!DOCTYPE html><html><head><title>Location Fix Verification</title>";
echo "<link rel='stylesheet' href='assets/css/main.css'></head><body>";
echo "<div style='max-width: 800px; margin: 40px auto; padding: 20px;'>";

echo "<h1>🔍 Locations Fix Verification</h1>";
echo "<p>Let's verify that the locations issue has been resolved.</p>";

// Test 1: Direct API call
echo "<h2>Test 1: API Call</h2>";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://localhost/operations/api/stock-transfers.php?action=locations");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, false);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode === 200 && $response) {
    $data = json_decode($response, true);
    if ($data && $data['success'] && isset($data['data']) && count($data['data']) > 0) {
        echo "<p style='color: green;'>✅ <strong>SUCCESS!</strong> API returned " . count($data['data']) . " locations</p>";
        
        echo "<div style='background: #f9fafb; padding: 16px; border-radius: 8px; margin: 16px 0;'>";
        echo "<h3>Available Locations:</h3>";
        foreach ($data['data'] as $location) {
            echo "<p>📍 <strong>" . htmlspecialchars($location['name']) . "</strong> (" . htmlspecialchars($location['type']) . ")</p>";
        }
        echo "</div>";
        
    } else {
        echo "<p style='color: red;'>❌ API returned empty or invalid data</p>";
        echo "<pre>" . htmlspecialchars($response) . "</pre>";
    }
} else {
    echo "<p style='color: red;'>❌ API call failed (HTTP " . $httpCode . ")</p>";
    echo "<p>Response: " . htmlspecialchars($response) . "</p>";
}

// Test 2: Database direct check
echo "<h2>Test 2: Database Check</h2>";
try {
    require_once __DIR__ . '/config/database.php';
    $db = getDB();
    
    $stmt = $db->query("SELECT COUNT(*) as count FROM locations");
    $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    if ($count > 0) {
        echo "<p style='color: green;'>✅ Database has {$count} locations</p>";
        
        $stmt = $db->query("SELECT data FROM locations ORDER BY JSON_UNQUOTE(JSON_EXTRACT(data, '$.name'))");
        $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<div style='background: #f9fafb; padding: 16px; border-radius: 8px; margin: 16px 0;'>";
        echo "<h3>Database Locations:</h3>";
        foreach ($locations as $row) {
            $loc = json_decode($row['data'], true);
            echo "<p>🗄️ " . htmlspecialchars($loc['name'] ?? 'Unknown') . " - " . htmlspecialchars($loc['status'] ?? 'Unknown') . "</p>";
        }
        echo "</div>";
        
    } else {
        echo "<p style='color: red;'>❌ No locations found in database</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Database error: " . htmlspecialchars($e->getMessage()) . "</p>";
}

// Test 3: Frontend simulation
echo "<h2>Test 3: Frontend Simulation</h2>";
echo "<p>This simulates what the Stock Transfer frontend should receive:</p>";

echo "<script>
async function testFrontendCall() {
    try {
        const response = await fetch('api/stock-transfers.php?action=locations');
        const data = await response.json();
        
        const resultDiv = document.getElementById('frontendResult');
        
        if (data.success && data.data && data.data.length > 0) {
            resultDiv.innerHTML = `
                <p style='color: green;'>✅ <strong>Frontend Test SUCCESS!</strong> Found \${data.data.length} locations</p>
                <div style='background: #f0f9ff; padding: 16px; border-radius: 8px; margin: 16px 0;'>
                    <h4>Dropdown would show:</h4>
                    <select style='width: 100%; padding: 8px; margin: 8px 0;'>
                        <option value=''>-- Select Source --</option>
                        \${data.data.map(loc => `<option value='\${loc.id}'>\${loc.name}</option>`).join('')}
                    </select>
                    <select style='width: 100%; padding: 8px; margin: 8px 0;'>
                        <option value=''>-- Select Destination --</option>
                        \${data.data.map(loc => `<option value='\${loc.id}'>\${loc.name}</option>`).join('')}
                    </select>
                </div>
            `;
        } else {
            resultDiv.innerHTML = '<p style=\"color: red;\">❌ Frontend would show: \"No locations available\"</p>';
        }
    } catch (error) {
        document.getElementById('frontendResult').innerHTML = '<p style=\"color: red;\">❌ Frontend error: ' + error.message + '</p>';
    }
}

document.addEventListener('DOMContentLoaded', testFrontendCall);
</script>";

echo "<div id='frontendResult'><p>Loading frontend test...</p></div>";

echo "<h2>🎯 Next Steps</h2>";
echo "<div style='background: #dbeafe; padding: 16px; border-radius: 8px; margin: 16px 0;'>";
echo "<p><strong>If all tests above show SUCCESS:</strong></p>";
echo "<ol>";
echo "<li>Go to the <a href='dashboard.php' style='color: #3b82f6;'>Dashboard</a></li>";
echo "<li>Navigate to <strong>Stock Transfer</strong></li>";
echo "<li>Click <strong>Create Transfer</strong></li>";
echo "<li>The dropdowns should now be populated!</li>";
echo "</ol>";
echo "</div>";

echo "<div style='text-align: center; margin: 30px 0;'>";
echo "<a href='dashboard.php' style='background: #10b981; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin-right: 10px;'>📊 Test in Dashboard</a>";
echo "<a href='test-locations-data.php' style='background: #3b82f6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px;'>🧪 Full Test Page</a>";
echo "</div>";

echo "</div></body></html>";
?>