<?php
/**
 * Diagnostic Script for Approval System
 * This will help identify the exact error
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'includes/auth.php';

echo "=================================================\n";
echo "    APPROVAL SYSTEM DIAGNOSTIC\n";
echo "=================================================\n\n";

// TEST 1: Database Connection
echo "TEST 1: Database Connection\n";
echo "-------------------------------------------------\n";
try {
    $db = getDB();
    echo "✓ Connected\n\n";
} catch (Exception $e) {
    echo "✗ Failed: " . $e->getMessage() . "\n\n";
    exit(1);
}

// TEST 2: Check Transfer Exists
echo "TEST 2: Check Transfer ST-2026-0001\n";
echo "-------------------------------------------------\n";
try {
    $stmt = $db->prepare("SELECT id, data FROM stock_transfers WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.transferNumber')) = ?");
    $stmt->execute(['ST-2026-0001']);
    $result = $stmt->fetch();
    
    if ($result) {
        echo "✓ Transfer found\n";
        echo "  ID: " . $result['id'] . "\n";
        $transfer = json_decode($result['data'], true);
        echo "  Status: " . $transfer['status'] . "\n";
        echo "  Source: " . ($transfer['sourceLocationName'] ?? 'N/A') . "\n";
        echo "  Destination: " . ($transfer['destinationLocationName'] ?? 'N/A') . "\n";
        echo "  Items: " . count($transfer['items'] ?? []) . "\n\n";
        
        $transferId = $result['id'];
    } else {
        echo "✗ Transfer not found\n\n";
        exit(1);
    }
} catch (Exception $e) {
    echo "✗ Error: " . $e->getMessage() . "\n\n";
    exit(1);
}

// TEST 3: Check Helper Functions
echo "TEST 3: Check Helper Functions\n";
echo "-------------------------------------------------\n";
$apiFile = file_get_contents('api/stock-transfers.php');

$functions = [
    'getAvailableInventory',
    'getProductName',
    'updateInventoryForTransfer',
    'logAuditEvent'
];

foreach ($functions as $func) {
    if (strpos($apiFile, "function $func") !== false) {
        echo "✓ $func() exists\n";
    } else {
        echo "✗ $func() NOT FOUND\n";
    }
}
echo "\n";

// TEST 4: Check Inventory for First Item
echo "TEST 4: Check Inventory Availability\n";
echo "-------------------------------------------------\n";
try {
    if (isset($transfer['items']) && count($transfer['items']) > 0) {
        $firstItem = $transfer['items'][0];
        $productId = $firstItem['productId'];
        $sourceLocationId = $transfer['sourceLocationId'];
        $requestedQty = $firstItem['quantity'];
        
        // Check available inventory
        $stmt = $db->prepare("
            SELECT JSON_UNQUOTE(JSON_EXTRACT(data, '$.availableQuantity')) as available 
            FROM inventory_locations 
            WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.productId')) = ? 
            AND JSON_UNQUOTE(JSON_EXTRACT(data, '$.locationId')) = ?
        ");
        $stmt->execute([$productId, $sourceLocationId]);
        $invResult = $stmt->fetch();
        
        if ($invResult) {
            $available = (int)$invResult['available'];
            echo "  Product ID: $productId\n";
            echo "  Requested: $requestedQty\n";
            echo "  Available: $available\n";
            
            if ($available >= $requestedQty) {
                echo "  ✓ Sufficient stock\n";
            } else {
                echo "  ✗ Insufficient stock\n";
            }
        } else {
            echo "  ✗ No inventory record found\n";
        }
    } else {
        echo "  ⚠ No items in transfer\n";
    }
    echo "\n";
} catch (Exception $e) {
    echo "✗ Error: " . $e->getMessage() . "\n\n";
}

// TEST 5: Test get_json_input Function
echo "TEST 5: Test get_json_input Function\n";
echo "-------------------------------------------------\n";
if (function_exists('get_json_input')) {
    echo "✓ get_json_input() function exists\n";
} else {
    echo "✗ get_json_input() function NOT FOUND\n";
}
echo "\n";

// TEST 6: Check Admin Users
echo "TEST 6: Check Admin/Manager Users\n";
echo "-------------------------------------------------\n";
try {
    $stmt = $db->query("SELECT id, JSON_UNQUOTE(JSON_EXTRACT(data, '$.username')) as username, JSON_UNQUOTE(JSON_EXTRACT(data, '$.role')) as role FROM users WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.role')) IN ('admin', 'manager')");
    $users = $stmt->fetchAll();
    
    if (count($users) > 0) {
        echo "✓ Found " . count($users) . " admin/manager user(s):\n";
        foreach ($users as $user) {
            echo "  - " . $user['username'] . " (" . $user['role'] . ") - ID: " . $user['id'] . "\n";
        }
    } else {
        echo "✗ No admin/manager users found\n";
    }
    echo "\n";
} catch (Exception $e) {
    echo "✗ Error: " . $e->getMessage() . "\n\n";
}

// TEST 7: Simulate Approval Request
echo "TEST 7: Simulate Approval API Call\n";
echo "-------------------------------------------------\n";
echo "Simulating POST request to api/stock-transfers.php?action=approve\n";
echo "With JSON body: {\"transferId\": \"$transferId\", \"approvalRemarks\": \"Test\"}\n\n";

// We'll output a curl command the user can run
$curlCommand = "curl -X POST \"http://localhost/operations3/api/stock-transfers.php?action=approve\" ";
$curlCommand .= "-H \"Content-Type: application/json\" ";
$curlCommand .= "-d '{\"transferId\":\"$transferId\",\"approvalRemarks\":\"Test approval\"}' ";
$curlCommand .= "-b \"PHPSESSID=YOUR_SESSION_ID\"";

echo "To test manually, you can run:\n";
echo "$curlCommand\n\n";

echo "Or open your browser's Developer Console and run:\n";
echo "fetch('api/stock-transfers.php?action=approve', {\n";
echo "  method: 'POST',\n";
echo "  headers: {'Content-Type': 'application/json'},\n";
echo "  body: JSON.stringify({transferId: '$transferId', approvalRemarks: 'Test'})\n";
echo "}).then(r => r.text()).then(console.log)\n\n";

echo "=================================================\n";
echo "           DIAGNOSTIC COMPLETE\n";
echo "=================================================\n";
