-- ==========================================
-- CRITICAL FIXES MIGRATION
-- RAM-YUM Operations System
-- Date: October 3, 2026
-- Purpose: Fix 3 critical audit findings
-- ==========================================

-- ==========================================
-- FIX #1: ADD SKU UNIQUENESS CONSTRAINT
-- ==========================================
-- Problem: Database allows duplicate SKUs across products
-- Solution: Add unique constraint on JSON-extracted SKU field

-- Step 1: Check for existing duplicate SKUs (run this first to verify)
SELECT 
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.sku')) as sku,
    COUNT(*) as count
FROM products
WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.sku')) IS NOT NULL
GROUP BY JSON_UNQUOTE(JSON_EXTRACT(data, '$.sku'))
HAVING COUNT(*) > 1;

-- Step 2: Add generated column for SKU (required for unique index on JSON field)
ALTER TABLE products 
ADD COLUMN sku_normalized VARCHAR(100) 
GENERATED ALWAYS AS (JSON_UNQUOTE(JSON_EXTRACT(data, '$.sku'))) STORED;

-- Step 3: Add unique constraint on the generated column
ALTER TABLE products 
ADD UNIQUE KEY unique_sku (sku_normalized);

-- Step 4: Add index for better query performance
CREATE INDEX idx_product_sku ON products(sku_normalized);

-- Verification query
SELECT 
    COUNT(*) as total_products,
    COUNT(DISTINCT sku_normalized) as unique_skus
FROM products;

-- ==========================================
-- FIX #2: ADD SERVER-SIDE NEGATIVE STOCK VALIDATION
-- ==========================================
-- Problem: Stock quantity validation only happens on client-side
-- Solution: Add CHECK constraint to prevent negative stock in inventory_locations

-- Add generated column for quantity validation
ALTER TABLE inventory_locations
ADD COLUMN quantity_value DECIMAL(10,2)
GENERATED ALWAYS AS (CAST(JSON_UNQUOTE(JSON_EXTRACT(data, '$.quantity')) AS DECIMAL(10,2))) STORED;

-- Add CHECK constraint to prevent negative quantities
ALTER TABLE inventory_locations
ADD CONSTRAINT chk_positive_quantity CHECK (quantity_value >= 0);

-- Add generated column for available quantity validation
ALTER TABLE inventory_locations
ADD COLUMN available_quantity_value DECIMAL(10,2)
GENERATED ALWAYS AS (CAST(JSON_UNQUOTE(JSON_EXTRACT(data, '$.availableQuantity')) AS DECIMAL(10,2))) STORED;

-- Add CHECK constraint to prevent negative available quantities
ALTER TABLE inventory_locations
ADD CONSTRAINT chk_positive_available_quantity CHECK (available_quantity_value >= 0);

-- Verification: Try to insert negative stock (should fail)
-- INSERT INTO inventory_locations (id, data) VALUES ('test_negative', '{"quantity": -5, "availableQuantity": -5}');

-- ==========================================
-- FIX #3: DOCUMENTATION CLARIFICATION
-- ==========================================
-- Note: POD (Proof of Delivery) scanning is ONLY implemented for Stock Transfers
-- PO Receiving workflow does NOT use QR/POD scanning - it uses manual receiving process
-- This is by design and documented in the system architecture
-- No database changes needed - this is a documentation/clarification issue

-- ==========================================
-- ROLLBACK INSTRUCTIONS (if needed)
-- ==========================================
/*
-- To rollback FIX #1 (SKU uniqueness):
ALTER TABLE products DROP INDEX unique_sku;
ALTER TABLE products DROP INDEX idx_product_sku;
ALTER TABLE products DROP COLUMN sku_normalized;

-- To rollback FIX #2 (negative stock prevention):
ALTER TABLE inventory_locations DROP CONSTRAINT chk_positive_available_quantity;
ALTER TABLE inventory_locations DROP CONSTRAINT chk_positive_quantity;
ALTER TABLE inventory_locations DROP COLUMN available_quantity_value;
ALTER TABLE inventory_locations DROP COLUMN quantity_value;
*/

-- ==========================================
-- POST-MIGRATION VERIFICATION QUERIES
-- ==========================================

-- Verify SKU uniqueness is enforced
SELECT 'SKU Uniqueness Check' as test_name,
    CASE 
        WHEN COUNT(*) > 0 THEN 'PASS - Constraint exists'
        ELSE 'FAIL - Constraint missing'
    END as result
FROM information_schema.table_constraints
WHERE table_schema = DATABASE()
AND table_name = 'products'
AND constraint_name = 'unique_sku';

-- Verify negative stock prevention is enforced
SELECT 'Negative Stock Prevention Check' as test_name,
    CASE 
        WHEN COUNT(*) >= 2 THEN 'PASS - Constraints exist'
        ELSE 'FAIL - Constraints missing'
    END as result
FROM information_schema.table_constraints
WHERE table_schema = DATABASE()
AND table_name = 'inventory_locations'
AND constraint_name IN ('chk_positive_quantity', 'chk_positive_available_quantity');

-- Show all products with their normalized SKUs
SELECT 
    id,
    sku_normalized,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.name')) as product_name,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.category')) as category,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.stock')) as stock
FROM products
ORDER BY sku_normalized
LIMIT 10;

-- Show inventory locations with quantity constraints
SELECT 
    id,
    quantity_value,
    available_quantity_value,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.productId')) as product_id,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.locationId')) as location_id
FROM inventory_locations
WHERE quantity_value < 20
ORDER BY quantity_value
LIMIT 10;

-- ==========================================
-- MIGRATION COMPLETE
-- ==========================================
-- Run verification queries above to confirm all fixes are applied
-- Test negative stock insertion manually to verify constraints work
-- Test duplicate SKU insertion manually to verify uniqueness constraint works
