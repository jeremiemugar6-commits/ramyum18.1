-- =====================================================================
-- Stock Transfer Demo Data
-- Sample transfers for immediate demonstration
-- =====================================================================

USE ramyum_db;

-- Delete any existing demo transfers to ensure clean data
DELETE FROM stock_transfers WHERE id LIKE 'st_demo_%';

-- Insert sample stock transfers for demonstration
INSERT INTO stock_transfers (id, data) VALUES
-- Pending Transfer - waiting for approval
('st_demo_001', JSON_OBJECT(
    'id', 'st_demo_001',
    'transferNumber', 'ST-2026-0001',
    'transferDate', DATE_FORMAT(NOW(), '%Y-%m-%d'),
    'sourceLocationId', 'loc1',
    'sourceLocationName', 'Main Warehouse',
    'destinationLocationId', 'loc2', 
    'destinationLocationName', 'Branch 1 - Makati',
    'requestedBy', 'u2',
    'requestedByName', 'Staff User',
    'status', 'Pending Approval',
    'remarks', 'Branch 1 needs restocking for weekend rush. Samyang and Shin Ramyun are running low.',
    'items', JSON_ARRAY(
        JSON_OBJECT(
            'productId', 'p1',
            'productName', 'Samyang Buldak Original',
            'sku', 'SB-001',
            'quantity', 20,
            'unit', 'pcs',
            'sourceStock', 100,
            'destinationStock', 30
        ),
        JSON_OBJECT(
            'productId', 'p2',
            'productName', 'Shin Ramyun',
            'sku', 'SR-002',
            'quantity', 15,
            'unit', 'pcs',
            'sourceStock', 80,
            'destinationStock', 25
        )
    ),
    'totalItems', 35,
    'createdAt', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'),
    'submittedAt', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),

-- Another Pending Transfer 
('st_demo_002', JSON_OBJECT(
    'id', 'st_demo_002',
    'transferNumber', 'ST-2026-0002', 
    'transferDate', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%d'),
    'sourceLocationId', 'loc1',
    'sourceLocationName', 'Main Warehouse',
    'destinationLocationId', 'loc3',
    'destinationLocationName', 'Branch 2 - Quezon City',
    'requestedBy', 'u2',
    'requestedByName', 'Staff User',
    'status', 'Pending Approval',
    'remarks', 'QC branch requesting Korean snacks for new customer promotion.',
    'items', JSON_ARRAY(
        JSON_OBJECT(
            'productId', 'p10',
            'productName', 'Korean Seaweed Snack',
            'sku', 'KS-010',
            'quantity', 25,
            'unit', 'pcs',
            'sourceStock', 120,
            'destinationStock', 50
        )
    ),
    'totalItems', 25,
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%dT%H:%i:%s.000Z'),
    'submittedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%dT%H:%i:%s.000Z')
)),

-- Approved Transfer - completed
('st_demo_003', JSON_OBJECT(
    'id', 'st_demo_003',
    'transferNumber', 'ST-2026-0003',
    'transferDate', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 DAY), '%Y-%m-%d'),
    'sourceLocationId', 'loc1',
    'sourceLocationName', 'Main Warehouse', 
    'destinationLocationId', 'loc4',
    'destinationLocationName', 'Storage Area - BGC',
    'requestedBy', 'u2',
    'requestedByName', 'Staff User',
    'status', 'Approved',
    'remarks', 'Moving overflow inventory to BGC storage facility.',
    'items', JSON_ARRAY(
        JSON_OBJECT(
            'productId', 'p3',
            'productName', 'Ottogi Jin Ramen',
            'sku', 'OJ-003',
            'quantity', 30,
            'unit', 'pcs',
            'sourceStock', 60,
            'destinationStock', 0
        )
    ),
    'totalItems', 30,
    'approvedBy', 'u1',
    'approvedByName', 'Admin User',
    'approvedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%dT%H:%i:%s.000Z'),
    'approvalRemarks', 'Approved. BGC facility has adequate space.',
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 DAY), '%Y-%m-%dT%H:%i:%s.000Z'),
    'submittedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 DAY), '%Y-%m-%dT%H:%i:%s.000Z')
)),

-- Rejected Transfer
('st_demo_004', JSON_OBJECT(
    'id', 'st_demo_004',
    'transferNumber', 'ST-2026-0004',
    'transferDate', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 3 DAY), '%Y-%m-%d'),
    'sourceLocationId', 'loc2',
    'sourceLocationName', 'Branch 1 - Makati',
    'destinationLocationId', 'loc3',
    'destinationLocationName', 'Branch 2 - Quezon City',
    'requestedBy', 'u2', 
    'requestedByName', 'Staff User',
    'status', 'Rejected',
    'remarks', 'Inter-branch transfer for customer special order.',
    'items', JSON_ARRAY(
        JSON_OBJECT(
            'productId', 'p1',
            'productName', 'Samyang Buldak Original',
            'sku', 'SB-001',
            'quantity', 35,
            'unit', 'pcs',
            'sourceStock', 30,
            'destinationStock', 20
        )
    ),
    'totalItems', 35,
    'rejectedBy', 'u1',
    'rejectedByName', 'Admin User',
    'rejectedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 DAY), '%Y-%m-%dT%H:%i:%s.000Z'),
    'rejectionReason', 'Insufficient stock at source location. Source has only 30 units but 35 requested.',
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 3 DAY), '%Y-%m-%dT%H:%i:%s.000Z'),
    'submittedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 3 DAY), '%Y-%m-%dT%H:%i:%s.000Z')
))
ON DUPLICATE KEY UPDATE id = id;

-- Add corresponding inventory movements for the approved transfer
INSERT INTO inventory_movements (id, data) VALUES
('mov_st_demo_003_out', JSON_OBJECT(
    'id', 'mov_st_demo_003_out',
    'productId', 'p3',
    'productName', 'Ottogi Jin Ramen',
    'locationId', 'loc1',
    'locationName', 'Main Warehouse',
    'movementType', 'Stock Out',
    'quantity', -30,
    'previousStock', 90,
    'newStock', 60,
    'referenceType', 'STOCK_TRANSFER',
    'referenceId', 'ST-2026-0003',
    'performedBy', 'u1',
    'performedByName', 'Admin User',
    'reason', 'Stock Transfer - Out',
    'notes', 'Transfer to Storage Area - BGC',
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('mov_st_demo_003_in', JSON_OBJECT(
    'id', 'mov_st_demo_003_in',
    'productId', 'p3', 
    'productName', 'Ottogi Jin Ramen',
    'locationId', 'loc4',
    'locationName', 'Storage Area - BGC',
    'movementType', 'Stock In',
    'quantity', 30,
    'previousStock', 0,
    'newStock', 30,
    'referenceType', 'STOCK_TRANSFER',
    'referenceId', 'ST-2026-0003',
    'performedBy', 'u1',
    'performedByName', 'Admin User',
    'reason', 'Stock Transfer - In',
    'notes', 'Transfer from Main Warehouse',
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%dT%H:%i:%s.000Z')
))
ON DUPLICATE KEY UPDATE id = id;

-- Verify demo data insertion
SELECT 'Demo stock transfers created:' as info, COUNT(*) as count FROM stock_transfers WHERE id LIKE 'st_demo_%';
SELECT 'Demo inventory movements created:' as info, COUNT(*) as count FROM inventory_movements WHERE id LIKE 'mov_st_demo_%';

-- Show summary of demo transfers by status
SELECT 
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) as status,
    COUNT(*) as count
FROM stock_transfers 
WHERE id LIKE 'st_demo_%'
GROUP BY JSON_UNQUOTE(JSON_EXTRACT(data, '$.status'));