-- =====================================================================
-- STEP 2: Add Location Data
-- Run this second in phpMyAdmin
-- =====================================================================

USE ramyum_db;

-- Insert the 4 required locations
INSERT INTO locations (id, data) VALUES
('loc1', JSON_OBJECT(
    'id', 'loc1',
    'name', 'Main Warehouse',
    'code', 'WH',
    'type', 'Warehouse',
    'address', '123 Industrial Avenue, Manila',
    'manager', 'Juan dela Cruz',
    'phone', '+63 2 8555 0001',
    'email', 'warehouse@ramyum.com',
    'status', 'Active',
    'capacity', 2000,
    'description', 'Primary storage and distribution center'
)),
('loc2', JSON_OBJECT(
    'id', 'loc2',
    'name', 'Branch 1 - Makati',
    'code', 'MKT',
    'type', 'Branch',
    'address', '456 Ayala Avenue, Makati City',
    'manager', 'Maria Santos',
    'phone', '+63 2 8555 0002',
    'email', 'makati@ramyum.com',
    'status', 'Active',
    'capacity', 500,
    'description', 'Makati retail branch with premium location'
)),
('loc3', JSON_OBJECT(
    'id', 'loc3',
    'name', 'Branch 2 - Quezon City',
    'code', 'QC',
    'type', 'Branch',
    'address', '789 Commonwealth Avenue, Quezon City',
    'manager', 'Ana Rodriguez',
    'phone', '+63 2 8555 0003',
    'email', 'qc@ramyum.com',
    'status', 'Active',
    'capacity', 400,
    'description', 'Quezon City retail branch with cold storage'
)),
('loc4', JSON_OBJECT(
    'id', 'loc4',
    'name', 'Storage Area - BGC',
    'code', 'BGC',
    'type', 'Storage',
    'address', '321 Bonifacio Global City, Taguig',
    'manager', 'Roberto Kim',
    'phone', '+63 2 8555 0004',
    'email', 'bgc@ramyum.com',
    'status', 'Active',
    'capacity', 1500,
    'description', 'Secondary storage facility for overflow inventory'
))
ON DUPLICATE KEY UPDATE data = VALUES(data);

-- Verify locations were created
SELECT 'Step 2 Complete: Locations Added' as status;
SELECT COUNT(*) as location_count FROM locations;
SELECT JSON_UNQUOTE(JSON_EXTRACT(data, '$.name')) as location_name 
FROM locations ORDER BY JSON_UNQUOTE(JSON_EXTRACT(data, '$.name'));