-- =====================================================================
-- RAM-YUM Capstone Demo Scenario Data
-- This creates the exact demonstration scenario for the pre-oral defense
-- =====================================================================

USE ramyum_db;

-- First, ensure we have the demo data loaded
-- (This assumes seed-demo-data.sql has been run first)

-- Create the demo Purchase Order: PO-2026-0001
INSERT INTO purchase_orders (id, data) VALUES
('demo_po_001', JSON_OBJECT(
    'id', 'demo_po_001',
    'poNumber', 'PO-2026-0001',
    'supplier', 'Seoul Food Distribution',
    'supplierId', 's1',
    'orderDate', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'),
    'expectedDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 7 DAY), '%Y-%m-%dT%H:%i:%s.000Z'),
    'status', 'Approved',
    'items', JSON_ARRAY(
        JSON_OBJECT(
            'productId', 'p1',
            'productName', 'Samyang Buldak Original',
            'quantity', 50,
            'unitCost', 65.00,
            'subtotal', 3250.00,
            'receivedQuantity', 0,
            'remainingQuantity', 50
        ),
        JSON_OBJECT(
            'productId', 'p2',
            'productName', 'Shin Ramyun',
            'quantity', 40,
            'unitCost', 75.00,
            'subtotal', 3000.00,
            'receivedQuantity', 0,
            'remainingQuantity', 40
        ),
        JSON_OBJECT(
            'productId', 'p3',
            'productName', 'Ottogi Jin Ramen',
            'quantity', 30,
            'unitCost', 50.00,
            'subtotal', 1500.00,
            'receivedQuantity', 0,
            'remainingQuantity', 30
        )
    ),
    'subtotal', 7750.00,
    'total', 7750.00,
    'notes', 'Demonstration order for capstone pre-oral defense',
    'createdBy', 'Admin User',
    'approvedBy', 'Admin User',
    'approvedAt', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'),
    'totalItems', 120,
    'receivedItems', 0,
    'remainingItems', 120
))
ON DUPLICATE KEY UPDATE data = VALUES(data);

-- Create some additional demo POs for variety
INSERT INTO purchase_orders (id, data) VALUES
('demo_po_002', JSON_OBJECT(
    'id', 'demo_po_002',
    'poNumber', 'PO-2026-0002',
    'supplier', 'K-Food Wholesale Trading',
    'supplierId', 's2',
    'orderDate', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 3 DAY), '%Y-%m-%dT%H:%i:%s.000Z'),
    'expectedDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 4 DAY), '%Y-%m-%dT%H:%i:%s.000Z'),
    'status', 'Pending',
    'items', JSON_ARRAY(
        JSON_OBJECT(
            'productId', 'p5',
            'productName', 'Nongshim Neoguri',
            'quantity', 25,
            'unitCost', 72.00,
            'subtotal', 1800.00,
            'receivedQuantity', 0,
            'remainingQuantity', 25
        ),
        JSON_OBJECT(
            'productId', 'p6',
            'productName', 'Nongshim Chapagetti',
            'quantity', 20,
            'unitCost', 69.00,
            'subtotal', 1380.00,
            'receivedQuantity', 0,
            'remainingQuantity', 20
        )
    ),
    'subtotal', 3180.00,
    'total', 3180.00,
    'notes', 'Secondary supplier order',
    'createdBy', 'Admin User',
    'totalItems', 45,
    'receivedItems', 0,
    'remainingItems', 45
)),
('demo_po_003', JSON_OBJECT(
    'id', 'demo_po_003',
    'poNumber', 'PO-2026-0003',
    'supplier', 'Asia Grocery Supply',
    'supplierId', 's3',
    'orderDate', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%dT%H:%i:%s.000Z'),
    'expectedDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 2 DAY), '%Y-%m-%dT%H:%i:%s.000Z'),
    'status', 'Fully Received',
    'items', JSON_ARRAY(
        JSON_OBJECT(
            'productId', 'p10',
            'productName', 'Korean Seaweed Snack',
            'quantity', 15,
            'unitCost', 95.00,
            'subtotal', 1425.00,
            'receivedQuantity', 15,
            'remainingQuantity', 0
        )
    ),
    'subtotal', 1425.00,
    'total', 1425.00,
    'notes', 'Completed delivery for demo',
    'createdBy', 'Admin User',
    'approvedBy', 'Admin User',
    'approvedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%dT%H:%i:%s.000Z'),
    'totalItems', 15,
    'receivedItems', 15,
    'remainingItems', 0,
    'lastReceived', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
))
ON DUPLICATE KEY UPDATE data = VALUES(data);

-- Create a sample receiving record for the completed PO
INSERT INTO receivings (id, data) VALUES
('demo_gr_001', JSON_OBJECT(
    'id', 'demo_gr_001',
    'receivingNumber', 'GR-2026-0001',
    'poId', 'demo_po_003',
    'poNumber', 'PO-2026-0003',
    'supplierId', 's3',
    'supplier', 'Asia Grocery Supply',
    'receivedDate', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'),
    'receivedBy', 'Admin User',
    'totalReceived', 15,
    'totalValue', 1425.00,
    'items', JSON_ARRAY(
        JSON_OBJECT(
            'productId', 'p10',
            'productName', 'Korean Seaweed Snack',
            'orderedQuantity', 15,
            'previouslyReceived', 0,
            'quantityReceived', 15,
            'newTotalReceived', 15,
            'unitCost', 95.00,
            'subtotal', 1425.00
        )
    ),
    'notes', 'Complete delivery received in good condition',
    'status', 'Completed'
))
ON DUPLICATE KEY UPDATE data = VALUES(data);

-- Create some sample stock movements to show receiving history
INSERT INTO inventory_movements (id, data) VALUES
('demo_mov_001', JSON_OBJECT(
    'id', 'demo_mov_001',
    'productId', 'p10',
    'productName', 'Korean Seaweed Snack',
    'sku', 'KS-010',
    'date', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'),
    'type', 'Stock In',
    'quantity', 15,
    'previousBalance', 40,
    'newBalance', 55,
    'change', 15,
    'reason', 'Purchase Order Receiving',
    'notes', 'Received from Asia Grocery Supply via PO-2026-0003',
    'user', 'Admin User',
    'referenceType', 'RECEIVING',
    'referenceId', 'GR-2026-0001',
    'referencePO', 'PO-2026-0003',
    'unitCost', 95.00
)),
('demo_mov_002', JSON_OBJECT(
    'id', 'demo_mov_002',
    'productId', 'p1',
    'productName', 'Samyang Buldak Original',
    'sku', 'SB-001',
    'date', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 DAY), '%Y-%m-%dT%H:%i:%s.000Z'),
    'type', 'Adjustment',
    'quantity', 5,
    'previousBalance', 50,
    'newBalance', 45,
    'change', -5,
    'reason', 'Inventory Count',
    'notes', 'Cycle count adjustment - damaged items removed',
    'user', 'Admin User',
    'referenceType', 'MANUAL',
    'referenceId', 'ADJ-001234'
)),
('demo_mov_003', JSON_OBJECT(
    'id', 'demo_mov_003',
    'productId', 'p2',
    'productName', 'Shin Ramyun',
    'sku', 'SR-002',
    'date', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%dT%H:%i:%s.000Z'),
    'type', 'Stock Out',
    'quantity', 8,
    'previousBalance', 40,
    'newBalance', 32,
    'change', -8,
    'reason', 'Sales',
    'notes', 'Customer order fulfillment',
    'user', 'Staff User',
    'referenceType', 'MANUAL',
    'referenceId', 'SALE-001'
))
ON DUPLICATE KEY UPDATE data = VALUES(data);

-- Update product stock to reflect the movements
UPDATE products 
SET data = JSON_SET(data, '$.stock', 55, '$.status', 'In Stock', '$.lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'))
WHERE id = 'p10';

UPDATE products 
SET data = JSON_SET(data, '$.stock', 45, '$.status', 'In Stock', '$.lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'))
WHERE id = 'p1';

UPDATE products 
SET data = JSON_SET(data, '$.stock', 32, '$.status', 'In Stock', '$.lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'))
WHERE id = 'p2';

-- Verification queries
SELECT 'Demo Purchase Orders:' as info;
SELECT 
    JSON_EXTRACT(data, '$.poNumber') as po_number,
    JSON_EXTRACT(data, '$.supplier') as supplier,
    JSON_EXTRACT(data, '$.status') as status,
    JSON_EXTRACT(data, '$.total') as total_php
FROM purchase_orders 
WHERE id LIKE 'demo_po_%'
ORDER BY JSON_EXTRACT(data, '$.poNumber');

SELECT 'Demo Receiving Records:' as info;
SELECT 
    JSON_EXTRACT(data, '$.receivingNumber') as gr_number,
    JSON_EXTRACT(data, '$.poNumber') as po_number,
    JSON_EXTRACT(data, '$.totalReceived') as items_received,
    JSON_EXTRACT(data, '$.totalValue') as value_php
FROM receivings 
WHERE id LIKE 'demo_gr_%'
ORDER BY JSON_EXTRACT(data, '$.receivingNumber');

SELECT 'Current Stock Levels:' as info;
SELECT 
    JSON_EXTRACT(data, '$.name') as product_name,
    JSON_EXTRACT(data, '$.stock') as current_stock,
    JSON_EXTRACT(data, '$.price') as price_php,
    JSON_EXTRACT(data, '$.status') as stock_status
FROM products 
WHERE id IN ('p1', 'p2', 'p3', 'p10')
ORDER BY JSON_EXTRACT(data, '$.name');