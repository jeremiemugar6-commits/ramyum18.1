-- =====================================================================
-- Stock Transfer Module Database Schema
-- Enhanced tables for comprehensive stock transfer workflow
-- =====================================================================

USE ramyum_db;

-- ---------------------------------------------------------------------
-- LOCATIONS/BRANCHES — Storage locations for inventory
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS locations (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Insert default locations for demonstration
INSERT INTO locations (id, data) VALUES
('loc1', JSON_OBJECT(
    'id', 'loc1',
    'name', 'Main Warehouse',
    'code', 'MAIN',
    'type', 'Warehouse',
    'address', 'Building A, RAM-YUM Central Hub, Manila',
    'manager', 'Maria Santos',
    'phone', '+63 2 8555 0001',
    'email', 'warehouse@ramyum.com',
    'status', 'Active',
    'capacity', 10000,
    'description', 'Primary storage facility with temperature control'
)),
('loc2', JSON_OBJECT(
    'id', 'loc2',
    'name', 'Branch 1 - Makati',
    'code', 'BR01',
    'type', 'Branch',
    'address', '123 Ayala Avenue, Makati City',
    'manager', 'Juan Dela Cruz',
    'phone', '+63 2 8555 0002',
    'email', 'makati@ramyum.com',
    'status', 'Active',
    'capacity', 500,
    'description', 'Makati retail branch and mini-warehouse'
)),
('loc3', JSON_OBJECT(
    'id', 'loc3',
    'name', 'Branch 2 - Quezon City',
    'code', 'BR02',
    'type', 'Branch',
    'address', '456 Commonwealth Avenue, Quezon City',
    'manager', 'Ana Rodriguez',
    'phone', '+63 2 8555 0003',
    'email', 'qc@ramyum.com',
    'status', 'Active',
    'capacity', 400,
    'description', 'Quezon City retail branch with cold storage'
)),
('loc4', JSON_OBJECT(
    'id', 'loc4',
    'name', 'Storage Area - BGC',
    'code', 'BGC',
    'type', 'Storage',
    'address', '789 Bonifacio Global City, Taguig',
    'manager', 'Roberto Kim',
    'phone', '+63 2 8555 0004',
    'email', 'bgc@ramyum.com',
    'status', 'Active',
    'capacity', 1500,
    'description', 'Secondary storage facility for overflow inventory'
))
ON DUPLICATE KEY UPDATE id = id;

-- ---------------------------------------------------------------------
-- INVENTORY LOCATIONS — Track inventory per location
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS inventory_locations (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Create initial inventory distribution for demonstration
-- Main Warehouse gets majority of stock, branches get smaller amounts
INSERT INTO inventory_locations (id, data) VALUES
-- Samyang Buldak Original distribution
('inv_p1_loc1', JSON_OBJECT(
    'id', 'inv_p1_loc1',
    'productId', 'p1',
    'locationId', 'loc1',
    'quantity', 100,
    'reservedQuantity', 0,
    'availableQuantity', 100,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('inv_p1_loc2', JSON_OBJECT(
    'id', 'inv_p1_loc2',
    'productId', 'p1',
    'locationId', 'loc2',
    'quantity', 30,
    'reservedQuantity', 0,
    'availableQuantity', 30,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('inv_p1_loc3', JSON_OBJECT(
    'id', 'inv_p1_loc3',
    'productId', 'p1',
    'locationId', 'loc3',
    'quantity', 20,
    'reservedQuantity', 0,
    'availableQuantity', 20,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),

-- Shin Ramyun distribution
('inv_p2_loc1', JSON_OBJECT(
    'id', 'inv_p2_loc1',
    'productId', 'p2',
    'locationId', 'loc1',
    'quantity', 80,
    'reservedQuantity', 0,
    'availableQuantity', 80,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('inv_p2_loc2', JSON_OBJECT(
    'id', 'inv_p2_loc2',
    'productId', 'p2',
    'locationId', 'loc2',
    'quantity', 25,
    'reservedQuantity', 0,
    'availableQuantity', 25,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('inv_p2_loc4', JSON_OBJECT(
    'id', 'inv_p2_loc4',
    'productId', 'p2',
    'locationId', 'loc4',
    'quantity', 15,
    'reservedQuantity', 0,
    'availableQuantity', 15,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),

-- Ottogi Jin Ramen distribution
('inv_p3_loc1', JSON_OBJECT(
    'id', 'inv_p3_loc1',
    'productId', 'p3',
    'locationId', 'loc1',
    'quantity', 60,
    'reservedQuantity', 0,
    'availableQuantity', 60,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('inv_p3_loc3', JSON_OBJECT(
    'id', 'inv_p3_loc3',
    'productId', 'p3',
    'locationId', 'loc3',
    'quantity', 40,
    'reservedQuantity', 0,
    'availableQuantity', 40,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),

-- Korean Seaweed Snack distribution
('inv_p10_loc1', JSON_OBJECT(
    'id', 'inv_p10_loc1',
    'productId', 'p10',
    'locationId', 'loc1',
    'quantity', 120,
    'reservedQuantity', 0,
    'availableQuantity', 120,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('inv_p10_loc2', JSON_OBJECT(
    'id', 'inv_p10_loc2',
    'productId', 'p10',
    'locationId', 'loc2',
    'quantity', 50,
    'reservedQuantity', 0,
    'availableQuantity', 50,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('inv_p10_loc4', JSON_OBJECT(
    'id', 'inv_p10_loc4',
    'productId', 'p10',
    'locationId', 'loc4',
    'quantity', 30,
    'reservedQuantity', 0,
    'availableQuantity', 30,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
))
ON DUPLICATE KEY UPDATE id = id;

-- Note: The existing stock_transfers and inventory_movements tables from schema.sql 
-- will be used for storing transfer records and transaction history.

-- ---------------------------------------------------------------------
-- AUDIT LOG for Stock Transfer Operations
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS stock_transfer_audit (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    transfer_id VARCHAR(40) NOT NULL,
    action_type VARCHAR(50) NOT NULL,
    user_id     VARCHAR(40) NOT NULL,
    user_name   VARCHAR(150) NOT NULL,
    details     JSON NULL,
    ip_address  VARCHAR(64) NULL,
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_transfer_id (transfer_id),
    INDEX idx_action_type (action_type),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

-- Add some sample audit logs for demonstration
INSERT INTO stock_transfer_audit (transfer_id, action_type, user_id, user_name, details) VALUES
('demo_transfer_1', 'TRANSFER_CREATED', 'u2', 'Staff User', JSON_OBJECT(
    'transferNumber', 'ST-2026-0001', 
    'sourceLocation', 'Main Warehouse',
    'destinationLocation', 'Branch 1 - Makati',
    'itemCount', 2
)),
('demo_transfer_1', 'TRANSFER_SUBMITTED', 'u2', 'Staff User', JSON_OBJECT(
    'transferNumber', 'ST-2026-0001',
    'status', 'Pending Approval'
)),
('demo_transfer_1', 'TRANSFER_APPROVED', 'u1', 'Admin User', JSON_OBJECT(
    'transferNumber', 'ST-2026-0001',
    'status', 'Approved',
    'approvalRemarks', 'Approved for branch restocking'
))
ON DUPLICATE KEY UPDATE id = id;

-- Verify table creation
SELECT 'Stock Transfer tables created successfully' as status;
SELECT 'Locations count:' as info, COUNT(*) as count FROM locations;
SELECT 'Inventory locations count:' as info, COUNT(*) as count FROM inventory_locations;