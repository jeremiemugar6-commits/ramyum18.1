-- =====================================================================
-- COMPLETE STOCK TRANSFER DATABASE SETUP
-- ONE FILE CONTAINS EVERYTHING - JUST RUN THIS ONCE!
-- =====================================================================

USE ramyum_db;

-- =====================================================================
-- STEP 1: CREATE ALL TABLES
-- =====================================================================

-- Create locations table
CREATE TABLE IF NOT EXISTS locations (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Create inventory_locations table  
CREATE TABLE IF NOT EXISTS inventory_locations (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Create stock_transfer_audit table
CREATE TABLE IF NOT EXISTS stock_transfer_audit (
    id            VARCHAR(40) PRIMARY KEY,
    transfer_id   VARCHAR(100) NOT NULL,
    action        VARCHAR(50) NOT NULL,
    performed_by  VARCHAR(40) NOT NULL,
    performed_by_name VARCHAR(255) NOT NULL,
    details       TEXT,
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_transfer_id (transfer_id),
    INDEX idx_action (action),
    INDEX idx_performed_by (performed_by),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

-- =====================================================================
-- STEP 2: INSERT ALL LOCATIONS DATA
-- =====================================================================

-- Insert the 4 required locations
INSERT INTO locations (id, data) VALUES
('loc1', JSON_OBJECT(
    'id', 'loc1',
    'name', 'Main Warehouse',
    'code', 'WH',
    'type', 'Warehouse',
    'address', '123 Industrial Avenue, Manila',
    'manager', 'Juan dela Cruz',
    'phone', '+63 2 8555 0001',
    'email', 'warehouse@ramyum.com',
    'status', 'Active',
    'capacity', 2000,
    'description', 'Primary storage and distribution center'
)),
('loc2', JSON_OBJECT(
    'id', 'loc2',
    'name', 'Branch 1 - Makati',
    'code', 'MKT',
    'type', 'Branch',
    'address', '456 Ayala Avenue, Makati City',
    'manager', 'Maria Santos',
    'phone', '+63 2 8555 0002',
    'email', 'makati@ramyum.com',
    'status', 'Active',
    'capacity', 500,
    'description', 'Makati retail branch with premium location'
)),
('loc3', JSON_OBJECT(
    'id', 'loc3',
    'name', 'Branch 2 - Quezon City',
    'code', 'QC',
    'type', 'Branch',
    'address', '789 Commonwealth Avenue, Quezon City',
    'manager', 'Ana Rodriguez',
    'phone', '+63 2 8555 0003',
    'email', 'qc@ramyum.com',
    'status', 'Active',
    'capacity', 400,
    'description', 'Quezon City retail branch with cold storage'
)),
('loc4', JSON_OBJECT(
    'id', 'loc4',
    'name', 'Storage Area - BGC',
    'code', 'BGC',
    'type', 'Storage',
    'address', '321 Bonifacio Global City, Taguig',
    'manager', 'Roberto Kim',
    'phone', '+63 2 8555 0004',
    'email', 'bgc@ramyum.com',
    'status', 'Active',
    'capacity', 1500,
    'description', 'Secondary storage facility for overflow inventory'
))
ON DUPLICATE KEY UPDATE data = VALUES(data);

-- =====================================================================
-- STEP 3: INSERT ALL INVENTORY DATA
-- =====================================================================

-- Add sample inventory across locations
INSERT INTO inventory_locations (id, data) VALUES
('inv_p1_loc1', JSON_OBJECT(
    'id', 'inv_p1_loc1',
    'productId', 'p1',
    'locationId', 'loc1',
    'quantity', 150,
    'reservedQuantity', 0,
    'availableQuantity', 150,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('inv_p1_loc2', JSON_OBJECT(
    'id', 'inv_p1_loc2',
    'productId', 'p1',
    'locationId', 'loc2',
    'quantity', 30,
    'reservedQuantity', 0,
    'availableQuantity', 30,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('inv_p2_loc1', JSON_OBJECT(
    'id', 'inv_p2_loc1',
    'productId', 'p2',
    'locationId', 'loc1',
    'quantity', 200,
    'reservedQuantity', 0,
    'availableQuantity', 200,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('inv_p2_loc2', JSON_OBJECT(
    'id', 'inv_p2_loc2',
    'productId', 'p2',
    'locationId', 'loc2',
    'quantity', 25,
    'reservedQuantity', 0,
    'availableQuantity', 25,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('inv_p3_loc1', JSON_OBJECT(
    'id', 'inv_p3_loc1',
    'productId', 'p3',
    'locationId', 'loc1',
    'quantity', 100,
    'reservedQuantity', 0,
    'availableQuantity', 100,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('inv_p4_loc1', JSON_OBJECT(
    'id', 'inv_p4_loc1',
    'productId', 'p4',
    'locationId', 'loc1',
    'quantity', 120,
    'reservedQuantity', 0,
    'availableQuantity', 120,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('inv_p5_loc1', JSON_OBJECT(
    'id', 'inv_p5_loc1',
    'productId', 'p5',
    'locationId', 'loc1',
    'quantity', 80,
    'reservedQuantity', 0,
    'availableQuantity', 80,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('inv_p5_loc2', JSON_OBJECT(
    'id', 'inv_p5_loc2',
    'productId', 'p5',
    'locationId', 'loc2',
    'quantity', 15,
    'reservedQuantity', 0,
    'availableQuantity', 15,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
))
ON DUPLICATE KEY UPDATE data = VALUES(data);

-- =====================================================================
-- STEP 4: INSERT ALL DEMO STOCK TRANSFER DATA
-- =====================================================================

-- Add comprehensive demo stock transfer records
INSERT INTO stock_transfers (id, data) VALUES
('st_demo_001', JSON_OBJECT(
    'id', 'st_demo_001',
    'transferNumber', 'ST-2026-0101',
    'transferDate', DATE_FORMAT(NOW(), '%Y-%m-%d'),
    'sourceLocationId', 'loc1',
    'sourceLocationName', 'Main Warehouse',
    'destinationLocationId', 'loc2',
    'destinationLocationName', 'Branch 1 - Makati',
    'requestedBy', 'u2',
    'requestedByName', 'Staff User',
    'status', 'Pending Approval',
    'priority', 'High',
    'remarks', 'URGENT: Branch 1 nearly out of stock on bestsellers. Weekend rush expected. Need immediate approval and transfer.',
    'items', JSON_ARRAY(
        JSON_OBJECT(
            'productId', 'p1',
            'productName', 'Samyang Buldak Original',
            'sku', 'SB-001',
            'quantity', 50,
            'unit', 'pcs',
            'sourceStock', 150,
            'destinationStock', 30,
            'notes', 'Critical - Only 30 units left at branch'
        ),
        JSON_OBJECT(
            'productId', 'p2',
            'productName', 'Shin Ramyun',
            'sku', 'SR-002',
            'quantity', 40,
            'unit', 'pcs',
            'sourceStock', 200,
            'destinationStock', 25,
            'notes', 'Below minimum stock level'
        ),
        JSON_OBJECT(
            'productId', 'p5',
            'productName', 'Chapagetti',
            'sku', 'CP-005',
            'quantity', 25,
            'unit', 'pcs',
            'sourceStock', 80,
            'destinationStock', 15,
            'notes', 'Popular item - high demand'
        )
    ),
    'totalItems', 115,
    'estimatedValue', 2875.00,
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 HOUR), '%Y-%m-%dT%H:%i:%s.000Z'),
    'submittedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')
)),

('st_demo_002', JSON_OBJECT(
    'id', 'st_demo_002',
    'transferNumber', 'ST-2026-0102',
    'transferDate', DATE_FORMAT(NOW(), '%Y-%m-%d'),
    'sourceLocationId', 'loc1',
    'sourceLocationName', 'Main Warehouse',
    'destinationLocationId', 'loc3',
    'destinationLocationName', 'Branch 2 - Quezon City',
    'requestedBy', 'u3',
    'requestedByName', 'Manager User',
    'status', 'Pending Approval',
    'priority', 'Medium',
    'remarks', 'New product launch - Korean Fried Chicken Ramen. Initial distribution to QC branch for market testing.',
    'items', JSON_ARRAY(
        JSON_OBJECT(
            'productId', 'p10',
            'productName', 'Korean Seaweed Snack',
            'sku', 'KS-010',
            'quantity', 30,
            'unit', 'pcs',
            'sourceStock', 120,
            'destinationStock', 50,
            'notes', 'New product - market test'
        )
    ),
    'totalItems', 30,
    'estimatedValue', 900.00,
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%dT%H:%i:%s.000Z'),
    'submittedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')
)),

('st_demo_003', JSON_OBJECT(
    'id', 'st_demo_003',
    'transferNumber', 'ST-2026-0103',
    'transferDate', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%d'),
    'sourceLocationId', 'loc1',
    'sourceLocationName', 'Main Warehouse',
    'destinationLocationId', 'loc4',
    'destinationLocationName', 'Storage Area - BGC',
    'requestedBy', 'u2',
    'requestedByName', 'Staff User',
    'status', 'Approved',
    'priority', 'Low',
    'remarks', 'Seasonal inventory redistribution. Moving winter stock to climate-controlled storage.',
    'items', JSON_ARRAY(
        JSON_OBJECT(
            'productId', 'p3',
            'productName', 'Ottogi Jin Ramen',
            'sku', 'OJ-003',
            'quantity', 50,
            'unit', 'pcs',
            'sourceStock', 100,
            'destinationStock', 0,
            'transferredQuantity', 50,
            'notes', 'Bulk transfer completed'
        ),
        JSON_OBJECT(
            'productId', 'p4',
            'productName', 'Nong Shim Cup Noodles',
            'sku', 'NS-004',
            'quantity', 30,
            'unit', 'pcs',
            'sourceStock', 120,
            'destinationStock', 0,
            'transferredQuantity', 30,
            'notes', 'Storage optimization'
        )
    ),
    'totalItems', 80,
    'estimatedValue', 1600.00,
    'approvedBy', 'u1',
    'approvedByName', 'Admin User',
    'approvedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 6 HOUR), '%Y-%m-%dT%H:%i:%s.000Z'),
    'approvalRemarks', 'Approved for inventory optimization. BGC facility has adequate climate control.',
    'completedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%dT%H:%i:%s.000Z'),
    'completedBy', 'u2',
    'completedByName', 'Staff User',
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%dT%H:%i:%s.000Z'),
    'submittedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 22 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')
)),

('st_demo_004', JSON_OBJECT(
    'id', 'st_demo_004',
    'transferNumber', 'ST-2026-0104',
    'transferDate', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 DAY), '%Y-%m-%d'),
    'sourceLocationId', 'loc2',
    'sourceLocationName', 'Branch 1 - Makati',
    'destinationLocationId', 'loc3',
    'destinationLocationName', 'Branch 2 - Quezon City',
    'requestedBy', 'u2',
    'requestedByName', 'Staff User',
    'status', 'Rejected',
    'priority', 'Medium',
    'remarks', 'Customer special order requires 60 units of premium ramen. Requesting transfer from Makati branch.',
    'items', JSON_ARRAY(
        JSON_OBJECT(
            'productId', 'p1',
            'productName', 'Samyang Buldak Original',
            'sku', 'SB-001',
            'quantity', 60,
            'unit', 'pcs',
            'sourceStock', 30,
            'destinationStock', 20,
            'notes', 'Special customer order - bulk purchase'
        )
    ),
    'totalItems', 60,
    'estimatedValue', 1800.00,
    'rejectedBy', 'u3',
    'rejectedByName', 'Manager User',
    'rejectedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%dT%H:%i:%s.000Z'),
    'rejectionReason', 'Insufficient inventory at source. Branch 1 has only 30 units but requires minimum 20 units for daily operations. Recommend ordering from Main Warehouse instead.',
    'alternativeAction', 'Transfer from Main Warehouse (150 units available) or reduce order quantity to 10 units.',
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 DAY), '%Y-%m-%dT%H:%i:%s.000Z'),
    'submittedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 46 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')
)),

('st_demo_005', JSON_OBJECT(
    'id', 'st_demo_005',
    'transferNumber', 'ST-2026-0105',
    'transferDate', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 3 HOUR), '%Y-%m-%d'),
    'sourceLocationId', 'loc4',
    'sourceLocationName', 'Storage Area - BGC',
    'destinationLocationId', 'loc2',
    'destinationLocationName', 'Branch 1 - Makati',
    'requestedBy', 'u3',
    'requestedByName', 'Manager User',
    'status', 'Approved',
    'priority', 'Critical',
    'remarks', 'EMERGENCY: Main supplier delivery delayed. Branch 1 experiencing stockout during peak hours. Emergency transfer from BGC storage.',
    'items', JSON_ARRAY(
        JSON_OBJECT(
            'productId', 'p3',
            'productName', 'Ottogi Jin Ramen',
            'sku', 'OJ-003',
            'quantity', 25,
            'unit', 'pcs',
            'sourceStock', 50,
            'destinationStock', 0,
            'notes', 'Emergency stockout coverage'
        ),
        JSON_OBJECT(
            'productId', 'p4',
            'productName', 'Nong Shim Cup Noodles',
            'sku', 'NS-004',
            'quantity', 20,
            'unit', 'pcs',
            'sourceStock', 30,
            'destinationStock', 0,
            'notes', 'Backup inventory activation'
        )
    ),
    'totalItems', 45,
    'estimatedValue', 900.00,
    'approvedBy', 'u1',
    'approvedByName', 'Admin User',
    'approvedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 HOUR), '%Y-%m-%dT%H:%i:%s.000Z'),
    'approvalRemarks', 'EMERGENCY APPROVED: Immediate transfer authorized. Courier dispatch arranged.',
    'fastTrack', true,
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 3 HOUR), '%Y-%m-%dT%H:%i:%s.000Z'),
    'submittedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 3 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')
))
ON DUPLICATE KEY UPDATE id = id;

-- =====================================================================
-- STEP 5: INSERT ALL AUDIT TRAIL DATA
-- =====================================================================

-- Clear existing demo audit entries
DELETE FROM stock_transfer_audit WHERE transfer_id LIKE 'ST-2026-01%';

-- Add comprehensive audit trail entries for all transfers
INSERT INTO stock_transfer_audit (id, transfer_id, action, performed_by, performed_by_name, details, created_at) VALUES

-- ST-2026-0101: Urgent restock scenario audit trail
('audit_001', 'ST-2026-0101', 'CREATED', 'u2', 'Staff User', 'Transfer created for urgent Branch 1 restock', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 HOUR), '%Y-%m-%d %H:%i:%s')),
('audit_002', 'ST-2026-0101', 'SUBMITTED', 'u2', 'Staff User', 'Transfer submitted for manager approval', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 HOUR), '%Y-%m-%d %H:%i:%s')),

-- ST-2026-0102: New product launch scenario audit trail  
('audit_003', 'ST-2026-0102', 'CREATED', 'u3', 'Manager User', 'Transfer created for new product distribution', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%d %H:%i:%s')),
('audit_004', 'ST-2026-0102', 'SUBMITTED', 'u3', 'Manager User', 'Transfer submitted for admin approval', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%d %H:%i:%s')),

-- ST-2026-0103: Completed transfer scenario audit trail
('audit_005', 'ST-2026-0103', 'CREATED', 'u2', 'Staff User', 'Transfer created for inventory optimization', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%d %H:%i:%s')),
('audit_006', 'ST-2026-0103', 'SUBMITTED', 'u2', 'Staff User', 'Transfer submitted for approval', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 22 HOUR), '%Y-%m-%d %H:%i:%s')),
('audit_007', 'ST-2026-0103', 'APPROVED', 'u1', 'Admin User', 'Transfer approved for execution', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 6 HOUR), '%Y-%m-%d %H:%i:%s')),
('audit_008', 'ST-2026-0103', 'COMPLETED', 'u2', 'Staff User', 'Inventory transfer completed successfully', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%d %H:%i:%s')),

-- ST-2026-0104: Rejected transfer scenario audit trail
('audit_009', 'ST-2026-0104', 'CREATED', 'u2', 'Staff User', 'Transfer created for special customer order', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 DAY), '%Y-%m-%d %H:%i:%s')),
('audit_010', 'ST-2026-0104', 'SUBMITTED', 'u2', 'Staff User', 'Transfer submitted for manager review', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 46 HOUR), '%Y-%m-%d %H:%i:%s')),
('audit_011', 'ST-2026-0104', 'REJECTED', 'u3', 'Manager User', 'Transfer rejected due to insufficient source inventory', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%d %H:%i:%s')),

-- ST-2026-0105: Emergency transfer scenario audit trail
('audit_012', 'ST-2026-0105', 'CREATED', 'u3', 'Manager User', 'Emergency transfer created for stockout situation', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 3 HOUR), '%Y-%m-%d %H:%i:%s')),
('audit_013', 'ST-2026-0105', 'SUBMITTED', 'u3', 'Manager User', 'Emergency transfer submitted for immediate approval', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 3 HOUR), '%Y-%m-%d %H:%i:%s')),
('audit_014', 'ST-2026-0105', 'APPROVED', 'u1', 'Admin User', 'Emergency transfer approved with fast-track priority', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 HOUR), '%Y-%m-%d %H:%i:%s'))

ON DUPLICATE KEY UPDATE id = id;

-- =====================================================================
-- STEP 6: ADD INVENTORY MOVEMENTS FOR COMPLETED TRANSFERS
-- =====================================================================

-- Movements for completed transfer (st_demo_003)
INSERT INTO inventory_movements (id, data) VALUES
('mov_st_demo_003_out_p3', JSON_OBJECT(
    'id', 'mov_st_demo_003_out_p3',
    'productId', 'p3',
    'productName', 'Ottogi Jin Ramen',
    'locationId', 'loc1',
    'locationName', 'Main Warehouse',
    'movementType', 'Stock Out',
    'quantity', -50,
    'previousStock', 100,
    'newStock', 50,
    'referenceType', 'STOCK_TRANSFER',
    'referenceId', 'ST-2026-0103',
    'performedBy', 'u1',
    'performedByName', 'Admin User',
    'reason', 'Stock Transfer - Out',
    'notes', 'Transfer to BGC storage facility',
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('mov_st_demo_003_in_p3', JSON_OBJECT(
    'id', 'mov_st_demo_003_in_p3',
    'productId', 'p3',
    'productName', 'Ottogi Jin Ramen',
    'locationId', 'loc4',
    'locationName', 'Storage Area - BGC',
    'movementType', 'Stock In',
    'quantity', 50,
    'previousStock', 0,
    'newStock', 50,
    'referenceType', 'STOCK_TRANSFER',
    'referenceId', 'ST-2026-0103',
    'performedBy', 'u1',
    'performedByName', 'Admin User',
    'reason', 'Stock Transfer - In',
    'notes', 'Received from Main Warehouse',
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('mov_st_demo_003_out_p4', JSON_OBJECT(
    'id', 'mov_st_demo_003_out_p4',
    'productId', 'p4',
    'productName', 'Nong Shim Cup Noodles',
    'locationId', 'loc1',
    'locationName', 'Main Warehouse',
    'movementType', 'Stock Out',
    'quantity', -30,
    'previousStock', 120,
    'newStock', 90,
    'referenceType', 'STOCK_TRANSFER',
    'referenceId', 'ST-2026-0103',
    'performedBy', 'u1',
    'performedByName', 'Admin User',
    'reason', 'Stock Transfer - Out',
    'notes', 'Storage optimization transfer',
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('mov_st_demo_003_in_p4', JSON_OBJECT(
    'id', 'mov_st_demo_003_in_p4',
    'productId', 'p4',
    'productName', 'Nong Shim Cup Noodles',
    'locationId', 'loc4',
    'locationName', 'Storage Area - BGC',
    'movementType', 'Stock In',
    'quantity', 30,
    'previousStock', 0,
    'newStock', 30,
    'referenceType', 'STOCK_TRANSFER',
    'referenceId', 'ST-2026-0103',
    'performedBy', 'u1',
    'performedByName', 'Admin User',
    'reason', 'Stock Transfer - In',
    'notes', 'Received from Main Warehouse',
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')
))
ON DUPLICATE KEY UPDATE id = id;

-- =====================================================================
-- FINAL VERIFICATION AND SUMMARY
-- =====================================================================

SELECT '==================== COMPLETE DATABASE SETUP FINISHED! ====================' as info;

-- Verify all data was inserted correctly
SELECT 'LOCATIONS:' as table_name, COUNT(*) as record_count FROM locations;
SELECT 'INVENTORY:' as table_name, COUNT(*) as record_count FROM inventory_locations;
SELECT 'STOCK TRANSFERS:' as table_name, COUNT(*) as record_count FROM stock_transfers WHERE id LIKE 'st_demo_%';
SELECT 'AUDIT TRAIL:' as table_name, COUNT(*) as record_count FROM stock_transfer_audit;
SELECT 'INVENTORY MOVEMENTS:' as table_name, COUNT(*) as record_count FROM inventory_movements WHERE id LIKE 'mov_st_demo_%';

-- Show the created locations
SELECT 
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.name')) as location_name,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.type')) as location_type,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) as status
FROM locations 
ORDER BY JSON_UNQUOTE(JSON_EXTRACT(data, '$.name'));

-- Show demo transfer summary
SELECT 
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.transferNumber')) as transfer_number,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) as status,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.priority')) as priority,
    CONCAT(
        JSON_UNQUOTE(JSON_EXTRACT(data, '$.sourceLocationName')), 
        ' → ', 
        JSON_UNQUOTE(JSON_EXTRACT(data, '$.destinationLocationName'))
    ) as route
FROM stock_transfers 
WHERE id LIKE 'st_demo_%'
ORDER BY JSON_UNQUOTE(JSON_EXTRACT(data, '$.transferNumber'));

-- Show audit trail summary
SELECT 
    transfer_id,
    GROUP_CONCAT(action ORDER BY created_at SEPARATOR ' → ') as workflow
FROM stock_transfer_audit 
WHERE transfer_id LIKE 'ST-2026-01%'
GROUP BY transfer_id 
ORDER BY transfer_id;

SELECT '==================== SETUP COMPLETE! ====================' as status;
SELECT 'Now go to: Dashboard → Stock Transfer → Create Transfer' as next_step;
SELECT 'Both dropdowns should show 4 locations!' as expected_result;
SELECT '🎉 Your Stock Transfer module is ready for demonstration! 🎉' as final_message;