<?php
/**
 * Add Sample POR (Proof of Receiving) Data
 * Creates realistic POR records for demonstration
 */

require_once 'config/database.php';
require_once 'includes/functions.php';

$db = getDB();

echo "=== Adding Sample POR Data ===\n\n";

try {
    $db->beginTransaction();
    
    // Sample data arrays
    $suppliers = [
        ['id' => 'SUP001', 'name' => 'Manila Food Distributors Inc.'],
        ['id' => 'SUP002', 'name' => 'Quezon Wholesale Supplies'],
        ['id' => 'SUP003', 'name' => 'Cebu Fresh Foods Corp.'],
        ['id' => 'SUP004', 'name' => 'Davao Meat Products Inc.']
    ];
    
    $products = [
        ['id' => 'prod_beef_chuck', 'name' => 'Beef Chuck', 'sku' => 'BEEF-001', 'cost' => 450.00],
        ['id' => 'prod_pork_belly', 'name' => 'Pork Belly', 'sku' => 'PORK-001', 'cost' => 380.00],
        ['id' => 'prod_chicken_breast', 'name' => 'Chicken Breast', 'sku' => 'CHKN-001', 'cost' => 220.00],
        ['id' => 'prod_ramen_noodles', 'name' => 'Ramen Noodles', 'sku' => 'NOOD-001', 'cost' => 15.00],
        ['id' => 'prod_soy_sauce', 'name' => 'Soy Sauce', 'sku' => 'SAUC-001', 'cost' => 45.00],
        ['id' => 'prod_cooking_oil', 'name' => 'Cooking Oil', 'sku' => 'OIL-001', 'cost' => 120.00]
    ];
    
    $statuses = ['Completed', 'Completed', 'Completed', 'Draft', 'Completed'];
    $inspectionStatuses = ['Completed', 'Completed', 'Pending', 'In Progress', 'Completed'];
    
    // Create 8 sample POR records
    for ($i = 1; $i <= 8; $i++) {
        $porId = generate_id('por');
        $porNumber = sprintf("POR-2026-%04d", $i);
        $poNumber = sprintf("PO-2026-%04d", $i);
        
        $supplier = $suppliers[array_rand($suppliers)];
        $status = $statuses[array_rand($statuses)];
        $inspectionStatus = $inspectionStatuses[array_rand($inspectionStatuses)];
        
        // Receiving date (spread over last 30 days)
        $daysAgo = rand(1, 30);
        $receivingDate = date('Y-m-d H:i:s', strtotime("-$daysAgo days"));
        
        // Random item count (2-4 items per POR)
        $itemCount = rand(2, 4);
        $totalOrdered = 0;
        $totalReceived = 0;
        $totalAccepted = 0;
        $totalRejected = 0;
        $totalValue = 0;
        
        // Generate items for this POR
        $porItems = [];
        $selectedProducts = array_rand($products, $itemCount);
        if (!is_array($selectedProducts)) $selectedProducts = [$selectedProducts];
        
        foreach ($selectedProducts as $prodIdx) {
            $product = $products[$prodIdx];
            $ordered = rand(20, 100);
            $received = $ordered - rand(0, 5); // Sometimes receive less
            $rejected = rand(0, min(5, $received)); // Random rejects
            $accepted = $received - $rejected;
            $damaged = rand(0, min(2, $rejected)); // Some rejected items are damaged
            
            $itemValue = $accepted * $product['cost'];
            
            $totalOrdered += $ordered;
            $totalReceived += $received;
            $totalAccepted += $accepted;
            $totalRejected += $rejected;
            $totalValue += $itemValue;
            
            $porItems[] = [
                'id' => generate_id('por_item'),
                'product' => $product,
                'ordered' => $ordered,
                'received' => $received,
                'accepted' => $accepted,
                'rejected' => $rejected,
                'damaged' => $damaged,
                'unitCost' => $product['cost'],
                'totalCost' => $itemValue
            ];
        }
        
        // Inventory updated for completed PORs only
        $inventoryUpdated = ($status === 'Completed' && $inspectionStatus === 'Completed') ? 1 : 0;
        
        // Insert POR record
        $stmt = $db->prepare("
            INSERT INTO proof_of_receiving (
                id, por_number, purchase_order_id, po_number,
                supplier_id, supplier_name, 
                received_by, received_by_name,
                receiving_date, receiving_time, 
                inspection_status, status,
                total_items, total_ordered, total_received, 
                total_accepted, total_rejected,
                total_value,
                inventory_updated, inventory_updated_at,
                inspection_notes, remarks,
                created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $porId,
            $porNumber,
            'PO_' . $i, // PO ID
            $poNumber,
            $supplier['id'],
            $supplier['name'],
            'admin', // received_by ID
            'System Admin', // received_by name
            $receivingDate,
            date('H:i:s', strtotime($receivingDate)),
            $inspectionStatus,
            $status,
            $itemCount,
            $totalOrdered,
            $totalReceived,
            $totalAccepted,
            $totalRejected,
            $totalValue,
            $inventoryUpdated,
            $inventoryUpdated ? $receivingDate : null,
            $inspectionStatus === 'Completed' ? 'All items inspected and verified' : 'Inspection in progress',
            rand(0, 1) ? 'Delivery on time' : null,
            $receivingDate,
            $receivingDate
        ]);
        
        echo "✓ Created POR: $porNumber (Status: $status, Inspection: $inspectionStatus)\n";
        
        // Insert POR items
        foreach ($porItems as $item) {
            $itemStmt = $db->prepare("
                INSERT INTO proof_of_receiving_items (
                    id, por_id, 
                    product_id, product_name, sku, unit,
                    ordered_quantity, received_quantity, 
                    accepted_quantity, rejected_quantity, damaged_quantity,
                    unit_cost, total_cost,
                    inspection_result, inspection_notes,
                    created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $inspectionResult = $item['rejected'] == 0 ? 'Pass' : ($item['accepted'] > 0 ? 'Conditional' : 'Fail');
            $inspectionNote = $item['rejected'] > 0 ? "Rejected {$item['rejected']} units due to quality issues" : 'All units acceptable';
            
            $itemStmt->execute([
                $item['id'],
                $porId,
                $item['product']['id'],
                $item['product']['name'],
                $item['product']['sku'],
                'kg',
                $item['ordered'],
                $item['received'],
                $item['accepted'],
                $item['rejected'],
                $item['damaged'],
                $item['unitCost'],
                $item['totalCost'],
                $inspectionResult,
                $inspectionNote,
                $receivingDate,
                $receivingDate
            ]);
            
            echo "  • {$item['product']['name']}: Ordered {$item['ordered']}, Received {$item['received']}, Accepted {$item['accepted']}, Rejected {$item['rejected']}\n";
        }
        
        echo "\n";
    }
    
    $db->commit();
    
    echo "=== Success! ===\n";
    echo "Added 8 sample POR records with items\n";
    echo "\nYou can now:\n";
    echo "1. Refresh the POR module in your dashboard\n";
    echo "2. View the POR list with filters\n";
    echo "3. See summary statistics\n\n";
    
} catch (Exception $e) {
    $db->rollBack();
    echo "✗ Error: " . $e->getMessage() . "\n";
    echo $e->getTraceAsString() . "\n";
}
