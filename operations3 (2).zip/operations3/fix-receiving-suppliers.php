<?php
require_once 'config/database.php';

$db = getDB();

echo "=== FIXING RECEIVING SUPPLIER NAMES ===\n\n";

// Get all suppliers first
$stmt = $db->query("SELECT * FROM suppliers");
$suppliers = [];
foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $supplierData = json_decode($row['data'], true);
    $suppliers[$row['id']] = $supplierData['company'] ?? $supplierData['name'] ?? 'Unknown Supplier';
}

echo "Loaded " . count($suppliers) . " suppliers:\n";
foreach ($suppliers as $id => $name) {
    echo "  - $id: $name\n";
}
echo "\n";

// Get all receivings
$stmt = $db->query("SELECT * FROM receivings");
$receivings = $stmt->fetchAll(PDO::FETCH_ASSOC);

$updated = 0;
$skipped = 0;

foreach ($receivings as $r) {
    $data = json_decode($r['data'], true);
    $supplier = $data['supplier'] ?? null;
    $supplierName = $data['supplierName'] ?? null;
    $supplierId = $data['supplierId'] ?? null;
    
    // If supplier name is missing but we have supplierId
    if ((empty($supplier) || empty($supplierName)) && !empty($supplierId)) {
        if (isset($suppliers[$supplierId])) {
            // Update the receiving data
            $data['supplier'] = $suppliers[$supplierId];
            $data['supplierName'] = $suppliers[$supplierId];
            
            $updateStmt = $db->prepare("UPDATE receivings SET data = ? WHERE id = ?");
            $updateStmt->execute([json_encode($data), $r['id']]);
            
            $receivingNumber = $data['receivingNumber'] ?? $r['id'];
            echo "✓ Updated $receivingNumber - Set supplier to: {$suppliers[$supplierId]}\n";
            $updated++;
        } else {
            echo "⚠ Warning: Supplier ID $supplierId not found for receiving {$r['id']}\n";
        }
    } else {
        $skipped++;
    }
}

echo "\n=== SUMMARY ===\n";
echo "Updated: $updated receivings\n";
echo "Skipped (already had supplier): $skipped receivings\n";
echo "\n✅ Done! Supplier names have been populated.\n";
