<?php
require_once __DIR__ . '/includes/auth.php';
$currentUser = require_login_page();
$token = $_GET['token'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Transfer Receiving - RAM-YUM</title>
    <link rel="stylesheet" href="assets/css/main.css">
    <script src="https://cdn.jsdelivr.net/npm/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
    <style>
        .receiving-container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 24px;
        }
        
        .receiving-header {
            text-align: center;
            margin-bottom: 32px;
        }
        
        .receiving-header h1 {
            font-size: 32px;
            color: var(--text-primary);
            margin-bottom: 8px;
        }
        
        .scan-section {
            background: var(--bg-primary);
            border-radius: 12px;
            padding: 32px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            text-align: center;
            margin-bottom: 24px;
        }
        
        .scan-options {
            display: flex;
            gap: 16px;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 24px;
        }
        
        .scan-btn {
            padding: 16px 32px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 12px;
        }
        
        .scan-btn-primary {
            background: var(--primary-orange);
            color: white;
        }
        
        .scan-btn-primary:hover {
            background: var(--primary-red);
            transform: translateY(-2px);
            box-shadow: 0 4px 16px rgba(255, 122, 0, 0.3);
        }
        
        .scan-btn-secondary {
            background: var(--bg-secondary);
            color: var(--text-primary);
            border: 2px solid var(--border-color);
        }
        
        .scan-btn-secondary:hover {
            background: var(--bg-gray);
            border-color: var(--primary-orange);
        }
        
        #camera-container {
            display: none;
            margin-top: 24px;
            background: white;
            padding: 20px;
            border-radius: 12px;
        }
        
        #qr-reader {
            max-width: 600px;
            margin: 0 auto;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            overflow: hidden;
        }
        
        .manual-entry {
            display: none;
            margin-top: 24px;
            background: var(--bg-secondary);
            padding: 24px;
            border-radius: 8px;
        }
        
        .manual-entry input {
            width: 100%;
            max-width: 400px;
            padding: 12px 16px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-size: 16px;
            margin-bottom: 16px;
        }
        
        .transfer-details {
            display: none;
            background: var(--bg-primary);
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            margin-bottom: 24px;
        }
        
        .detail-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }
        
        .detail-item {
            background: var(--bg-secondary);
            padding: 16px;
            border-radius: 8px;
        }
        
        .detail-label {
            font-size: 12px;
            color: var(--text-secondary);
            text-transform: uppercase;
            font-weight: 600;
            margin-bottom: 4px;
        }
        
        .detail-value {
            font-size: 16px;
            color: var(--text-primary);
            font-weight: 500;
        }
        
        .items-section {
            display: none;
            background: var(--bg-primary);
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            margin-bottom: 24px;
        }
        
        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 16px;
        }
        
        .items-table th {
            background: var(--bg-secondary);
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: var(--text-secondary);
            font-size: 12px;
            text-transform: uppercase;
            border-bottom: 2px solid var(--border-color);
        }
        
        .items-table td {
            padding: 16px 12px;
            border-bottom: 1px solid var(--border-color);
        }
        
        .items-table input[type="number"] {
            width: 80px;
            padding: 8px;
            border: 2px solid var(--border-color);
            border-radius: 4px;
            font-size: 14px;
        }
        
        .items-table select {
            padding: 8px 12px;
            border: 2px solid var(--border-color);
            border-radius: 4px;
            font-size: 14px;
            min-width: 120px;
        }
        
        .condition-good { border-left: 4px solid #28a745; }
        .condition-damaged { border-left: 4px solid #dc3545; }
        .condition-missing { border-left: 4px solid #ffc107; }
        .condition-incorrect { border-left: 4px solid #6c757d; }
        
        .photo-section {
            display: none;
            background: var(--bg-primary);
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            margin-bottom: 24px;
        }
        
        .photo-upload-area {
            border: 2px dashed var(--border-color);
            border-radius: 8px;
            padding: 32px;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .photo-upload-area:hover {
            border-color: var(--primary-orange);
            background: var(--bg-secondary);
        }
        
        .photo-preview {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 16px;
            margin-top: 16px;
        }
        
        .photo-item {
            position: relative;
            border-radius: 8px;
            overflow: hidden;
            aspect-ratio: 1;
        }
        
        .photo-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .photo-remove {
            position: absolute;
            top: 8px;
            right: 8px;
            background: rgba(220, 53, 69, 0.9);
            color: white;
            border: none;
            border-radius: 50%;
            width: 28px;
            height: 28px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .confirm-section {
            display: none;
            background: var(--bg-primary);
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .confirm-section textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-size: 14px;
            font-family: inherit;
            resize: vertical;
            min-height: 100px;
        }
        
        .action-buttons {
            display: flex;
            gap: 12px;
            justify-content: center;
            margin-top: 24px;
            flex-wrap: wrap;
        }
        
        .btn {
            padding: 12px 32px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .btn-primary {
            background: var(--primary-orange);
            color: white;
        }
        
        .btn-primary:hover {
            background: var(--primary-red);
        }
        
        .btn-secondary {
            background: var(--bg-secondary);
            color: var(--text-primary);
            border: 2px solid var(--border-color);
        }
        
        .btn-secondary:hover {
            background: var(--bg-gray);
        }
        
        .alert {
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 16px;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border-left: 4px solid #28a745;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
        }
        
        .alert-warning {
            background: #fff3cd;
            color: #856404;
            border-left: 4px solid #ffc107;
        }
        
        .damage-photo-required {
            background: #fff3cd;
            padding: 12px;
            border-radius: 4px;
            border-left: 4px solid #ffc107;
            margin-top: 8px;
        }
        
        .loading {
            text-align: center;
            padding: 40px;
            color: var(--text-secondary);
        }
    </style>
</head>
<body>
    <div class="receiving-container">
        <div class="receiving-header">
            <h1>📦 Stock Transfer Receiving</h1>
            <p style="color: var(--text-secondary);">Scan QR code or enter transfer number to begin receiving</p>
        </div>

        <div id="alertContainer"></div>

        <div class="scan-section" id="scanSection">
            <h2>Scan Transfer QR Code</h2>
            <p style="color: var(--text-secondary); margin-bottom: 24px;">
                Use your device camera to scan the QR code attached to the delivery
            </p>
            
            <div class="scan-options">
                <button class="scan-btn scan-btn-primary" onclick="startQRScan()">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z"/>
                        <circle cx="12" cy="13" r="4"/>
                    </svg>
                    Scan QR Code
                </button>
                
                <button class="scan-btn scan-btn-secondary" onclick="showManualEntry()">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/>
                        <path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>
                    </svg>
                    Enter Manually
                </button>
            </div>

            <div id="camera-container">
                <div id="qr-reader"></div>
                <div style="margin-top: 16px;">
                    <button class="btn btn-secondary" onclick="stopQRScan()">Cancel Scan</button>
                </div>
            </div>

            <div class="manual-entry" id="manualEntry">
                <h3>Enter Transfer Number</h3>
                <input type="text" id="manualToken" placeholder="e.g., POD-ABC123..." />
                <div>
                    <button class="btn btn-primary" onclick="loadManualTransfer()">Load Transfer</button>
                    <button class="btn btn-secondary" onclick="hideManualEntry()">Cancel</button>
                </div>
            </div>
        </div>

        <div class="transfer-details" id="transferDetails">
            <h2>Transfer Details</h2>
            <div class="detail-grid" id="detailGrid"></div>
        </div>

        <div class="items-section" id="itemsSection">
            <h2>Verify Items</h2>
            <p style="color: var(--text-secondary); margin-bottom: 16px;">
                Verify each item received and note any discrepancies
            </p>
            <table class="items-table">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Expected Qty</th>
                        <th>Received Qty</th>
                        <th>Unit</th>
                        <th>Condition</th>
                        <th>Notes</th>
                    </tr>
                </thead>
                <tbody id="itemsTableBody"></tbody>
            </table>
        </div>

        <div class="photo-section" id="photoSection">
            <h2>📸 Delivery Photo Evidence</h2>
            <p style="color: var(--text-secondary); margin-bottom: 16px;">
                Take or upload photo(s) of the received items
            </p>
            
            <div class="photo-upload-area" onclick="document.getElementById('photoInput').click()">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin: 0 auto 12px;">
                    <path d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z"/>
                    <circle cx="12" cy="13" r="4"/>
                </svg>
                <p style="margin: 0; color: var(--text-secondary);">
                    Click to take photo or upload image
                </p>
            </div>
            <input type="file" id="photoInput" accept="image/*" capture="environment" multiple style="display: none;" onchange="handlePhotoUpload(event)" />
            
            <div class="photo-preview" id="photoPreview"></div>
        </div>

        <div class="confirm-section" id="confirmSection">
            <h2>✅ Confirm Receiving</h2>
            <p style="color: var(--text-secondary); margin-bottom: 16px;">
                Review all information and add any additional notes
            </p>
            
            <label style="display: block; margin-bottom: 8px; font-weight: 600;">
                Receiving Notes (Optional)
            </label>
            <textarea id="receivingNotes" placeholder="Add any remarks or observations about this receiving..."></textarea>
            
            <div class="action-buttons">
                <button class="btn btn-primary" onclick="confirmReceiving()">
                    Confirm Receiving
                </button>
                <button class="btn btn-secondary" onclick="cancelReceiving()">
                    Cancel
                </button>
            </div>
        </div>
    </div>

    <script>
        let currentTransfer = null;
        let currentPOD = null;
        let html5QrCode = null;
        let uploadedPhotos = [];
        let receivingItems = [];

        // Auto-load if token is in URL
        window.addEventListener('DOMContentLoaded', () => {
            const urlToken = '<?php echo htmlspecialchars($token); ?>';
            if (urlToken) {
                loadTransferByToken(urlToken);
            }
        });

        async function startQRScan() {
            const container = document.getElementById('camera-container');
            container.style.display = 'block';
            
            try {
                html5QrCode = new Html5Qrcode("qr-reader");
                
                await html5QrCode.start(
                    { facingMode: "environment" },
                    { fps: 10, qrbox: { width: 250, height: 250 } },
                    onScanSuccess,
                    onScanFailure
                );
            } catch (err) {
                console.error('Error starting QR scanner:', err);
                showAlert('error', 'Failed to access camera. Please ensure camera permissions are granted or use manual entry.');
                container.style.display = 'none';
            }
        }

        async function stopQRScan() {
            if (html5QrCode) {
                await html5QrCode.stop();
                html5QrCode = null;
            }
            document.getElementById('camera-container').style.display = 'none';
        }

        function onScanSuccess(decodedText) {
            console.log('QR Code scanned:', decodedText);
            stopQRScan();
            
            // Extract token from URL or use directly
            let token = decodedText;
            if (decodedText.includes('?token=')) {
                token = new URL(decodedText).searchParams.get('token');
            }
            
            loadTransferByToken(token);
        }

        function onScanFailure(error) {
            // Silent - this is called frequently during scanning
        }

        function showManualEntry() {
            document.getElementById('manualEntry').style.display = 'block';
        }

        function hideManualEntry() {
            document.getElementById('manualEntry').style.display = 'none';
            document.getElementById('manualToken').value = '';
        }

        function loadManualTransfer() {
            const token = document.getElementById('manualToken').value.trim();
            if (!token) {
                showAlert('error', 'Please enter a transfer number or QR token');
                return;
            }
            loadTransferByToken(token);
        }

        async function loadTransferByToken(token) {
            try {
                showAlert('info', 'Loading transfer...');
                
                const res = await fetch(`/api/proof-of-delivery.php?action=scan&token=${encodeURIComponent(token)}`);
                const data = await res.json();

                if (!data.success) {
                    throw new Error(data.error || 'Failed to load transfer');
                }

                if (data.alreadyReceived) {
                    showAlert('warning', `This transfer has already been received by ${data.receivedBy} on ${new Date(data.receivedAt).toLocaleString()}`);
                    return;
                }

                currentTransfer = data.data;
                currentPOD = { podId: data.data.podId };
                
                displayTransferDetails();
                hideManualEntry();
                document.getElementById('scanSection').style.display = 'none';
                showAlert('success', 'Transfer loaded successfully! Please verify items below.');

            } catch (error) {
                console.error('Error loading transfer:', error);
                showAlert('error', error.message);
            }
        }

        function displayTransferDetails() {
            // Display transfer header details
            const detailGrid = document.getElementById('detailGrid');
            detailGrid.innerHTML = `
                <div class="detail-item">
                    <div class="detail-label">Transfer Number</div>
                    <div class="detail-value">${currentTransfer.transferNumber}</div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">From</div>
                    <div class="detail-value">${currentTransfer.sourceLocation}</div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">To</div>
                    <div class="detail-value">${currentTransfer.destinationLocation}</div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Transfer Date</div>
                    <div class="detail-value">${currentTransfer.transferDate}</div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Total Items</div>
                    <div class="detail-value">${currentTransfer.totalItems}</div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Status</div>
                    <div class="detail-value">${currentTransfer.status}</div>
                </div>
            `;

            // Display items table
            const tbody = document.getElementById('itemsTableBody');
            tbody.innerHTML = '';
            
            currentTransfer.items.forEach((item, index) => {
                const row = document.createElement('tr');
                row.className = 'condition-good';
                row.id = `item-row-${index}`;
                row.innerHTML = `
                    <td>
                        <strong>${item.productName}</strong><br>
                        <small style="color: var(--text-secondary);">SKU: ${item.sku}</small>
                    </td>
                    <td><strong>${item.quantity}</strong></td>
                    <td>
                        <input type="number" 
                               id="received-qty-${index}" 
                               value="${item.quantity}" 
                               min="0" 
                               max="${item.quantity}"
                               onchange="validateReceivedQty(${index})" />
                    </td>
                    <td>${item.unit}</td>
                    <td>
                        <select id="condition-${index}" onchange="handleConditionChange(${index})">
                            <option value="Good">Good</option>
                            <option value="Damaged">Damaged</option>
                            <option value="Missing">Missing</option>
                            <option value="Incorrect">Incorrect Item</option>
                        </select>
                    </td>
                    <td>
                        <input type="text" 
                               id="notes-${index}" 
                               placeholder="Add notes..."
                               style="width: 100%; padding: 8px; border: 1px solid var(--border-color); border-radius: 4px;" />
                        <div id="damage-alert-${index}"></div>
                    </td>
                `;
                tbody.appendChild(row);
                
                receivingItems.push({
                    ...item,
                    receivedQuantity: item.quantity,
                    condition: 'Good',
                    notes: '',
                    damagePhotoId: null
                });
            });

            document.getElementById('transferDetails').style.display = 'block';
            document.getElementById('itemsSection').style.display = 'block';
            document.getElementById('photoSection').style.display = 'block';
            document.getElementById('confirmSection').style.display = 'block';
        }

        function validateReceivedQty(index) {
            const input = document.getElementById(`received-qty-${index}`);
            const value = parseInt(input.value) || 0;
            receivingItems[index].receivedQuantity = value;
            
            if (value !== receivingItems[index].quantity) {
                showAlert('warning', 'Quantity discrepancy detected. Please verify and add notes.');
            }
        }

        function handleConditionChange(index) {
            const select = document.getElementById(`condition-${index}`);
            const condition = select.value;
            const row = document.getElementById(`item-row-${index}`);
            const damageAlert = document.getElementById(`damage-alert-${index}`);
            
            receivingItems[index].condition = condition;
            
            // Update row styling
            row.className = `condition-${condition.toLowerCase()}`;
            
            // Show damage photo requirement
            if (condition === 'Damaged') {
                damageAlert.innerHTML = `
                    <div class="damage-photo-required">
                        ⚠️ Damage photo required
                        <button class="btn btn-primary" style="margin-left: 8px; padding: 4px 12px; font-size: 12px;" onclick="takeDamagePhoto(${index})">
                            Take Photo
                        </button>
                    </div>
                `;
            } else {
                damageAlert.innerHTML = '';
            }
        }

        async function takeDamagePhoto(index) {
            // Trigger photo input
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = 'image/*';
            input.capture = 'environment';
            input.onchange = async (e) => {
                const file = e.target.files[0];
                if (file) {
                    try {
                        const photoId = await uploadPhoto(file, 'damage');
                        receivingItems[index].damagePhotoId = photoId;
                        showAlert('success', `Damage photo uploaded for ${receivingItems[index].productName}`);
                        
                        // Update alert
                        const damageAlert = document.getElementById(`damage-alert-${index}`);
                        damageAlert.innerHTML = `
                            <div class="damage-photo-required" style="background: #d4edda; border-left-color: #28a745;">
                                ✅ Damage photo uploaded
                            </div>
                        `;
                    } catch (error) {
                        showAlert('error', 'Failed to upload damage photo: ' + error.message);
                    }
                }
            };
            input.click();
        }

        async function handlePhotoUpload(event) {
            const files = Array.from(event.target.files);
            
            for (const file of files) {
                try {
                    const photoId = await uploadPhoto(file, 'delivery');
                    
                    // Add to preview
                    const preview = document.getElementById('photoPreview');
                    const photoDiv = document.createElement('div');
                    photoDiv.className = 'photo-item';
                    photoDiv.innerHTML = `
                        <img src="${URL.createObjectURL(file)}" alt="Delivery photo" />
                        <button class="photo-remove" onclick="removePhoto('${photoId}')">×</button>
                    `;
                    preview.appendChild(photoDiv);
                    
                    uploadedPhotos.push({ id: photoId, file: file });
                    
                } catch (error) {
                    console.error('Upload error:', error);
                    showAlert('error', 'Failed to upload photo: ' + error.message);
                }
            }
            
            // Clear input
            event.target.value = '';
        }

        async function uploadPhoto(file, type) {
            const formData = new FormData();
            formData.append('image', file);
            formData.append('type', 'damage'); // Use damage directory for all POD photos
            formData.append('podId', currentPOD.podId);
            formData.append('photoType', type);
            
            const res = await fetch('/api/upload-image.php', {
                method: 'POST',
                body: formData
            });
            
            const data = await res.json();
            if (!data.success) {
                throw new Error(data.error || 'Upload failed');
            }
            
            // Generate unique ID for this photo
            return `photo_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        }

        function removePhoto(photoId) {
            uploadedPhotos = uploadedPhotos.filter(p => p.id !== photoId);
            // Reload preview
            document.getElementById('photoPreview').innerHTML = '';
            uploadedPhotos.forEach(photo => {
                const photoDiv = document.createElement('div');
                photoDiv.className = 'photo-item';
                photoDiv.innerHTML = `
                    <img src="${URL.createObjectURL(photo.file)}" alt="Delivery photo" />
                    <button class="photo-remove" onclick="removePhoto('${photo.id}')">×</button>
                `;
                document.getElementById('photoPreview').appendChild(photoDiv);
            });
        }

        async function confirmReceiving() {
            try {
                // Validate all damaged items have photos
                const damagedItems = receivingItems.filter(item => item.condition === 'Damaged');
                const missingPhotos = damagedItems.filter(item => !item.damagePhotoId);
                
                if (missingPhotos.length > 0) {
                    showAlert('error', 'Please upload damage photos for all damaged items');
                    return;
                }
                
                // Collect notes from inputs
                receivingItems.forEach((item, index) => {
                    item.notes = document.getElementById(`notes-${index}`).value;
                });
                
                const notes = document.getElementById('receivingNotes').value;
                
                if (!confirm('Confirm receiving for this stock transfer?')) {
                    return;
                }
                
                showAlert('info', 'Processing receiving...');
                
                const res = await fetch('/api/proof-of-delivery.php?action=confirm-receiving', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        podId: currentPOD.podId,
                        items: receivingItems.map((item, index) => ({
                            productId: item.productId,
                            productName: item.productName,
                            sku: item.sku,
                            expectedQuantity: item.quantity,
                            receivedQuantity: item.receivedQuantity,
                            unit: item.unit,
                            condition: item.condition,
                            notes: item.notes,
                            damagePhotoId: item.damagePhotoId,
                            photoIds: []
                        })),
                        notes: notes,
                        photos: uploadedPhotos.map(p => p.id)
                    })
                });
                
                const data = await res.json();
                
                if (!data.success) {
                    throw new Error(data.error || 'Failed to confirm receiving');
                }
                
                showAlert('success', '✅ Receiving confirmed successfully!');
                
                setTimeout(() => {
                    window.location.href = '/dashboard.php';
                }, 2000);
                
            } catch (error) {
                console.error('Error confirming receiving:', error);
                showAlert('error', error.message);
            }
        }

        function cancelReceiving() {
            if (confirm('Cancel receiving? All entered data will be lost.')) {
                window.location.reload();
            }
        }

        function showAlert(type, message) {
            const container = document.getElementById('alertContainer');
            const alert = document.createElement('div');
            alert.className = `alert alert-${type}`;
            alert.textContent = message;
            container.innerHTML = '';
            container.appendChild(alert);
            
            // Auto-remove after 5 seconds for non-error messages
            if (type !== 'error') {
                setTimeout(() => alert.remove(), 5000);
            }
            
            // Scroll to top
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    </script>
</body>
</html>
