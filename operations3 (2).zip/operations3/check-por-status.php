<?php
/**
 * Check and Fix POR Status
 * Checks if POR-2026-0001 status is correct based on receiving data
 */

require_once __DIR__ . '/config/database.php';

$db = getDB();

echo "<html><head><title>Check POR Status</title>";
echo "<style>
    body { font-family: Arial, sans-serif; max-width: 1000px; margin: 50px auto; padding: 20px; background: #f5f5f5; }
    table { width: 100%; border-collapse: collapse; background: white; margin: 20px 0; }
    th, td { padding: 12px; text-align: left; border: 1px solid #ddd; }
    th { background: #3B82F6; color: white; font-weight: 600; }
    .pending { background: #FEF3C7; color: #92400E; }
    .passed { background: #D1FAE5; color: #065F46; }
    .failed { background: #FEE2E2; color: #991B1B; }
    .info { background: #DBEAFE; padding: 15px; border-left: 4px solid #3B82F6; margin: 20px 0; }
    .success { background: #D1FAE5; padding: 15px; border-left: 4px solid #10B981; margin: 20px 0; }
    .warning { background: #FEF3C7; padding: 15px; border-left: 4px solid #F59E0B; margin: 20px 0; }
</style></head><body>";

echo "<h1>🔍 POR Status Check</h1>";

try {
    // Get POR-2026-0001
    $stmt = $db->prepare("
        SELECT 
            por.*,
            r.data as receiving_data
        FROM proof_of_receiving por
        LEFT JOIN receivings r ON r.id = por.receiving_id
        WHERE por.por_number = 'POR-2026-0001'
    ");
    $stmt->execute();
    $por = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$por) {
        echo "<div class='warning'><strong>⚠️ POR-2026-0001 not found!</strong></div>";
        echo "</body></html>";
        exit;
    }
    
    echo "<div class='info'><strong>📋 Found POR:</strong> {$por['por_number']}</div>";
    
    // Display current POR data
    echo "<h2>Current POR Data:</h2>";
    echo "<table>";
    echo "<tr><th>Field</th><th>Value</th></tr>";
    echo "<tr><td><strong>POR Number</strong></td><td>{$por['por_number']}</td></tr>";
    echo "<tr><td><strong>PO Number</strong></td><td>{$por['po_number']}</td></tr>";
    echo "<tr><td><strong>Supplier</strong></td><td>{$por['supplier_name']}</td></tr>";
    echo "<tr><td><strong>Inspection Status</strong></td><td class='pending'><strong>{$por['inspection_status']}</strong></td></tr>";
    echo "<tr><td><strong>Received By</strong></td><td>{$por['received_by_name']}</td></tr>";
    echo "<tr><td><strong>Receiving Date</strong></td><td>{$por['receiving_date']}</td></tr>";
    echo "</table>";
    
    // Get POR items
    $stmt = $db->prepare("
        SELECT * FROM proof_of_receiving_items 
        WHERE por_id = ?
    ");
    $stmt->execute([$por['id']]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h2>POR Items:</h2>";
    echo "<table>";
    echo "<tr><th>Product</th><th>Ordered</th><th>Received</th><th>Accepted</th><th>Rejected</th><th>Result</th></tr>";
    
    $totalOrdered = 0;
    $totalReceived = 0;
    $totalAccepted = 0;
    $totalRejected = 0;
    
    foreach ($items as $item) {
        $totalOrdered += $item['ordered_quantity'];
        $totalReceived += $item['received_quantity'];
        $totalAccepted += $item['accepted_quantity'];
        $totalRejected += $item['rejected_quantity'];
        
        $resultClass = 'pending';
        if ($item['inspection_result'] === 'Passed') $resultClass = 'passed';
        if ($item['inspection_result'] === 'Failed') $resultClass = 'failed';
        
        echo "<tr>";
        echo "<td>{$item['product_name']}</td>";
        echo "<td>{$item['ordered_quantity']}</td>";
        echo "<td>{$item['received_quantity']}</td>";
        echo "<td class='passed'><strong>{$item['accepted_quantity']}</strong></td>";
        echo "<td class='failed'><strong>{$item['rejected_quantity']}</strong></td>";
        echo "<td class='{$resultClass}'>{$item['inspection_result']}</td>";
        echo "</tr>";
    }
    
    echo "</table>";
    
    // Calculate what status SHOULD be
    echo "<h2>📊 Status Calculation:</h2>";
    echo "<table>";
    echo "<tr><th>Metric</th><th>Value</th></tr>";
    echo "<tr><td>Total Ordered</td><td><strong>{$totalOrdered}</strong></td></tr>";
    echo "<tr><td>Total Received</td><td><strong>{$totalReceived}</strong></td></tr>";
    echo "<tr><td>Total Accepted</td><td class='passed'><strong>{$totalAccepted}</strong></td></tr>";
    echo "<tr><td>Total Rejected</td><td class='failed'><strong>{$totalRejected}</strong></td></tr>";
    echo "</table>";
    
    // Determine correct status
    $correctStatus = 'Pending';
    
    if ($totalRejected > 0) {
        $correctStatus = 'Failed';
    } elseif ($totalAccepted > 0 && $totalRejected == 0) {
        if ($totalAccepted == $totalReceived) {
            $correctStatus = 'Passed';
        } else {
            $correctStatus = 'Partial';
        }
    }
    
    echo "<div class='info'>";
    echo "<h3>🧮 Status Logic:</h3>";
    echo "<ul>";
    if ($totalRejected > 0) {
        echo "<li>Total Rejected: {$totalRejected} > 0 → <strong class='failed'>Failed</strong></li>";
    } elseif ($totalAccepted > 0 && $totalRejected == 0) {
        if ($totalAccepted == $totalReceived) {
            echo "<li>Total Accepted: {$totalAccepted} == Total Received: {$totalReceived}</li>";
            echo "<li>No rejections → <strong class='passed'>Passed</strong></li>";
        } else {
            echo "<li>Total Accepted: {$totalAccepted} != Total Received: {$totalReceived}</li>";
            echo "<li>Some items damaged → <strong>Partial</strong></li>";
        }
    } else {
        echo "<li>No items accepted yet → <strong class='pending'>Pending</strong></li>";
    }
    echo "</ul>";
    echo "</div>";
    
    // Compare with current status
    if ($correctStatus !== $por['inspection_status']) {
        echo "<div class='warning'>";
        echo "<h3>⚠️ Status Mismatch!</h3>";
        echo "<p><strong>Current Status:</strong> {$por['inspection_status']}</p>";
        echo "<p><strong>Should Be:</strong> <strong>{$correctStatus}</strong></p>";
        echo "</div>";
        
        // Offer to fix
        echo "<form method='POST' style='margin: 20px 0;'>";
        echo "<input type='hidden' name='fix' value='yes'>";
        echo "<input type='hidden' name='por_id' value='{$por['id']}'>";
        echo "<input type='hidden' name='correct_status' value='{$correctStatus}'>";
        echo "<button type='submit' style='padding:12px 24px; background:#10B981; color:white; border:none; border-radius:8px; font-weight:600; cursor:pointer; font-size:1rem;'>";
        echo "✓ Fix Status to '{$correctStatus}'";
        echo "</button>";
        echo "</form>";
    } else {
        echo "<div class='success'>";
        echo "<h3>✓ Status is Correct!</h3>";
        echo "<p>Current status '<strong>{$por['inspection_status']}</strong>' matches the calculated status.</p>";
        echo "</div>";
    }
    
    // Handle fix request
    if ($_POST['fix'] ?? false) {
        $porId = $_POST['por_id'];
        $newStatus = $_POST['correct_status'];
        
        $stmt = $db->prepare("UPDATE proof_of_receiving SET inspection_status = ? WHERE id = ?");
        $stmt->execute([$newStatus, $porId]);
        
        echo "<div class='success'>";
        echo "<h3>✅ Status Updated!</h3>";
        echo "<p>POR status has been changed to: <strong>{$newStatus}</strong></p>";
        echo "<p><a href='check-por-status.php' style='color:#3B82F6; font-weight:600;'>↻ Reload Page</a></p>";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<div style='background:#FEE2E2; padding:20px; border-left:4px solid #EF4444; margin:20px 0;'>";
    echo "<strong>❌ Error:</strong> {$e->getMessage()}";
    echo "</div>";
}

echo "<p style='margin-top:30px;'><a href='dashboard.php' style='padding:12px 24px; background:#FF7A00; color:white; text-decoration:none; border-radius:8px; font-weight:600; display:inline-block;'>← Back to Dashboard</a></p>";
echo "</body></html>";
?>
