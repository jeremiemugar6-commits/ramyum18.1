<?php
/**
 * Test Stock Transfer and Location Connection
 */

require_once 'includes/auth.php';

$db = getDB();

echo "=================================================\n";
echo "  STOCK TRANSFER & LOCATION CONNECTION TEST\n";
echo "=================================================\n\n";

// TEST 1: Verify locations are accessible
echo "TEST 1: Locations API Connection\n";
echo "-------------------------------------------------\n";
$stmt = $db->query("SELECT id, data FROM locations WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) = 'Active'");
$locations = [];
while ($row = $stmt->fetch()) {
    $data = json_decode($row['data'], true);
    $locations[$row['id']] = $data;
    echo "✓ " . $row['id'] . " - " . $data['name'] . "\n";
}
echo "Total: " . count($locations) . " active locations\n\n";

// TEST 2: Check inventory at each location
echo "TEST 2: Inventory at Each Location\n";
echo "-------------------------------------------------\n";
foreach ($locations as $locId => $locData) {
    $stmt = $db->prepare("
        SELECT 
            JSON_UNQUOTE(JSON_EXTRACT(data, '$.productId')) as productId,
            JSON_UNQUOTE(JSON_EXTRACT(data, '$.availableQuantity')) as qty
        FROM inventory_locations
        WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.locationId')) = ?
    ");
    $stmt->execute([$locId]);
    $items = $stmt->fetchAll();
    
    echo $locData['name'] . ": " . count($items) . " products\n";
    if (count($items) > 0) {
        foreach (array_slice($items, 0, 3) as $item) {
            echo "  - Product " . $item['productId'] . ": " . $item['qty'] . " units\n";
        }
        if (count($items) > 3) {
            echo "  ... and " . (count($items) - 3) . " more\n";
        }
    }
}
echo "\n";

// TEST 3: Verify location can be used in stock transfer
echo "TEST 3: Create Test Stock Transfer\n";
echo "-------------------------------------------------\n";

if (count($locations) >= 2) {
    $locationIds = array_keys($locations);
    $sourceId = $locationIds[0];
    $destId = $locationIds[1];
    
    $sourceData = $locations[$sourceId];
    $destData = $locations[$destId];
    
    echo "Source: " . $sourceData['name'] . " (ID: $sourceId)\n";
    echo "Destination: " . $destData['name'] . " (ID: $destId)\n";
    
    // Get a product that exists at source
    $stmt = $db->prepare("
        SELECT 
            JSON_UNQUOTE(JSON_EXTRACT(data, '$.productId')) as productId,
            JSON_UNQUOTE(JSON_EXTRACT(data, '$.availableQuantity')) as qty
        FROM inventory_locations
        WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.locationId')) = ?
        AND CAST(JSON_UNQUOTE(JSON_EXTRACT(data, '$.availableQuantity')) AS UNSIGNED) > 5
        LIMIT 1
    ");
    $stmt->execute([$sourceId]);
    $product = $stmt->fetch();
    
    if ($product) {
        echo "Test Product: " . $product['productId'] . " (Available: " . $product['qty'] . ")\n";
        
        // Create transfer structure (don't actually insert)
        $transferData = [
            'id' => 'st_test_' . time(),
            'transferNumber' => 'ST-TEST-0001',
            'sourceLocationId' => $sourceId,
            'sourceLocationName' => $sourceData['name'],
            'destinationLocationId' => $destId,
            'destinationLocationName' => $destData['name'],
            'items' => [
                [
                    'productId' => $product['productId'],
                    'quantity' => 5
                ]
            ],
            'status' => 'Pending Approval',
            'transferDate' => date('Y-m-d\TH:i:s.v\Z')
        ];
        
        echo "\n✓ Transfer structure validated:\n";
        echo "  From: " . $transferData['sourceLocationName'] . "\n";
        echo "  To: " . $transferData['destinationLocationName'] . "\n";
        echo "  Items: " . count($transferData['items']) . "\n";
        echo "  Status: " . $transferData['status'] . "\n";
    } else {
        echo "⚠ No product with sufficient quantity found at source location\n";
    }
} else {
    echo "⚠ Need at least 2 locations to create transfers\n";
}

echo "\n";

// TEST 4: Verify no demo flags
echo "TEST 4: Check for Demo Data Flags\n";
echo "-------------------------------------------------\n";
$hasDemoFlags = false;
foreach ($locations as $locId => $locData) {
    if (isset($locData['isDemo']) || isset($locData['demo']) || isset($locData['isDemoData'])) {
        echo "✗ Demo flag found in: " . $locData['name'] . "\n";
        $hasDemoFlags = true;
    }
}

if (!$hasDemoFlags) {
    echo "✓ No demo data flags found\n";
}

echo "\n";

// TEST 5: Check API endpoints are properly connected
echo "TEST 5: API Endpoint Verification\n";
echo "-------------------------------------------------\n";

$endpoints = [
    'api/locations.php' => 'Locations API',
    'api/stock-transfers.php' => 'Stock Transfers API'
];

foreach ($endpoints as $file => $name) {
    if (file_exists($file)) {
        $content = file_get_contents($file);
        
        // Check for proper includes
        if (strpos($content, "require_once") !== false || strpos($content, "require") !== false) {
            echo "✓ $name - Properly configured\n";
        } else {
            echo "⚠ $name - May have configuration issues\n";
        }
    } else {
        echo "✗ $name - File not found\n";
    }
}

echo "\n=================================================\n";
echo "              TEST COMPLETE\n";
echo "=================================================\n\n";

echo "Summary:\n";
echo "- Locations: " . count($locations) . " active\n";
echo "- Demo Flags: " . ($hasDemoFlags ? 'FOUND (needs cleanup)' : 'None') . "\n";
echo "- Connection: " . (count($locations) >= 2 ? 'Ready' : 'Need more locations') . "\n\n";

echo "Next Steps:\n";
echo "1. Access the system at: http://localhost/operations3/\n";
echo "2. Go to Stock Transfer module\n";
echo "3. Click 'Create Transfer'\n";
echo "4. Select locations and add items\n";
echo "5. Submit for approval\n\n";
