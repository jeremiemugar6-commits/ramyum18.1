<?php
require_once 'config/database.php';

$db = getDB();

echo "DATA STRUCTURE ANALYSIS\n";
echo str_repeat("=", 80) . "\n\n";

// Check suppliers
echo "SUPPLIERS:\n";
$stmt = $db->query("SELECT id, data FROM suppliers LIMIT 1");
$supplier = $stmt->fetch(PDO::FETCH_ASSOC);
if ($supplier) {
    echo "ID: " . $supplier['id'] . "\n";
    echo "Data structure:\n";
    $data = json_decode($supplier['data'], true);
    print_r($data);
}
echo "\n" . str_repeat("-", 80) . "\n\n";

// Check products
echo "PRODUCTS:\n";
$stmt = $db->query("SELECT id, data FROM products LIMIT 1");
$product = $stmt->fetch(PDO::FETCH_ASSOC);
if ($product) {
    echo "ID: " . $product['id'] . "\n";
    echo "Data structure:\n";
    $data = json_decode($product['data'], true);
    print_r($data);
}
echo "\n" . str_repeat("-", 80) . "\n\n";

// Check purchase orders
echo "PURCHASE ORDERS:\n";
$stmt = $db->query("SELECT id, data FROM purchase_orders LIMIT 1");
$po = $stmt->fetch(PDO::FETCH_ASSOC);
if ($po) {
    echo "ID: " . $po['id'] . "\n";
    echo "Data structure:\n";
    $data = json_decode($po['data'], true);
    print_r($data);
}
echo "\n" . str_repeat("-", 80) . "\n\n";

// Check receivings
echo "RECEIVINGS:\n";
$stmt = $db->query("SELECT id, data FROM receivings LIMIT 1");
$receiving = $stmt->fetch(PDO::FETCH_ASSOC);
if ($receiving) {
    echo "ID: " . $receiving['id'] . "\n";
    echo "Data structure:\n";
    $data = json_decode($receiving['data'], true);
    print_r($data);
}
echo "\n" . str_repeat("-", 80) . "\n\n";

// Check stock transfers
echo "STOCK TRANSFERS:\n";
$stmt = $db->query("SELECT id, data FROM stock_transfers LIMIT 1");
$transfer = $stmt->fetch(PDO::FETCH_ASSOC);
if ($transfer) {
    echo "ID: " . $transfer['id'] . "\n";
    echo "Data structure:\n";
    $data = json_decode($transfer['data'], true);
    print_r($data);
}
