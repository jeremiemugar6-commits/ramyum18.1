<?php
/**
 * Purchase Order QR Code Display
 * Shows QR code for approved POs that can be scanned during delivery
 */

require_once __DIR__ . '/includes/auth.php';
require_login();
$currentUser = $_SESSION['user'];

$poId = $_GET['id'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PO QR Code - RAM-YUM</title>
    <link rel="stylesheet" href="assets/css/main.css">
    <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js"></script>
    <style>
        .qr-container {
            max-width: 800px;
            margin: 40px auto;
            background: white;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .qr-code-display {
            text-align: center;
            margin: 30px 0;
        }
        #qrCanvas {
            border: 8px solid #f3f4f6;
            border-radius: 12px;
            padding: 20px;
            background: white;
        }
        .qr-token {
            font-family: 'Courier New', monospace;
            font-size: 14px;
            color: #6b7280;
            margin-top: 20px;
            padding: 12px;
            background: #f9fafb;
            border-radius: 8px;
            word-break: break-all;
        }
        .po-details {
            background: #f9fafb;
            padding: 24px;
            border-radius: 12px;
            margin: 20px 0;
        }
        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid #e5e7eb;
        }
        .detail-row:last-child {
            border-bottom: none;
        }
        .detail-label {
            font-weight: 600;
            color: #374151;
        }
        .detail-value {
            color: #6b7280;
        }
        .action-buttons {
            display: flex;
            gap: 12px;
            margin-top: 30px;
        }
        .btn {
            flex: 1;
            padding: 14px 24px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.2s;
        }
        .btn-primary {
            background: var(--primary-red);
            color: white;
        }
        .btn-primary:hover {
            background: #b91c1c;
        }
        .btn-secondary {
            background: #f3f4f6;
            color: #374151;
        }
        .btn-secondary:hover {
            background: #e5e7eb;
        }
        .items-table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        .items-table th {
            background: #f3f4f6;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #374151;
            border-bottom: 2px solid #e5e7eb;
        }
        .items-table td {
            padding: 12px;
            border-bottom: 1px solid #e5e7eb;
        }
        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-approved {
            background: #dbeafe;
            color: #1e40af;
        }
        .status-awaiting {
            background: #fef3c7;
            color: #92400e;
        }
        @media print {
            .action-buttons, .no-print {
                display: none;
            }
            .qr-container {
                box-shadow: none;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="qr-container">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
            <div>
                <h1 style="margin: 0; font-size: 28px; color: #111827;">Purchase Order QR Code</h1>
                <p style="margin: 8px 0 0 0; color: #6b7280;">Scan this code when receiving delivery</p>
            </div>
            <button onclick="window.close()" class="btn-secondary no-print" style="width: auto; padding: 10px 20px;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M6 18L18 6M6 6l12 12"/>
                </svg>
                Close
            </button>
        </div>

        <div id="loadingMessage" style="text-align: center; padding: 40px;">
            <p style="color: #6b7280;">Loading PO details...</p>
        </div>

        <div id="contentArea" style="display: none;">
            <!-- PO Details -->
            <div class="po-details">
                <div class="detail-row">
                    <span class="detail-label">PO Number:</span>
                    <span class="detail-value" id="poNumber">-</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Supplier:</span>
                    <span class="detail-value" id="supplierName">-</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Order Date:</span>
                    <span class="detail-value" id="orderDate">-</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Total Amount:</span>
                    <span class="detail-value" id="totalAmount">-</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Status:</span>
                    <span id="statusBadge">-</span>
                </div>
            </div>

            <!-- QR Code -->
            <div class="qr-code-display">
                <canvas id="qrCanvas"></canvas>
                <div class="qr-token">
                    <strong>Token:</strong> <span id="qrTokenText">-</span>
                </div>
            </div>

            <!-- Items List -->
            <div>
                <h3 style="margin: 30px 0 16px 0; color: #111827;">Items to Receive</h3>
                <table class="items-table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>SKU</th>
                            <th style="text-align: right;">Quantity</th>
                            <th style="text-align: right;">Unit Cost</th>
                            <th style="text-align: right;">Total</th>
                        </tr>
                    </thead>
                    <tbody id="itemsTableBody">
                        <tr>
                            <td colspan="5" style="text-align: center; color: #9ca3af;">No items</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Instructions -->
            <div style="background: #eff6ff; border-left: 4px solid #3b82f6; padding: 20px; margin: 30px 0; border-radius: 8px;">
                <h4 style="margin: 0 0 12px 0; color: #1e40af;">📱 How to Use This QR Code</h4>
                <ol style="margin: 0; padding-left: 20px; color: #1e40af;">
                    <li>Print or display this QR code</li>
                    <li>When supplier delivers, scan using mobile device</li>
                    <li>Verify items delivered vs. ordered</li>
                    <li>Capture photos of damaged items (if any)</li>
                    <li>Confirm receipt to update inventory automatically</li>
                </ol>
            </div>

            <!-- Action Buttons -->
            <div class="action-buttons no-print">
                <button onclick="window.print()" class="btn btn-primary">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M6 9V2h12v7M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/>
                        <path d="M6 14h12v8H6z"/>
                    </svg>
                    Print QR Code
                </button>
                <button onclick="openScanPage()" class="btn btn-secondary">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M22 11.08V12a10 10 0 11-5.93-9.14"/>
                        <path d="M22 4L12 14.01l-3-3"/>
                    </svg>
                    Scan Now
                </button>
            </div>
        </div>

        <div id="errorMessage" style="display: none; padding: 40px; text-align: center;">
            <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2" style="margin: 0 auto 20px;">
                <circle cx="12" cy="12" r="10"/>
                <path d="M12 8v4M12 16h.01"/>
            </svg>
            <h3 style="color: #111827; margin: 0 0 12px 0;">Cannot Display QR Code</h3>
            <p id="errorText" style="color: #6b7280; margin: 0;"></p>
        </div>
    </div>

    <script>
        const poId = '<?php echo htmlspecialchars($poId); ?>';
        let qrToken = null;

        async function loadPOData() {
            try {
                const response = await fetch(`api/po-receiving.php?action=qr-token&poId=${poId}`);
                const result = await response.json();

                if (result.success) {
                    const po = result.data.po;
                    qrToken = result.data.qrToken;

                    // Display PO details
                    document.getElementById('poNumber').textContent = po.poNumber;
                    document.getElementById('supplierName').textContent = po.supplierName || 'N/A';
                    document.getElementById('orderDate').textContent = formatDate(po.orderDate);
                    document.getElementById('totalAmount').textContent = formatCurrency(po.total);

                    // Status badge
                    const statusBadge = document.getElementById('statusBadge');
                    statusBadge.textContent = po.status;
                    statusBadge.className = 'status-badge ' + (po.status === 'Approved' ? 'status-approved' : 'status-awaiting');

                    // Display items
                    renderItems(po.items);

                    // Generate QR code
                    generateQRCode(qrToken);

                    // Show content
                    document.getElementById('loadingMessage').style.display = 'none';
                    document.getElementById('contentArea').style.display = 'block';

                } else {
                    showError(result.error || 'Failed to load PO details');
                }
            } catch (error) {
                console.error('Error loading PO:', error);
                showError('Failed to load PO details. Please try again.');
            }
        }

        function generateQRCode(token) {
            const scanUrl = `${window.location.origin}/scan-po-receiving.php?token=${token}`;
            
            QRCode.toCanvas(
                document.getElementById('qrCanvas'),
                scanUrl,
                {
                    width: 300,
                    margin: 2,
                    color: {
                        dark: '#111827',
                        light: '#ffffff'
                    }
                },
                (error) => {
                    if (error) {
                        console.error('QR generation error:', error);
                        showError('Failed to generate QR code');
                    }
                }
            );

            document.getElementById('qrTokenText').textContent = token;
        }

        function renderItems(items) {
            const tbody = document.getElementById('itemsTableBody');
            
            if (!items || items.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" style="text-align: center; color: #9ca3af;">No items</td></tr>';
                return;
            }

            tbody.innerHTML = items.map(item => `
                <tr>
                    <td>${escapeHtml(item.productName)}</td>
                    <td>${escapeHtml(item.sku || 'N/A')}</td>
                    <td style="text-align: right;">${item.quantity} ${item.unit || 'pcs'}</td>
                    <td style="text-align: right;">${formatCurrency(item.unitCost)}</td>
                    <td style="text-align: right;">${formatCurrency(item.quantity * item.unitCost)}</td>
                </tr>
            `).join('');
        }

        function openScanPage() {
            if (qrToken) {
                window.open(`scan-po-receiving.php?token=${qrToken}`, '_blank');
            }
        }

        function showError(message) {
            document.getElementById('loadingMessage').style.display = 'none';
            document.getElementById('contentArea').style.display = 'none';
            document.getElementById('errorText').textContent = message;
            document.getElementById('errorMessage').style.display = 'block';
        }

        function formatDate(isoDate) {
            if (!isoDate) return 'N/A';
            const date = new Date(isoDate);
            return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
        }

        function formatCurrency(amount) {
            return '₱' + parseFloat(amount || 0).toLocaleString(undefined, {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        // Load on page ready
        if (poId) {
            loadPOData();
        } else {
            showError('No PO ID provided');
        }
    </script>
</body>
</html>
