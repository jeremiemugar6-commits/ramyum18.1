<?php require_once __DIR__ . '/includes/auth.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - RAM-YUM Store</title>
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/auth.css">
</head>
<body>
<div class="auth-container">
    <div class="auth-card" style="text-align:center;">
        <img src="assets/images/logo.jpg" alt="RAM-YUM Logo" style="width: 100px; height: 100px; object-fit: contain; margin: 0 auto 20px; display: block;">
        <h2 class="auth-title">Forgot Your Password?</h2>
        <p class="auth-subtitle" style="margin-bottom:20px;">
            RAM-YUM accounts are created and managed by administrators.
            Please contact your system administrator to have your password reset.
        </p>
        <a href="index.php" class="btn-primary" style="display:inline-block; text-decoration:none; text-align:center;">Back to Login</a>
    </div>
</div>
</body>
</html>
