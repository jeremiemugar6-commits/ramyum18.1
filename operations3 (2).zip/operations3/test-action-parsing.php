<?php
/**
 * Test Action Parsing from JSON Body
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'includes/functions.php';

echo "TEST: Action Parsing from JSON Body\n";
echo str_repeat("=", 80) . "\n\n";

// Test 1: Original code (action from GET only)
echo "1. ORIGINAL CODE (GET only):\n";
echo str_repeat("-", 80) . "\n";
$_SERVER['REQUEST_METHOD'] = 'POST';
$_GET['action'] = '';  // No action in URL

$action_old = $_GET['action'] ?? '';
echo "Result: action = '$action_old'\n";
echo "Status: " . ($action_old ? "✓ Found" : "✗ Empty (will fail)") . "\n";

// Test 2: Fixed code (action from JSON body for POST)
echo "\n2. FIXED CODE (JSON body for POST):\n";
echo str_repeat("-", 80) . "\n";

// Simulate JSON body
$jsonBody = json_encode([
    'action' => 'create-from-receiving',
    'receiving_id' => 'test-receiving-123'
]);

// Mock php://input
stream_wrapper_unregister('php');
stream_wrapper_register('php', MockInput::class);
MockInput::$data = $jsonBody;

$method = 'POST';
if ($method === 'POST' || $method === 'PUT' || $method === 'DELETE') {
    $input = get_json_input();
    $action = $input['action'] ?? $_GET['action'] ?? '';
} else {
    $action = $_GET['action'] ?? '';
}

echo "JSON Body: $jsonBody\n";
echo "Parsed input: " . print_r($input, true) . "\n";
echo "Result: action = '$action'\n";
echo "Status: " . ($action === 'create-from-receiving' ? "✓ Correctly parsed!" : "✗ Failed") . "\n";

echo "\n" . str_repeat("=", 80) . "\n";
echo "CONCLUSION:\n";
echo "The fix allows reading 'action' from JSON body for POST requests.\n";
echo "This matches how the frontend sends the request.\n";

class MockInput {
    public static $data = '';
    private $position = 0;
    
    public function stream_open($path, $mode, $options, &$opened_path) {
        $this->position = 0;
        return true;
    }
    
    public function stream_read($count) {
        $ret = substr(self::$data, $this->position, $count);
        $this->position += strlen($ret);
        return $ret;
    }
    
    public function stream_eof() {
        return $this->position >= strlen(self::$data);
    }
    
    public function stream_stat() {
        return [];
    }
}
