<?php
/**
 * CHECK INVENTORY MOVEMENTS TABLE STRUCTURE
 */

require_once 'config/database.php';

$db = getDB();

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "INVENTORY_MOVEMENTS TABLE STRUCTURE\n";
echo "═══════════════════════════════════════════════════════════════════════\n\n";

// Get table structure
$stmt = $db->query("DESCRIBE inventory_movements");
$columns = $stmt->fetchAll();

echo "COLUMNS:\n";
echo "───────────────────────────────────────────────────────────────────────\n";
foreach ($columns as $col) {
    echo sprintf("%-25s %-15s %-10s %-10s %s\n", 
        $col['Field'], 
        $col['Type'], 
        $col['Null'], 
        $col['Key'],
        $col['Extra']
    );
}

echo "\n";

// Get sample rows with ALL columns
$stmt = $db->query("SELECT * FROM inventory_movements LIMIT 3");
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "SAMPLE ROWS (showing all columns):\n";
echo "───────────────────────────────────────────────────────────────────────\n";

foreach ($rows as $i => $row) {
    echo "\nRow " . ($i + 1) . ":\n";
    foreach ($row as $key => $value) {
        if ($key === 'data' && $value) {
            // Pretty print JSON
            $decoded = json_decode($value, true);
            if ($decoded) {
                echo "  {$key}:\n";
                foreach ($decoded as $k => $v) {
                    echo "    {$k}: " . (is_array($v) ? json_encode($v) : $v) . "\n";
                }
            } else {
                echo "  {$key}: [Invalid JSON]\n";
            }
        } else {
            $displayValue = $value === null ? '[NULL]' : $value;
            if (strlen($displayValue) > 100) {
                $displayValue = substr($displayValue, 0, 100) . '...';
            }
            echo "  {$key}: {$displayValue}\n";
        }
    }
}

echo "\n";
echo "═══════════════════════════════════════════════════════════════════════\n";
echo "TABLE CHECK COMPLETE\n";
echo "═══════════════════════════════════════════════════════════════════════\n";
