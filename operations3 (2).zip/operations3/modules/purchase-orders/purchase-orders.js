import { DataService } from '../../assets/js/utils/data-service.js';
import { Validator } from '../../assets/js/utils/validator.js';
import { toast } from '../../assets/js/components/toast.js';
import { modal } from '../../assets/js/components/modal.js';
import { DataTable } from '../../assets/js/components/table.js';
import { store } from '../../assets/js/store.js';
import { formatCurrency } from '../../assets/js/utils/format.js';
import { BadgeHelper } from '../../assets/js/utils/badge-helper.js';

const dataService = new DataService();

// Demo Integration Mode Configuration
let demoConfig = null;

async function loadDemoConfig() {
    if (!demoConfig) {
        try {
            const response = await fetch('api/demo-config.php');
            const result = await response.json();
            demoConfig = result.success ? result.data : { demoMode: false, demoMessage: '' };
        } catch (error) {
            console.warn('Could not load demo config:', error);
            demoConfig = { demoMode: false, demoMessage: '' };
        }
    }
    return demoConfig;
}

// --- RENDER FUNCTION ---
export async function renderPurchaseOrders() {
    const container = document.getElementById('appContent');
    const userRole = store.getState().role;
    const canApprove = userRole === 'admin' || userRole === 'manager';
    const canCreate = userRole === 'admin' || userRole === 'manager' || userRole === 'staff';
    
    // Load demo configuration
    const config = await loadDemoConfig();

    container.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:26px; flex-wrap:wrap; gap:16px; background:var(--bg-card); padding:22px 26px; border-radius:12px; border:1px solid var(--border-color); box-shadow:var(--shadow-sm);">
            <div>
                <h1 class="page-title">Purchase Orders</h1>
                <p class="page-subtitle">Manage vendor orders, track approvals, and receive stock.</p>
                ${config.demoMode ? BadgeHelper.getDemoIndicator(config.demoMessage) : ''}
            </div>
            ${canCreate ? `<button id="createPoBtn" style="background:var(--primary-red); color:white; padding:10px 20px; border:none; border-radius:8px; font-weight:600; cursor:pointer; display:flex; align-items:center; gap:8px;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>
                Create PO
            </button>` : ''}
        </div>

        <!-- Status Tabs -->
        <div class="status-tabs-container" style="background:var(--bg-card); border:1px solid var(--border-color); border-radius:12px; padding:8px; margin-bottom:20px;">
            <div class="status-tabs" style="display:flex; gap:6px; overflow-x:auto;">
                <button class="status-tab active" data-status="" style="flex:1; min-width:100px; padding:12px 16px; border:none; border-radius:8px; background:transparent; color:var(--text-secondary); font-weight:600; cursor:pointer; transition:all 0.2s; white-space:nowrap;">
                    <span style="font-size:0.85rem;">All Orders</span>
                    <span class="tab-count" style="display:block; font-size:1.1rem; color:var(--text-primary); margin-top:4px;">0</span>
                </button>
                <button class="status-tab" data-status="Pending" style="flex:1; min-width:100px; padding:12px 16px; border:none; border-radius:8px; background:transparent; color:var(--text-secondary); font-weight:600; cursor:pointer; transition:all 0.2s; white-space:nowrap;">
                    <span style="font-size:0.85rem;">⏳ Pending</span>
                    <span class="tab-count" style="display:block; font-size:1.1rem; color:#F59E0B; margin-top:4px;">0</span>
                </button>
                <button class="status-tab" data-status="Approved" style="flex:1; min-width:100px; padding:12px 16px; border:none; border-radius:8px; background:transparent; color:var(--text-secondary); font-weight:600; cursor:pointer; transition:all 0.2s; white-space:nowrap;">
                    <span style="font-size:0.85rem;">✓ Approved</span>
                    <span class="tab-count" style="display:block; font-size:1.1rem; color:#3B82F6; margin-top:4px;">0</span>
                </button>
                <button class="status-tab" data-status="RECEIVED" style="flex:1; min-width:100px; padding:12px 16px; border:none; border-radius:8px; background:transparent; color:var(--text-secondary); font-weight:600; cursor:pointer; transition:all 0.2s; white-space:nowrap;">
                    <span style="font-size:0.85rem;">📦 Received</span>
                    <span class="tab-count" style="display:block; font-size:1.1rem; color:#10B981; margin-top:4px;">0</span>
                </button>
                <button class="status-tab" data-status="Draft" style="flex:1; min-width:100px; padding:12px 16px; border:none; border-radius:8px; background:transparent; color:var(--text-secondary); font-weight:600; cursor:pointer; transition:all 0.2s; white-space:nowrap;">
                    <span style="font-size:0.85rem;">📝 Draft</span>
                    <span class="tab-count" style="display:block; font-size:1.1rem; color:#9CA3AF; margin-top:4px;">0</span>
                </button>
                <button class="status-tab" data-status="Cancelled" style="flex:1; min-width:100px; padding:12px 16px; border:none; border-radius:8px; background:transparent; color:var(--text-secondary); font-weight:600; cursor:pointer; transition:all 0.2s; white-space:nowrap;">
                    <span style="font-size:0.85rem;">✕ Cancelled</span>
                    <span class="tab-count" style="display:block; font-size:1.1rem; color:#EF4444; margin-top:4px;">0</span>
                </button>
            </div>
        </div>

        <!-- Search Filter -->
        <div style="display:flex; gap:16px; margin-bottom:20px; flex-wrap:wrap;">
            <input type="text" id="poSearch" placeholder="🔍 Search by PO #, Supplier..." style="flex:1; min-width:200px; padding:12px 16px; border:1px solid var(--border-color); border-radius:8px; background:var(--bg-white); color:var(--text-primary); font-size:0.95rem;">
        </div>

        <!-- Status Key/Legend Box -->
        <div style="background:var(--bg-card); border:1px solid var(--border-color); border-radius:10px; padding:16px 20px; margin-bottom:20px;">
            <div style="display:flex; align-items:center; gap:12px; margin-bottom:12px;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>
                <h4 style="font-weight:600; font-size:0.95rem; color:var(--text-primary); margin:0;">Status Key</h4>
            </div>
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:12px;">
                <div style="display:flex; align-items:center; gap:8px;">
                    <span style="padding:3px 10px; border-radius:999px; font-size:0.75rem; font-weight:600; background:#E5E7EB; color:#6B7280;">Draft</span>
                    <span style="font-size:0.85rem; color:var(--text-secondary);">Not yet submitted</span>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                    <span style="padding:3px 10px; border-radius:999px; font-size:0.75rem; font-weight:600; background:#FEF3C7; color:#92400E;">Pending</span>
                    <span style="font-size:0.85rem; color:var(--text-secondary);">Awaiting approval</span>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                    <span style="padding:3px 10px; border-radius:999px; font-size:0.75rem; font-weight:600; background:#DBEAFE; color:#1E40AF;">Approved</span>
                    <span style="font-size:0.85rem; color:var(--text-secondary);">Ready to receive</span>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                    <span style="padding:3px 10px; border-radius:999px; font-size:0.75rem; font-weight:600; background:#D1FAE5; color:#065F46;">Fully Received</span>
                    <span style="font-size:0.85rem; color:var(--text-secondary);">All items received</span>
                </div>
                <div style="display:flex; align-items:center; gap:8px;">
                    <span style="padding:3px 10px; border-radius:999px; font-size:0.75rem; font-weight:600; background:#FEE2E2; color:#991B1B;">Cancelled</span>
                    <span style="font-size:0.85rem; color:var(--text-secondary);">Order cancelled</span>
                </div>
            </div>
        </div>

        <style>
            .status-tab.active {
                background: linear-gradient(135deg, var(--primary-orange), var(--primary-red)) !important;
                color: white !important;
                box-shadow: 0 4px 12px rgba(255, 122, 0, 0.3);
            }
            .status-tab.active .tab-count {
                color: white !important;
            }
            .status-tab:hover:not(.active) {
                background: var(--bg-gray) !important;
            }
            .status-tabs::-webkit-scrollbar {
                height: 4px;
            }
            .status-tabs::-webkit-scrollbar-thumb {
                background: var(--border-color);
                border-radius: 4px;
            }
        </style>

        <!-- Table Container -->
        <div id="poTableContainer"></div>
    `;

    // --- LOAD DATA ---
    await loadPOs();

    // --- EVENT LISTENERS ---
    document.getElementById('createPoBtn')?.addEventListener('click', () => openPoForm());
    document.getElementById('poSearch')?.addEventListener('input', filterPOData);
    
    // Listen for POR creation events to update PO badges
    window.addEventListener('porCreated', (event) => {
        console.log('POR created - updating PO list and badges');
        loadPOData(); // Reload to update badge counts
    });
    
    // Tab click handlers
    document.querySelectorAll('.status-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            // Remove active class from all tabs
            document.querySelectorAll('.status-tab').forEach(t => t.classList.remove('active'));
            // Add active class to clicked tab
            tab.classList.add('active');
            // Filter data
            filterPOData();
        });
    });
}

// --- STATE & DATA ---
let currentPOs = [];
let poTable = null;

async function loadPOs() {
    try {
        const allPOs = await dataService.findAll('purchase_orders');
        // Filter out archived POs by default
        currentPOs = allPOs.filter(po => po.status !== 'Archived');
        updateSummaryStats();
        renderPOTable();
    } catch (error) {
        toast.show('Failed to load purchase orders.', 'error');
        console.error(error);
    }
}

// --- UI HELPERS ---
function getStatusBadge(status) {
    return BadgeHelper.getPOStatusBadge(status);
}

function updateSummaryStats() {
    const counts = {
        draft: currentPOs.filter(p => p.status === 'Draft').length,
        pending: currentPOs.filter(p => p.status === 'Pending' || p.status === 'PENDING').length,
        approved: currentPOs.filter(p => p.status === 'Approved').length,
        received: currentPOs.filter(p => 
            p.status === 'Partially Received' || 
            p.status === 'Fully Received' || 
            p.status === 'Received' ||
            p.status === 'RECEIVED'
        ).length,
        cancelled: currentPOs.filter(p => p.status === 'Cancelled').length,
        all: currentPOs.length
    };
    
    // Update tab counts only (cards removed)
    const tabs = document.querySelectorAll('.status-tab');
    tabs.forEach(tab => {
        const status = tab.getAttribute('data-status');
        const countSpan = tab.querySelector('.tab-count');
        if (countSpan) {
            if (status === '') {
                countSpan.textContent = counts.all;
            } else if (status === 'Pending') {
                countSpan.textContent = counts.pending;
            } else if (status === 'Approved') {
                countSpan.textContent = counts.approved;
            } else if (status === 'RECEIVED') {
                countSpan.textContent = counts.received;
            } else if (status === 'Draft') {
                countSpan.textContent = counts.draft;
            } else if (status === 'Cancelled') {
                countSpan.textContent = counts.cancelled;
            }
        }
    });
}

// Generate proper PO numbers in PO-YYYY-NNNN format
async function generatePoNumber() {
    const currentYear = new Date().getFullYear();
    const allPOs = await dataService.findAll('purchase_orders');
    
    // Find the highest PO number for current year
    const yearPOs = allPOs.filter(po => 
        po.poNumber && po.poNumber.startsWith(`PO-${currentYear}-`)
    );
    
    let maxNumber = 0;
    yearPOs.forEach(po => {
        const match = po.poNumber.match(/PO-\d{4}-(\d{4})/);
        if (match) {
            maxNumber = Math.max(maxNumber, parseInt(match[1]));
        }
    });
    
    const nextNumber = (maxNumber + 1).toString().padStart(4, '0');
    return `PO-${currentYear}-${nextNumber}`;
}

// --- RENDER TABLE ---
function renderPOTable(filteredData = null) {
    const dataToRender = filteredData || currentPOs;
    const container = document.getElementById('poTableContainer');
    const userRole = store.getState().role;
    const canApprove = userRole === 'admin' || userRole === 'manager';
    const canArchive = userRole === 'admin';

    const columns = [
        { key: 'poNumber', label: 'PO #' },
        { key: 'supplier', label: 'Supplier' },
        { key: 'orderDate', label: 'Date' },
        { key: 'total', label: 'Total Cost' },
        { key: 'status', label: 'Status' }
    ];

    // Map data for table
    const formattedData = dataToRender.map(po => ({
        ...po,
        orderDate: new Date(po.orderDate).toLocaleDateString(),
        total: BadgeHelper.formatCurrency(po.total, false, true),
        status: getStatusBadge(po.status),
        // Keep raw values for approve modal logic
        rawStatus: po.status,
        rawTotal: po.total
    }));

    // Define available actions based on status and role
    let actionsConfig = { actions: true };

    if (canApprove || canArchive) {
        actionsConfig.onEdit = (rowData) => handlePOWorkflow(rowData);
        
        // Add approve action for pending orders (admin only)
        if (userRole === 'admin') {
            actionsConfig.onApprove = (rowData) => {
                if (rowData.rawStatus === 'Pending') {
                    approvePurchaseOrder(rowData);
                }
            };
        }
        
        if (canArchive) {
            actionsConfig.onDelete = (rowData) => {
                if (['Draft', 'Pending', 'Cancelled'].includes(rowData.rawStatus)) {
                    confirmArchive(rowData);
                } else {
                    toast.show('Cannot archive an order that has been approved or processed.', 'warning');
                }
            };
            actionsConfig.deleteLabel = 'Archive'; // Change button label
        }
    }

    if (!poTable) {
        poTable = new DataTable('poTableContainer', columns, formattedData, actionsConfig);
    } else {
        poTable.updateData(formattedData);
    }
}

// --- FILTER DATA ---
function filterPOData() {
    const searchTerm = document.getElementById('poSearch').value.toLowerCase();
    
    // Get active tab's status filter
    const activeTab = document.querySelector('.status-tab.active');
    const statusFilter = activeTab ? activeTab.getAttribute('data-status') : '';

    const filtered = currentPOs.filter(po => {
        // Search filter
        const matchesSearch = po.poNumber.toLowerCase().includes(searchTerm) || 
                              po.supplier.toLowerCase().includes(searchTerm);
        
        // Status filter
        let matchesStatus = true;
        if (statusFilter) {
            if (statusFilter === 'RECEIVED') {
                // "Received" tab includes all received statuses
                matchesStatus = po.status === 'Partially Received' || 
                               po.status === 'Fully Received' || 
                               po.status === 'Received' ||
                               po.status === 'RECEIVED';
            } else if (statusFilter === 'Pending') {
                matchesStatus = po.status === 'Pending' || po.status === 'PENDING';
            } else {
                matchesStatus = po.status === statusFilter;
            }
        }
        
        return matchesSearch && matchesStatus;
    });

    renderPOTable(filtered);
}

// --- CRUD: CREATE PO FORM ---
async function openPoForm() {
    const title = 'Create Purchase Order';
    const suppliers = await dataService.findAll('suppliers');
    const products = await dataService.findAll('products');

    // Step 1 HTML (Select Supplier)
    const formHTML = `
        <form id="poForm" style="display:grid; gap:16px;">
            <!-- Available Products Reference -->
            <div style="background:var(--bg-gray); padding:16px; border-radius:8px; border:1px solid var(--border-color);">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
                    <h4 style="margin:0; color:var(--text-primary); font-size:0.95rem;">📦 Available Products</h4>
                    <span style="font-size:0.85rem; color:var(--text-secondary);">${products.length} items</span>
                </div>
                <div style="max-height:200px; overflow-y:auto; background:var(--bg-white); border:1px solid var(--border-color); border-radius:6px;">
                    <table style="width:100%; font-size:0.85rem; border-collapse:collapse;">
                        <thead style="position:sticky; top:0; background:var(--bg-gray); border-bottom:2px solid var(--border-color); z-index:1;">
                            <tr>
                                <th style="padding:8px 12px; text-align:left; font-weight:600; color:var(--text-primary);">Product Name</th>
                                <th style="padding:8px 12px; text-align:left; font-weight:600; color:var(--text-primary);">SKU</th>
                                <th style="padding:8px 12px; text-align:right; font-weight:600; color:var(--text-primary);">Price</th>
                                <th style="padding:8px 12px; text-align:right; font-weight:600; color:var(--text-primary);">Stock</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${products.length > 0 ? products.map(p => `
                                <tr style="border-bottom:1px solid var(--border-color);">
                                    <td style="padding:8px 12px; color:var(--text-primary);">${p.name}</td>
                                    <td style="padding:8px 12px; color:var(--text-secondary);">${p.sku || 'N/A'}</td>
                                    <td style="padding:8px 12px; text-align:right; font-weight:600; color:var(--primary-red);">₱${parseFloat(p.price || 0).toFixed(2)}</td>
                                    <td style="padding:8px 12px; text-align:right; color:${(p.stock || 0) > 10 ? '#10B981' : (p.stock || 0) > 0 ? '#F59E0B' : '#EF4444'};">
                                        ${p.stock || 0}
                                    </td>
                                </tr>
                            `).join('') : '<tr><td colspan="4" style="padding:20px; text-align:center; color:var(--text-secondary);">No products available</td></tr>'}
                        </tbody>
                    </table>
                </div>
                <p style="margin:8px 0 0 0; font-size:0.75rem; color:var(--text-secondary); font-style:italic;">
                    💡 Tip: Review available products above before creating your order
                </p>
            </div>
            
            <div>
                <label style="display:block; font-weight:500; margin-bottom:4px;">Select Supplier *</label>
                <select id="po_supplier" class="form-input" style="width:100%;">
                    <option value="">-- Select Supplier --</option>
                    ${suppliers.map(s => `<option value="${s.id}">${s.company} - ${s.contactPerson}</option>`).join('')}
                </select>
            </div>
            
            <div id="poItemsContainer" style="display:none; margin-top:16px; border-top:1px solid var(--border-color); padding-top:16px;">
                <h4 style="margin-bottom:12px;">Order Items</h4>
                <div id="poItemsList"></div>
                <button type="button" id="addItemBtn" style="margin-top:8px; padding:6px 12px; background:transparent; border:1px solid var(--border-color); border-radius:4px; color:var(--text-secondary); cursor:pointer;">+ Add Item</button>
                <div style="margin-top:12px; text-align:right; font-weight:700; font-size:1.2rem;">
                    Total: ₱<span id="poTotalDisplay">0.00</span>
                </div>
            </div>
            
            <div id="poNotesContainer" style="display:none;">
                <label style="display:block; font-weight:500; margin-bottom:4px;">Notes (Optional)</label>
                <textarea id="po_notes" class="form-input" rows="2" placeholder="Any special instructions or notes..."></textarea>
            </div>
        </form>
    `;

    modal.open(title, formHTML, {
        confirmText: 'Submit for Approval',
        onConfirm: async () => {
            const supplierId = document.getElementById('po_supplier').value;
            const items = collectPOItems();
            const notes = document.getElementById('po_notes').value.trim();
            
            if (!supplierId) { toast.show('Please select a supplier.', 'error'); return; }
            if (items.length === 0) { toast.show('Please add at least one item to the order.', 'error'); return; }

            // Validate items
            for (let item of items) {
                if (!item.productId || !item.productName || item.quantity <= 0 || item.unitCost <= 0) {
                    toast.show('Please ensure all items have valid product, quantity, and cost.', 'error');
                    return;
                }
            }

            const supplierData = suppliers.find(s => s.id === supplierId);
            const subtotal = items.reduce((sum, item) => sum + (item.quantity * item.unitCost), 0);

            const poData = {
                poNumber: await generatePoNumber(),
                supplier_name: supplierData.company,
                supplierId: supplierId,
                items: items,
                subtotal: subtotal,
                total: subtotal, // For demo, no taxes/fees
                orderDate: new Date().toISOString(),
                expectedDate: null,
                status: 'Pending',
                notes: notes,
                createdBy: store.getState().user?.name || 'System',
                totalItems: items.reduce((sum, item) => sum + item.quantity, 0),
                receivedItems: 0,
                remainingItems: items.reduce((sum, item) => sum + item.quantity, 0)
            };

            try {
                await dataService.create('purchase_orders', poData);
                toast.show('Purchase Order created and sent for approval!', 'success');
                modal.close();
                await loadPOs();
            } catch (error) {
                console.error('PO Creation Error:', error);
                toast.show('Failed to create Purchase Order.', 'error');
            }
        }
    });

    // Attach Event Listeners for Dynamic Item Addition
    document.getElementById('po_supplier').addEventListener('change', async (e) => {
        const container = document.getElementById('poItemsContainer');
        const notesContainer = document.getElementById('poNotesContainer');
        const list = document.getElementById('poItemsList');
        
        if (e.target.value) {
            container.style.display = 'block';
            notesContainer.style.display = 'block';
            list.innerHTML = ''; // Clear previous items
            addPOItemRow(list, products); // Add initial row
        } else {
            container.style.display = 'none';
            notesContainer.style.display = 'none';
        }
    });

    document.getElementById('addItemBtn').addEventListener('click', () => {
        const list = document.getElementById('poItemsList');
        addPOItemRow(list, products);
    });
}

function addPOItemRow(container, products) {
    const row = document.createElement('div');
    row.className = 'po-item-row';
    row.style.cssText = `
        display: grid; grid-template-columns: 2fr 1fr 1fr 60px; gap: 8px; margin-bottom: 8px;
        align-items: center; padding: 8px; border: 1px solid var(--border-color); border-radius: 4px;
    `;
    
    // Create dropdown for products
    const productOptions = products.map(p => 
        `<option value="${p.id}" data-name="${p.name}" data-price="${p.price}">${p.name} - ₱${p.price}</option>`
    ).join('');
    
    row.innerHTML = `
        <select class="po-item-product form-input" style="padding:8px; border:1px solid var(--border-color); border-radius:4px;">
            <option value="">-- Select Product --</option>
            ${productOptions}
        </select>
        <input type="number" class="po-item-qty" placeholder="Qty" min="1" value="1" style="padding:8px; border:1px solid var(--border-color); border-radius:4px;">
        <input type="number" class="po-item-cost" placeholder="Unit Cost ₱" step="0.01" min="0" value="0.00" style="padding:8px; border:1px solid var(--border-color); border-radius:4px;">
        <button type="button" class="po-remove-item" style="background:#FEE2E2; color:#991B1B; border:none; border-radius:4px; cursor:pointer; padding:8px;">&times;</button>
    `;

    container.appendChild(row);

    // Auto-fill price when product is selected
    const productSelect = row.querySelector('.po-item-product');
    const costInput = row.querySelector('.po-item-cost');
    
    productSelect.addEventListener('change', (e) => {
        const selectedOption = e.target.options[e.target.selectedIndex];
        if (selectedOption.dataset.price) {
            costInput.value = parseFloat(selectedOption.dataset.price).toFixed(2);
            updateTotalDisplay();
        }
    });

    // Add Live Update for Total Cost
    const inputs = row.querySelectorAll('input');
    inputs.forEach(input => {
        input.addEventListener('input', updateTotalDisplay);
    });

    // Remove Item
    row.querySelector('.po-remove-item').addEventListener('click', () => {
        row.remove();
        updateTotalDisplay();
    });
}

function collectPOItems() {
    const rows = document.querySelectorAll('.po-item-row');
    const items = [];
    rows.forEach(row => {
        const productSelect = row.querySelector('.po-item-product');
        const selectedOption = productSelect.options[productSelect.selectedIndex];
        const productId = productSelect.value;
        const productName = selectedOption.dataset.name;
        const qty = parseInt(row.querySelector('.po-item-qty').value) || 0;
        const cost = parseFloat(row.querySelector('.po-item-cost').value) || 0;
        
        if (productId && productName && qty > 0 && cost > 0) {
            items.push({ 
                productId: productId,
                productName: productName, 
                quantity: qty, 
                unitCost: cost,
                subtotal: qty * cost,
                receivedQuantity: 0,
                remainingQuantity: qty
            });
        }
    });
    return items;
}

function updateTotalDisplay() {
    const items = collectPOItems();
    const total = items.reduce((sum, item) => sum + (item.quantity * item.unitCost), 0);
    document.getElementById('poTotalDisplay').textContent = formatCurrency(total);
}

// --- CRUD: WORKFLOW & APPROVAL ---
async function handlePOWorkflow(rowData) {
    const userRole = store.getState().role;
    
    // Renders the modal based on status
    const title = `Purchase Order: ${rowData.poNumber}`;
    let actions = { confirmText: 'Close', onConfirm: () => modal.close() };
    
    // Calculate receiving progress
    const totalOrdered = rowData.items.reduce((sum, item) => sum + item.quantity, 0);
    const totalReceived = rowData.items.reduce((sum, item) => sum + (item.receivedQuantity || 0), 0);
    const receivingProgress = totalOrdered > 0 ? ((totalReceived / totalOrdered) * 100).toFixed(1) : 0;
    
    // Fetch related PORs
    let porData = null;
    try {
        const porResponse = await fetch(`api/por.php?action=by-po&po_id=${rowData.id}`);
        const porResult = await porResponse.json();
        if (porResult.success && porResult.data && porResult.data.length > 0) {
            porData = porResult.data;
        }
    } catch (error) {
        console.warn('Could not fetch POR data:', error);
    }
    
    let bodyHTML = `
        <div style="display:grid; gap:12px; margin-bottom:16px;">
            <p><strong>Supplier:</strong> ${rowData.supplier}</p>
            <p><strong>Order Date:</strong> ${new Date(rowData.orderDate).toLocaleDateString()}</p>
            <p><strong>Status:</strong> ${getStatusBadge(rowData.status)}</p>
            ${rowData.expectedDate ? `<p><strong>Expected Date:</strong> ${new Date(rowData.expectedDate).toLocaleDateString()}</p>` : ''}
            ${rowData.notes ? `<p><strong>Notes:</strong> ${rowData.notes}</p>` : ''}
        </div>
        
        ${totalReceived > 0 ? `
        <div style="margin-bottom:16px; padding:12px; background:#F3F4F6; border-radius:6px;">
            <h4 style="margin-bottom:8px;">Receiving Progress</h4>
            <div style="background:#E5E7EB; border-radius:4px; height:8px; margin-bottom:4px;">
                <div style="background:#10B981; height:100%; width:${receivingProgress}%; border-radius:4px;"></div>
            </div>
            <p style="font-size:0.9rem; color:var(--text-secondary);">${totalReceived} of ${totalOrdered} items received (${receivingProgress}%)</p>
        </div>
        ` : ''}
        
        ${porData && porData.length > 0 ? `
        <div style="margin-bottom:16px; padding:12px; background:#F0FDF4; border-left:4px solid #10B981; border-radius:6px;">
            <h4 style="margin:0 0 12px 0; color:#065F46; display:flex; align-items:center; gap:8px;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/></svg>
                Proof of Receiving (POR) Records
            </h4>
            ${porData.map(por => {
                const statusColor = por.status === 'Completed' ? '#10B981' : por.status === 'Draft' ? '#F59E0B' : '#EF4444';
                const inspectionColor = ({ Passed: '#10B981', Completed: '#10B981', Partial: '#F97316', 'In Progress': '#3B82F6', Failed: '#EF4444' })[por.inspection_status] || '#F59E0B';
                const acceptanceRate = por.total_received > 0 ? ((por.total_accepted / por.total_received) * 100).toFixed(1) : 0;
                
                return `
                    <div style="background:white; padding:12px; border-radius:6px; margin-bottom:8px; border:1px solid #D1FAE5;">
                        <div style="display:flex; justify-content:space-between; align-items:start; margin-bottom:10px;">
                            <div>
                                <strong style="color:#065F46; font-size:1.05rem;">${por.por_number}</strong>
                                <div style="display:flex; gap:6px; margin-top:4px;">
                                    <span style="background:${statusColor}; color:white; padding:2px 8px; border-radius:4px; font-size:0.75rem; font-weight:600;">${por.status}</span>
                                    <span style="background:${inspectionColor}; color:white; padding:2px 8px; border-radius:4px; font-size:0.75rem; font-weight:600;">${por.inspection_status}</span>
                                    ${por.inventory_updated == 1 ? '<span style="background:#3B82F6; color:white; padding:2px 8px; border-radius:4px; font-size:0.75rem; font-weight:600;">Inventoried</span>' : ''}
                                </div>
                            </div>
                            <button onclick="viewPORFromPO(${por.id})" style="background:#065F46; color:white; padding:6px 12px; border:none; border-radius:4px; cursor:pointer; font-size:0.85rem; font-weight:600;">
                                View POR
                            </button>
                        </div>
                        <div style="display:grid; grid-template-columns:repeat(4, 1fr); gap:8px; font-size:0.85rem;">
                            <div style="text-align:center; padding:6px; background:#F9FAFB; border-radius:4px;">
                                <div style="color:#9CA3AF; font-size:0.75rem;">Received</div>
                                <div style="font-weight:600; color:#3B82F6;">${por.total_received || 0}</div>
                            </div>
                            <div style="text-align:center; padding:6px; background:#F9FAFB; border-radius:4px;">
                                <div style="color:#9CA3AF; font-size:0.75rem;">Accepted</div>
                                <div style="font-weight:600; color:#10B981;">${por.total_accepted || 0}</div>
                            </div>
                            <div style="text-align:center; padding:6px; background:#F9FAFB; border-radius:4px;">
                                <div style="color:#9CA3AF; font-size:0.75rem;">Rejected</div>
                                <div style="font-weight:600; color:#EF4444;">${por.total_rejected || 0}</div>
                            </div>
                            <div style="text-align:center; padding:6px; background:#F9FAFB; border-radius:4px;">
                                <div style="color:#9CA3AF; font-size:0.75rem;">Acceptance</div>
                                <div style="font-weight:600; color:${acceptanceRate >= 95 ? '#10B981' : acceptanceRate >= 80 ? '#F59E0B' : '#EF4444'};">${acceptanceRate}%</div>
                            </div>
                        </div>
                        <div style="margin-top:8px; font-size:0.8rem; color:#6B7280;">
                            <strong>Date:</strong> ${new Date(por.receiving_date).toLocaleDateString()} | 
                            <strong>Accepted Value:</strong> ₱${formatCurrency(por.accepted_value || 0)}
                        </div>
                    </div>
                `;
            }).join('')}
        </div>
        ` : totalReceived > 0 ? `
        <div style="margin-bottom:16px; padding:12px; background:#FFF7ED; border-left:4px solid #F59E0B; border-radius:6px;">
            <h4 style="margin:0 0 8px 0; color:#92400E; display:flex; align-items:center; gap:8px;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
                No Proof of Receiving Yet
            </h4>
            <p style="margin:0; font-size:0.85rem; color:#92400E;">
                Items have been received but no POR has been created. Create a POR in the Receiving module for quality inspection and inventory update.
            </p>
        </div>
        ` : ''}
        
        <div style="border-top:1px solid var(--border-color); padding-top:16px;">
            <h4 style="margin-bottom:8px;">Items Ordered</h4>
            ${rowData.items.map(item => `
                <div style="display:grid; grid-template-columns:2fr 1fr 1fr 1fr; gap:8px; padding:8px 0; border-bottom:1px solid var(--border-color); font-size:0.9rem; align-items:center;">
                    <div style="font-weight:500;">${item.productName}</div>
                    <div>Qty: ${item.quantity}</div>
                    <div>₱${formatCurrency(item.unitCost)}</div>
                    <div style="text-align:right;">₱${formatCurrency(item.quantity * item.unitCost)}</div>
                </div>
            `).join('')}
            <div style="text-align:right; font-weight:bold; margin-top:8px; padding-top:8px; border-top:2px solid var(--border-color);">
                Total: ₱${formatCurrency(rowData.total)}
            </div>
        </div>
    `;

    // Workflow Actions based on status and role
    if (userRole === 'admin' || userRole === 'manager') {
        if (rowData.status === 'Pending') {
            actions = {
                confirmText: 'Approve Order',
                cancelText: 'Reject',
                onConfirm: async () => {
                    await dataService.update('purchase_orders', rowData.id, { 
                        status: 'Approved',
                        approvedBy: store.getState().user?.name || 'System',
                        approvedAt: new Date().toISOString()
                    });
                    toast.show('Purchase Order approved! Ready for receiving.', 'success');
                    modal.close();
                    await loadPOs();
                },
                onCancel: async () => {
                    await dataService.update('purchase_orders', rowData.id, { 
                        status: 'Draft',
                        rejectedBy: store.getState().user?.name || 'System',
                        rejectedAt: new Date().toISOString()
                    });
                    toast.show('Purchase Order rejected and moved back to Draft.', 'info');
                    modal.close();
                    await loadPOs();
                }
            };
        } else if (rowData.status === 'Draft') {
            actions = {
                confirmText: 'Submit for Approval',
                onConfirm: async () => {
                    await dataService.update('purchase_orders', rowData.id, { 
                        status: 'Pending',
                        submittedBy: store.getState().user?.name || 'System',
                        submittedAt: new Date().toISOString()
                    });
                    toast.show('Purchase Order submitted for approval.', 'success');
                    modal.close();
                    await loadPOs();
                }
            };
        } else if (rowData.status === 'Approved' || rowData.status === 'Partially Received') {
            // Add Generate QR button for approved POs
            bodyHTML += `
                <div style="margin-top:20px; padding:16px; background:#DBEAFE; border-left:4px solid #3B82F6; border-radius:8px;">
                    <h4 style="margin:0 0 8px 0; color:#1E40AF;">📱 Proof of Receiving (POR)</h4>
                    <p style="margin:0 0 12px 0; font-size:0.9rem; color:#1E40AF;">
                        Generate a QR code for this purchase order. Warehouse staff can scan this code during delivery to record receipt.
                    </p>
                    <button onclick="generatePOQR('${rowData.id}')" style="background:var(--primary-red); color:white; padding:10px 20px; border:none; border-radius:6px; font-weight:600; cursor:pointer; display:flex; align-items:center; gap:8px;">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 7v4a1 1 0 001 1h3"/><path d="M21 7v4a1 1 0 01-1 1h-3"/><path d="M3 17v-4a1 1 0 011-1h3"/><path d="M21 17v-4a1 1 0 00-1-1h-3"/></svg>
                        ${rowData.qrToken ? 'View QR Code' : 'Generate QR Code'}
                    </button>
                </div>
            `;
            
            actions = {
                confirmText: 'Go to Receiving',
                onConfirm: () => {
                    modal.close();
                    // Navigate to receiving module with this PO pre-selected
                    toast.show('Navigate to Receiving module to process this PO.', 'info');
                }
            };
        }
    }

    // Additional action for cancelling orders (admin only)
    if (userRole === 'admin' && ['Draft', 'Pending', 'Approved'].includes(rowData.status)) {
        const originalOnCancel = actions.onCancel;
        actions.cancelText = originalOnCancel ? 'Reject' : 'Cancel Order';
        actions.onCancel = originalOnCancel || (async () => {
            modal.open(
                'Cancel Purchase Order',
                '<p style="color:var(--text-secondary);">Are you sure you want to cancel this purchase order? This action cannot be undone.</p>',
                {
                    confirmText: 'Cancel Order',
                    onConfirm: async () => {
                        await dataService.update('purchase_orders', rowData.id, {
                            status: 'Cancelled',
                            cancelledBy: store.getState().user?.name || 'System',
                            cancelledAt: new Date().toISOString()
                        });
                        toast.show('Purchase Order cancelled.', 'info');
                        modal.close();
                        await loadPOs();
                    }
                }
            );
        });
    }

    modal.open(title, bodyHTML, actions);
}

// --- CRUD: ARCHIVE ---
async function confirmArchive(rowData) {
    modal.open(
        `Archive PO #${rowData.poNumber}?`, 
        `<p style="color:var(--text-secondary);">Are you sure you want to archive this order? Archived orders can be restored later if needed.</p>`,
        {
            confirmText: 'Archive Order',
            onConfirm: async () => {
                try {
                    // Update status to Archived instead of deleting
                    const response = await fetch('api/data.php?type=purchase_orders', {
                        method: 'GET'
                    });
                    const result = await response.json();
                    
                    if (result.success) {
                        const po = result.data.find(p => p.id === rowData.id);
                        if (po) {
                            po.status = 'Archived';
                            po.archivedAt = new Date().toISOString();
                            po.archivedBy = store.getState().name;
                            
                            const updateResponse = await fetch(`api/data.php?type=purchase_orders&id=${rowData.id}`, {
                                method: 'PUT',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify(po)
                            });
                            
                            const updateResult = await updateResponse.json();
                            if (updateResult.success) {
                                toast.show('Purchase Order archived successfully.', 'info');
                                modal.close();
                                await loadPOData();
                            } else {
                                throw new Error(updateResult.error);
                            }
                        }
                    }
                } catch (error) {
                    toast.show('Failed to archive order: ' + error.message, 'error');
                }
            }
        }
    );
}

// --- APPROVE PURCHASE ORDER ---
async function approvePurchaseOrder(rowData) {
    modal.open(
        `Approve PO #${rowData.poNumber}?`,
        `<div style="color:var(--text-secondary);">
            <p style="margin-bottom:16px;">Are you sure you want to approve this purchase order?</p>
            <div style="background:#F3F4F6; padding:16px; border-radius:8px; margin-bottom:16px;">
                <p><strong>Supplier:</strong> ${rowData.supplier}</p>
                <p><strong>Total Amount:</strong> ₱${formatCurrency(rowData.rawTotal || rowData.total)}</p>
                <p><strong>Items Count:</strong> ${rowData.items?.length || 0} items</p>
            </div>
            <p style="font-size:0.9rem; color:#059669;"><strong>✓ Once approved, this order will be ready for receiving.</strong></p>
        </div>`,
        {
            confirmText: 'Approve Order',
            cancelText: 'Cancel',
            onConfirm: async () => {
                try {
                    await dataService.update('purchase_orders', rowData.id, {
                        status: 'Approved',
                        approvedBy: store.getState().user?.name || 'System',
                        approvedAt: new Date().toISOString()
                    });
                    toast.show(`Purchase Order ${rowData.poNumber} approved successfully!`, 'success');
                    modal.close();
                    await loadPOs();
                } catch (error) {
                    console.error('Approval Error:', error);
                    toast.show('Failed to approve purchase order.', 'error');
                }
            }
        }
    );
}


// --- PO RECEIVING QR CODE GENERATION ---
window.generatePOQR = async function(poId) {
    try {
        // Check if QR already exists
        const po = currentPOs.find(p => p.id === poId);
        
        if (po && po.qrToken) {
            // QR already generated, just display it
            window.open(`view-po-qr.php?id=${poId}`, '_blank');
            return;
        }

        // Generate new QR code
        const response = await fetch('api/po-receiving.php?action=generate-qr', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ poId: poId })
        });

        const result = await response.json();

        if (result.success) {
            toast.show('QR code generated successfully!', 'success');
            
            // Refresh PO list to update status
            await loadPOs();
            modal.close();
            
            // Open QR code view in new tab
            window.open(`view-po-qr.php?id=${poId}`, '_blank');
        } else {
            toast.show(result.error || 'Failed to generate QR code', 'error');
        }
    } catch (error) {
        console.error('Error generating QR:', error);
        toast.show('Failed to generate QR code. Please try again.', 'error');
    }
};

// --- VIEW POR FROM PURCHASE ORDER ---
window.viewPORFromPO = async function(porId) {
    try {
        // Fetch POR data
        const response = await fetch(`api/por.php?action=details&id=${porId}`);
        const result = await response.json();
        
        if (result.success) {
            const por = result.data;
            
            const itemsHTML = por.items ? por.items.map(item => {
                const acceptanceRate = item.received_quantity > 0 
                    ? ((item.accepted_quantity / item.received_quantity) * 100).toFixed(1)
                    : 0;
                const statusColor = item.inspection_result === 'Passed' ? '#10B981' : 
                                  item.inspection_result === 'Failed' ? '#EF4444' : 
                                  item.inspection_result === 'Conditional' ? '#F59E0B' : '#9CA3AF';
                
                return `
                    <div style="display:grid; grid-template-columns:2fr 1fr 1fr 1fr 1fr 1fr; gap:8px; padding:8px; border-bottom:1px solid var(--border-color); font-size:0.85rem; align-items:center;">
                        <div>
                            <div style="font-weight:500;">${item.product_name}</div>
                            <div style="font-size:0.75rem; color:var(--text-secondary);">SKU: ${item.sku}</div>
                            ${item.batch_number ? `<div style="font-size:0.75rem; color:var(--text-secondary);">Batch: ${item.batch_number}</div>` : ''}
                        </div>
                        <div style="text-align:center;">
                            <div style="font-size:0.75rem; color:var(--text-secondary);">Ordered</div>
                            <div style="font-weight:600;">${item.ordered_quantity}</div>
                        </div>
                        <div style="text-align:center;">
                            <div style="font-size:0.75rem; color:var(--text-secondary);">Received</div>
                            <div style="font-weight:600; color:#3B82F6;">${item.received_quantity}</div>
                        </div>
                        <div style="text-align:center;">
                            <div style="font-size:0.75rem; color:var(--text-secondary);">Accepted</div>
                            <div style="font-weight:600; color:#10B981;">${item.accepted_quantity}</div>
                        </div>
                        <div style="text-align:center;">
                            <div style="font-size:0.75rem; color:var(--text-secondary);">Rejected</div>
                            <div style="font-weight:600; color:#EF4444;">${item.rejected_quantity}</div>
                        </div>
                        <div style="text-align:center;">
                            <span style="background:${statusColor}; color:white; padding:2px 6px; border-radius:4px; font-size:0.75rem; font-weight:500;">${item.inspection_result}</span>
                        </div>
                    </div>
                `;
            }).join('') : '<p style="color:var(--text-secondary);">No items available.</p>';
            
            const statusColor = por.status === 'Completed' ? '#10B981' : 
                              por.status === 'Draft' ? '#F59E0B' : '#EF4444';
            const inspectionColor = ({ Passed: '#10B981', Completed: '#10B981', Partial: '#F97316', 'In Progress': '#3B82F6', Failed: '#EF4444' })[por.inspection_status] || '#F59E0B';
            
            const bodyHTML = `
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:16px;">
                    <div>
                        <p style="margin-bottom:8px;"><strong>POR Number:</strong> ${por.por_number}</p>
                        <p style="margin-bottom:8px;"><strong>PO Number:</strong> ${por.purchase_order_number || 'N/A'}</p>
                        <p style="margin-bottom:8px;"><strong>Supplier:</strong> ${por.supplier_name}</p>
                        <p style="margin-bottom:8px;"><strong>Receiving Date:</strong> ${new Date(por.receiving_date).toLocaleDateString()}</p>
                    </div>
                    <div>
                        <p style="margin-bottom:8px;"><strong>Status:</strong> <span style="background:${statusColor}; color:white; padding:3px 8px; border-radius:4px; font-size:0.85rem; font-weight:500;">${por.status}</span></p>
                        <p style="margin-bottom:8px;"><strong>Inspection:</strong> <span style="background:${inspectionColor}; color:white; padding:3px 8px; border-radius:4px; font-size:0.85rem; font-weight:500;">${por.inspection_status}</span></p>
                        <p style="margin-bottom:8px;"><strong>Inventory Updated:</strong> ${por.inventory_updated == 1 ? '<span style="color:#10B981;">✓ Yes</span>' : '<span style="color:#9CA3AF;">✗ No</span>'}</p>
                    </div>
                </div>
                
                ${por.notes ? `<div style="margin-bottom:16px;"><strong>Notes:</strong><br><p style="color:var(--text-secondary); font-size:0.9rem;">${por.notes}</p></div>` : ''}
                ${por.inspection_notes ? `<div style="margin-bottom:16px;"><strong>Inspection Notes:</strong><br><p style="color:var(--text-secondary); font-size:0.9rem;">${por.inspection_notes}</p></div>` : ''}
                
                <div style="border-top:1px solid var(--border-color); padding-top:16px; margin-top:16px;">
                    <h4 style="margin-bottom:12px;">Inspection Results</h4>
                    <div style="display:grid; grid-template-columns:1fr 1fr 1fr 1fr; gap:12px; margin-bottom:16px;">
                        <div style="text-align:center; padding:10px; background:var(--bg-gray); border-radius:6px;">
                            <div style="font-size:0.75rem; color:var(--text-secondary);">Total Received</div>
                            <div style="font-size:1.3rem; font-weight:700; color:#3B82F6;">${por.total_received || 0}</div>
                        </div>
                        <div style="text-align:center; padding:10px; background:var(--bg-gray); border-radius:6px;">
                            <div style="font-size:0.75rem; color:var(--text-secondary);">Accepted</div>
                            <div style="font-size:1.3rem; font-weight:700; color:#10B981;">${por.total_accepted || 0}</div>
                        </div>
                        <div style="text-align:center; padding:10px; background:var(--bg-gray); border-radius:6px;">
                            <div style="font-size:0.75rem; color:var(--text-secondary);">Rejected</div>
                            <div style="font-size:1.3rem; font-weight:700; color:#EF4444;">${por.total_rejected || 0}</div>
                        </div>
                        <div style="text-align:center; padding:10px; background:var(--bg-gray); border-radius:6px;">
                            <div style="font-size:0.75rem; color:var(--text-secondary);">Acceptance Rate</div>
                            <div style="font-size:1.3rem; font-weight:700; color:${por.total_received > 0 && ((por.total_accepted / por.total_received) * 100) >= 95 ? '#10B981' : '#F59E0B'};">${por.total_received > 0 ? ((por.total_accepted / por.total_received) * 100).toFixed(1) : 0}%</div>
                        </div>
                    </div>
                    ${itemsHTML}
                </div>
                
                <div style="margin-top:16px; padding:12px; background:#EFF6FF; border-radius:6px; border-left:4px solid #3B82F6;">
                    <p style="font-size:0.9rem; color:#1E40AF; margin:0;">
                        <strong>💡 Tip:</strong> To edit inspection results, complete POR, or print the document, visit the <strong>Proof of Receiving</strong> module or click "Go to POR Module" below.
                    </p>
                </div>
            `;
            
            modal.open(`POR Details: ${por.por_number}`, bodyHTML, {
                confirmText: 'Go to POR Module',
                cancelText: 'Print POR',
                onConfirm: () => {
                    modal.close();
                    // Navigate to POR module
                    document.querySelector('.nav-item[data-page="por"]')?.click();
                },
                onCancel: () => {
                    // Open print view
                    window.open(`por-document.php?id=${porId}`, '_blank');
                }
            });
        } else {
            throw new Error(result.message || 'Failed to load POR details');
        }
    } catch (error) {
        console.error('Error viewing POR:', error);
        toast.show('Error loading POR details: ' + error.message, 'error');
    }
};

