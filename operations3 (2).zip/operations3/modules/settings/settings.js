import { store } from '../../assets/js/store.js';
import { toast } from '../../assets/js/components/toast.js';
import { modal } from '../../assets/js/components/modal.js';
import { DataTable } from '../../assets/js/components/table.js';
import { Validator } from '../../assets/js/utils/validator.js';

// --- RENDER FUNCTION ---
export async function renderSettings() {
    const container = document.getElementById('appContent');
    const user = store.getState().user;
    const userRole = store.getState().role;

    container.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:26px; flex-wrap:wrap; gap:16px; background:var(--bg-card); padding:22px 26px; border-radius:12px; border:1px solid var(--border-color); box-shadow:var(--shadow-sm);">
            <div>
                <h1 class="page-title">System Settings</h1>
                <p class="page-subtitle">Manage your profile, theme, and security preferences.</p>
            </div>
        </div>

        <div style="display:flex; gap:8px; margin-bottom:20px; border-bottom:1px solid var(--border-color); padding-bottom:12px;">
            <button class="settings-tab active" data-tab="general" style="padding:8px 16px; background:transparent; border:none; border-bottom:2px solid var(--primary-red); color:var(--primary-red); font-weight:500; cursor:pointer;">General</button>
            <button class="settings-tab" data-tab="profile" style="padding:8px 16px; background:transparent; border:none; color:var(--text-secondary); cursor:pointer;">Profile</button>
            <button class="settings-tab" data-tab="security" style="padding:8px 16px; background:transparent; border:none; color:var(--text-secondary); cursor:pointer;">Security</button>
            ${userRole === 'admin' ? `
                <button class="settings-tab" data-tab="users" style="padding:8px 16px; background:transparent; border:none; color:var(--text-secondary); cursor:pointer;">Users</button>
                <button class="settings-tab" data-tab="security-logs" style="padding:8px 16px; background:transparent; border:none; color:var(--text-secondary); cursor:pointer;">Security Logs</button>
            ` : ''}
        </div>

        <div id="settingsContent">
            ${renderGeneralTab(userRole)}
        </div>
    `;

    document.querySelectorAll('.settings-tab').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            document.querySelectorAll('.settings-tab').forEach(b => {
                b.style.borderBottom = 'none';
                b.style.color = 'var(--text-secondary)';
                b.classList.remove('active');
            });

            const target = e.target;
            target.style.borderBottom = '2px solid var(--primary-red)';
            target.style.color = 'var(--primary-red)';
            target.classList.add('active');

            const tab = target.dataset.tab;
            const contentContainer = document.getElementById('settingsContent');

            if (tab === 'general') {
                contentContainer.innerHTML = renderGeneralTab(userRole);
                attachGeneralEvents();
            } else if (tab === 'profile') {
                contentContainer.innerHTML = renderProfileTab(user);
                attachProfileEvents();
            } else if (tab === 'security') {
                contentContainer.innerHTML = renderSecurityTab();
                attachSecurityEvents();
            } else if (tab === 'users') {
                contentContainer.innerHTML = renderUsersTab();
                await loadUsers();
            } else if (tab === 'security-logs') {
                contentContainer.innerHTML = renderSecurityLogsTab();
                await loadSecurityLogs();
            }
        });
    });

    attachGeneralEvents();
}

// --- TAB RENDERERS ---

function renderGeneralTab(role) {
    const currentTheme = localStorage.getItem('theme') || 'light';
    return `
        <div class="card" style="padding:24px;">
            <h3 style="margin-bottom:16px;">Application Settings</h3>

            <div style="display:grid; gap:20px;">
                <div style="display:flex; justify-content:space-between; align-items:center; padding:16px; border:1px solid var(--border-color); border-radius:8px;">
                    <div>
                        <h4 style="font-size:1rem; margin-bottom:4px;">Dark Mode</h4>
                        <p style="color:var(--text-secondary); font-size:0.9rem;">Toggle the application theme between light and dark.</p>
                    </div>
                    <label style="position:relative; display:inline-block; width:50px; height:26px;">
                        <input type="checkbox" id="themeToggleSettings" ${currentTheme === 'dark' ? 'checked' : ''} style="opacity:0; width:0; height:0;">
                        <span style="position:absolute; cursor:pointer; top:0; left:0; right:0; bottom:0; background-color:${currentTheme === 'dark' ? '#B91C1C' : '#ccc'}; transition:.4s; border-radius:34px;"></span>
                        <span style="position:absolute; content:''; height:20px; width:20px; left:${currentTheme === 'dark' ? '26px' : '3px'}; bottom:3px; background-color:white; transition:.4s; border-radius:50%;"></span>
                    </label>
                </div>

                ${role === 'admin' ? `
                <div style="display:flex; justify-content:space-between; align-items:center; padding:16px; border:1px solid var(--border-color); border-radius:8px;">
                    <div>
                        <h4 style="font-size:1rem; margin-bottom:4px;">System Diagnostics</h4>
                        <p style="color:var(--text-secondary); font-size:0.9rem;">Reset demo operational data (products, suppliers, orders) back to the initial seed. User accounts are not affected.</p>
                    </div>
                    <button id="resetDatabaseBtn" style="background:#EF4444; color:white; border:none; padding:8px 16px; border-radius:6px; cursor:pointer; font-weight:500;">Reset Demo Data</button>
                </div>` : ''}
            </div>
        </div>
    `;
}

function renderProfileTab(user) {
    return `
        <div class="card" style="padding:24px;">
            <h3 style="margin-bottom:16px;">Profile Information</h3>

            <div style="display:grid; gap:20px; max-width:500px;">
                <div style="display:flex; align-items:center; gap:20px;">
                    <div style="width:80px; height:80px; border-radius:50%; overflow:hidden; border:2px solid var(--border-color); background:#E5E7EB; display:flex; align-items:center; justify-content:center; position:relative;">
                        <img id="settingsProfilePreview" src="${user.profilePicture || ''}" style="width:100%; height:100%; object-fit:cover; ${user.profilePicture ? '' : 'display:none;'}">
                        <span id="settingsProfilePlaceholder" style="font-size:32px; color:#6B7280; ${user.profilePicture ? 'display:none;' : ''}">${user.name ? user.name.charAt(0).toUpperCase() : 'U'}</span>
                    </div>
                    <div>
                        <button id="changeProfilePicBtn" style="background:var(--bg-gray); border:1px solid var(--border-color); padding:8px 16px; border-radius:6px; cursor:pointer; font-weight:500;">Change Photo</button>
                        <input type="file" id="settingsImageInput" accept="image/*" style="display:none;">
                    </div>
                </div>

                <div>
                    <label style="display:block; font-weight:500; margin-bottom:4px;">Display Name</label>
                    <input type="text" id="settingsNameInput" value="${user.name || ''}" class="form-input" style="max-width:300px;">
                </div>

                <div>
                    <label style="display:block; font-weight:500; margin-bottom:4px;">Role</label>
                    <input type="text" value="${user.role || 'staff'}" class="form-input" disabled style="max-width:300px; background:var(--bg-gray);">
                </div>

                <button id="saveProfileBtn" style="margin-top:8px; background:#B91C1C; color:white; padding:10px 20px; border:none; border-radius:6px; cursor:pointer; font-weight:500; max-width:150px;">Save Changes</button>
            </div>
        </div>
    `;
}

function renderSecurityTab() {
    return `
        <div class="card" style="padding:24px;">
            <h3 style="margin-bottom:16px;">Security & Access</h3>

            <div style="display:grid; gap:20px; max-width:500px;">
                <div style="padding:16px; border:1px solid var(--border-color); border-radius:8px;">
                    <h4 style="font-size:1rem; margin-bottom:4px;">🔒 Security Features Enabled</h4>
                    <ul style="color:var(--text-secondary); font-size:0.9rem; margin-top:8px; list-style:none; padding-left:0;">
                        <li style="margin-bottom:4px;">✓ Password hashing with bcrypt (server-side)</li>
                        <li style="margin-bottom:4px;">✓ PHP server-side sessions</li>
                        <li style="margin-bottom:4px;">✓ Brute force protection (5 attempts, 15 min lockout)</li>
                        <li style="margin-bottom:4px;">✓ Server-side input sanitization</li>
                        <li style="margin-bottom:4px;">✓ Security audit logging (MySQL)</li>
                    </ul>
                </div>

                <div style="padding:16px; border:1px solid var(--border-color); border-radius:8px;">
                    <h4 style="font-size:1rem; margin-bottom:4px;">Account Actions</h4>
                    <div style="display:flex; gap:12px; margin-top:8px; flex-wrap:wrap;">
                        <button id="changePasswordBtn" style="background:var(--bg-gray); border:1px solid var(--border-color); padding:8px 16px; border-radius:6px; cursor:pointer; font-weight:500;">Change Password</button>
                        <button id="logoutEverywhereBtn" style="background:#EF4444; color:white; border:none; padding:8px 16px; border-radius:6px; cursor:pointer; font-weight:500;">Logout</button>
                        ${store.getState().role === 'admin' ? `<button id="clearLoginAttemptsBtn" style="background:#F59E0B; color:white; border:none; padding:8px 16px; border-radius:6px; cursor:pointer; font-weight:500;">Clear Login Blocks</button>` : ''}
                    </div>
                </div>
            </div>
        </div>
    `;
}

function renderUsersTab() {
    return `
        <div class="card" style="padding:24px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:16px;">
                <div>
                    <h3 style="margin-bottom:4px;">User Accounts</h3>
                    <p style="color:var(--text-secondary); font-size:0.9rem;">Only administrators can create new user accounts. There is no public sign-up.</p>
                </div>
                <button id="addUserBtn" style="background:var(--primary-red); color:white; padding:10px 20px; border:none; border-radius:8px; font-weight:600; cursor:pointer; display:flex; align-items:center; gap:8px;">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>
                    Add User
                </button>
            </div>
            <div id="userTableContainer"></div>
        </div>
    `;
}

// --- EVENT ATTACHMENT FUNCTIONS ---

function attachGeneralEvents() {
    const themeSwitch = document.getElementById('themeToggleSettings');
    if (themeSwitch) {
        themeSwitch.addEventListener('change', () => {
            const isChecked = themeSwitch.checked;
            const nextTheme = isChecked ? 'dark' : 'light';
            document.documentElement.setAttribute('data-theme', nextTheme);
            localStorage.setItem('theme', nextTheme);
            toast.show(`Theme switched to ${nextTheme}.`, 'info');

            const sliderSpan = themeSwitch.nextElementSibling;
            const circleSpan = sliderSpan.nextElementSibling;
            if (isChecked) {
                sliderSpan.style.backgroundColor = '#B91C1C';
                circleSpan.style.left = '26px';
            } else {
                sliderSpan.style.backgroundColor = '#ccc';
                circleSpan.style.left = '3px';
            }
        });
    }

    const resetBtn = document.getElementById('resetDatabaseBtn');
    if (resetBtn) {
        resetBtn.addEventListener('click', async () => {
            if (!confirm('Reset all products, suppliers, orders, and inventory history back to the initial seed data? User accounts will not be affected.')) return;
            try {
                const res = await fetch('api/reset-demo-data.php', { method: 'POST' });
                const result = await res.json();
                if (!result.success) throw new Error(result.error || 'Reset failed.');
                toast.show('Demo data has been reset.', 'success');
            } catch (error) {
                toast.show(error.message || 'Failed to reset demo data.', 'error');
            }
        });
    }
}

function attachProfileEvents() {
    const user = store.getState().user;
    if (!user) return;

    const changePicBtn = document.getElementById('changeProfilePicBtn');
    const fileInput = document.getElementById('settingsImageInput');

    if (changePicBtn && fileInput) {
        changePicBtn.addEventListener('click', () => fileInput.click());

        fileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (ev) => {
                    const preview = document.getElementById('settingsProfilePreview');
                    const placeholder = document.getElementById('settingsProfilePlaceholder');
                    if (preview && placeholder) {
                        preview.src = ev.target.result;
                        preview.style.display = 'block';
                        placeholder.style.display = 'none';
                    }
                };
                reader.readAsDataURL(file);
            }
        });
    }

    const saveBtn = document.getElementById('saveProfileBtn');
    if (saveBtn) {
        saveBtn.addEventListener('click', async () => {
            const newName = document.getElementById('settingsNameInput').value.trim();
            const previewImg = document.getElementById('settingsProfilePreview');
            let newImage = null;

            if (previewImg.src && previewImg.src.startsWith('data:image')) {
                newImage = previewImg.src;
            }

            if (!newName) {
                toast.show('Name cannot be empty.', 'error');
                return;
            }

            try {
                const res = await fetch('api/profile.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name: newName, profilePicture: newImage })
                });
                const result = await res.json();
                if (!result.success) throw new Error(result.error || 'Update failed.');

                store.dispatch({ user: { ...user, name: newName, ...(newImage ? { profilePicture: newImage } : {}) } });
                toast.show('Profile updated successfully!', 'success');
            } catch (error) {
                toast.show(error.message || 'Failed to update profile.', 'error');
            }
        });
    }
}

function attachSecurityEvents() {
    const changePassBtn = document.getElementById('changePasswordBtn');
    if (changePassBtn) {
        changePassBtn.addEventListener('click', () => {
            const formHTML = `
                <form id="changePassForm" style="display:grid; gap:16px;">
                    <div>
                        <label style="display:block; font-weight:500; margin-bottom:4px;">Current Password *</label>
                        <input type="password" id="currentPassInput" class="form-input" required>
                    </div>
                    <div>
                        <label style="display:block; font-weight:500; margin-bottom:4px;">New Password *</label>
                        <input type="password" id="newPassInput" class="form-input" placeholder="Min. 8 characters" required>
                        <p style="font-size:0.8rem; color:var(--text-secondary); margin-top:4px;">Must include uppercase, lowercase, and a number.</p>
                    </div>
                    <div>
                        <label style="display:block; font-weight:500; margin-bottom:4px;">Confirm New Password *</label>
                        <input type="password" id="confirmPassInput" class="form-input" required>
                    </div>
                </form>
            `;

            modal.open('Change Password', formHTML, {
                confirmText: 'Update Password',
                onConfirm: async () => {
                    const currentPass = document.getElementById('currentPassInput').value.trim();
                    const newPass = document.getElementById('newPassInput').value.trim();
                    const confirmPass = document.getElementById('confirmPassInput').value.trim();

                    if (!Validator.password(newPass)) {
                        toast.show('Password must be 8+ chars, include uppercase, lowercase, and number.', 'error');
                        return false; // Prevent modal from closing
                    }
                    if (newPass !== confirmPass) {
                        toast.show('Passwords do not match.', 'error');
                        return false; // Prevent modal from closing
                    }

                    try {
                        const res = await fetch('api/change-password.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ currentPassword: currentPass, newPassword: newPass })
                        });
                        const result = await res.json();
                        if (!result.success) throw new Error(result.error || 'Update failed.');

                        toast.show('Password updated successfully! Please log in again.', 'success');
                        modal.close();
                        setTimeout(async () => {
                            await fetch('api/logout.php');
                            window.location.href = 'index.php';
                        }, 1500);
                        return true; // Allow modal to close
                    } catch (error) {
                        toast.show(error.message || 'Failed to update password.', 'error');
                        return false; // Prevent modal from closing on error
                    }
                }
            });
        });
    }

    const logoutEverywhereBtn = document.getElementById('logoutEverywhereBtn');
    if (logoutEverywhereBtn) {
        logoutEverywhereBtn.addEventListener('click', async () => {
            if (confirm('Log out of your account?')) {
                await fetch('api/logout.php');
                store.dispatch({ isAuthenticated: false, user: null, role: null });
                toast.show('Logged out.', 'info');
                setTimeout(() => window.location.href = 'index.php', 500);
            }
        });
    }

    const clearBlocksBtn = document.getElementById('clearLoginAttemptsBtn');
    if (clearBlocksBtn) {
        clearBlocksBtn.addEventListener('click', async () => {
            if (!confirm('Clear all login attempt tracking and unlock all accounts?')) return;
            try {
                const res = await fetch('api/clear-login-attempts.php', { method: 'POST' });
                const result = await res.json();
                if (!result.success) throw new Error(result.error || 'Failed.');
                toast.show(`Cleared ${result.cleared} login block(s).`, 'success');
            } catch (error) {
                toast.show(error.message || 'Failed to clear login blocks.', 'error');
            }
        });
    }
}

// --- USER MANAGEMENT (ADMIN ONLY) ---

let currentUsers = [];
let userTable = null;

async function loadUsers() {
    if (store.getState().role !== 'admin') return;

    try {
        const res = await fetch('api/users.php');
        console.log('Users API Response Status:', res.status);
        
        // Get response as text first, then try to parse as JSON
        const text = await res.text();
        console.log('Users API Response Text:', text);
        
        let result;
        try {
            result = JSON.parse(text);
        } catch (parseError) {
            console.error('Failed to parse JSON response:', parseError);
            console.error('Raw response:', text);
            throw new Error('Invalid response from server. Check browser console for details.');
        }
        
        console.log('Users API Response:', result);
        
        if (!result.success) {
            throw new Error(result.error || 'Failed to load users.');
        }
        
        currentUsers = result.data || [];
        renderUserTable();
        document.getElementById('addUserBtn')?.addEventListener('click', () => openUserForm());
    } catch (error) {
        console.error('Load users error:', error);
        toast.show(error.message || 'Failed to load user accounts.', 'error');
    }
}

function renderUserTable() {
    const container = document.getElementById('userTableContainer');
    if (!container) return;

    if (userTable && !document.body.contains(userTable.container)) {
        userTable = null;
    }

    const currentUserId = store.getState().user?.id;

    const columns = [
        { key: 'name', label: 'Full Name' },
        { key: 'username', label: 'Username' },
        { key: 'email', label: 'Email' },
        { key: 'role', label: 'Role' },
    ];

    const roleColors = { admin: '#B91C1C', manager: '#D97706', staff: '#3B82F6' };

    const formattedData = currentUsers.map(u => ({
        ...u,
        role: `<span style="background:${roleColors[u.role] || '#6B7280'}22; color:${roleColors[u.role] || '#6B7280'}; padding:4px 10px; border-radius:999px; font-size:0.8rem; font-weight:600; text-transform:capitalize;">${u.role}</span>`,
    }));

    if (!userTable) {
        userTable = new DataTable('userTableContainer', columns, formattedData, {
            actions: true,
            onEdit: (rowData) => openUserForm(currentUsers.find(u => u.id === rowData.id)),
            onDelete: (rowData) => {
                if (rowData.id === currentUserId) {
                    toast.show("You can't delete your own account while logged in.", 'error');
                    return;
                }
                confirmDeleteUser(currentUsers.find(u => u.id === rowData.id));
            }
        });
    } else {
        userTable.updateData(formattedData);
    }
}

// --- CRUD: USER FORM (ADD / EDIT) ---
function openUserForm(existingUser = null) {
    const isEdit = !!existingUser;
    const title = isEdit ? `Edit User: ${existingUser.name}` : 'Add New User';

    const formHTML = `
        <form id="userForm" style="display:grid; gap:16px;">
            <div>
                <label style="display:block; font-weight:500; margin-bottom:4px;">Full Name *</label>
                <input type="text" id="u_name" value="${isEdit ? existingUser.name : ''}" class="form-input" placeholder="e.g. Juan Dela Cruz" required>
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                <div>
                    <label style="display:block; font-weight:500; margin-bottom:4px;">Email Address *</label>
                    <input type="email" id="u_email" value="${isEdit ? existingUser.email : ''}" class="form-input" placeholder="name@ramyum.com" required>
                </div>
                <div>
                    <label style="display:block; font-weight:500; margin-bottom:4px;">Username *</label>
                    <input type="text" id="u_username" value="${isEdit ? existingUser.username : ''}" class="form-input" placeholder="Choose a username" required>
                </div>
            </div>

            <div>
                <label style="display:block; font-weight:500; margin-bottom:4px;">Role *</label>
                <select id="u_role" class="form-input">
                    <option value="staff" ${isEdit && existingUser.role === 'staff' ? 'selected' : ''}>Staff</option>
                    <option value="manager" ${isEdit && existingUser.role === 'manager' ? 'selected' : ''}>Manager</option>
                    <option value="admin" ${isEdit && existingUser.role === 'admin' ? 'selected' : ''}>Administrator</option>
                </select>
            </div>

            <div>
                <label style="display:block; font-weight:500; margin-bottom:4px;">${isEdit ? 'Reset Password (leave blank to keep current)' : 'Temporary Password *'}</label>
                <input type="password" id="u_password" class="form-input" placeholder="8+ chars, uppercase, lowercase, number" ${isEdit ? '' : 'required'}>
            </div>
        </form>
    `;

    modal.open(title, formHTML, {
        confirmText: isEdit ? 'Update User' : 'Add User',
        onConfirm: async () => {
            const name = document.getElementById('u_name').value.trim();
            const email = document.getElementById('u_email').value.trim();
            const username = document.getElementById('u_username').value.trim();
            const role = document.getElementById('u_role').value;
            const password = document.getElementById('u_password').value.trim();

            const rules = { name: 'required', email: 'required|email', username: 'required' };
            const validation = Validator.validateForm({ name, email, username }, rules);
            if (!validation.isValid) {
                toast.show(Object.values(validation.errors)[0], 'error');
                return false; // Prevent modal from closing
            }

            if (!isEdit && !Validator.password(password)) {
                toast.show('Password must be 8+ chars, include uppercase, lowercase, and number.', 'error');
                return false; // Prevent modal from closing
            }
            if (isEdit && password && !Validator.password(password)) {
                toast.show('Password must be 8+ chars, include uppercase, lowercase, and number.', 'error');
                return false; // Prevent modal from closing
            }

            const formData = { name, email, username, role };
            if (password) formData.password = password;

            try {
                if (isEdit) {
                    const res = await fetch(`api/users.php?id=${encodeURIComponent(existingUser.id)}`, {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(formData)
                    });
                    const result = await res.json();
                    if (!result.success) throw new Error(result.error || 'Update failed.');
                    toast.show('User account updated successfully!', 'success');
                } else {
                    const res = await fetch('api/users.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(formData)
                    });
                    const result = await res.json();
                    if (!result.success) throw new Error(result.error || 'Creation failed.');
                    toast.show('User account created successfully!', 'success');
                }
                modal.close();
                await loadUsers();
                return true; // Allow modal to close
            } catch (error) {
                toast.show(error.message || 'Failed to save user account.', 'error');
                console.error(error);
                return false; // Prevent modal from closing on error
            }
        }
    });
}

// --- CRUD: DELETE CONFIRMATION ---
function confirmDeleteUser(rowData) {
    modal.open(
        `Remove ${rowData.name}?`,
        `<p style="color:var(--text-secondary);">Are you sure you want to remove <strong>${rowData.name}</strong>'s account? They will no longer be able to log in.</p>`,
        {
            confirmText: 'Remove User',
            onConfirm: async () => {
                try {
                    const res = await fetch(`api/users.php?id=${encodeURIComponent(rowData.id)}`, { method: 'DELETE' });
                    const result = await res.json();
                    if (!result.success) throw new Error(result.error || 'Delete failed.');
                    toast.show('User account removed.', 'info');
                    modal.close();
                    await loadUsers();
                    return true; // Allow modal to close
                } catch (error) {
                    toast.show(error.message || 'Failed to remove user account.', 'error');
                    return false; // Prevent modal from closing on error
                }
            }
        }
    );
}

// --- SECURITY LOGS TAB (ADMIN ONLY) ---
function renderSecurityLogsTab() {
    return `
        <div class="card" style="padding:24px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:16px;">
                <div>
                    <h3 style="margin-bottom:4px;">Security Audit Logs</h3>
                    <p style="color:var(--text-secondary); font-size:0.9rem;">Monitor system security events and user activity (stored in MySQL).</p>
                </div>
            </div>

            <div style="margin-bottom:16px;">
                <input type="text" id="logSearch" placeholder="Search logs by event, user, or details..." class="form-input" style="max-width:400px;">
            </div>

            <div id="securityLogsContainer" style="max-height:600px; overflow-y:auto;">
                <!-- Logs will be rendered here -->
            </div>
        </div>
    `;
}

let currentLogs = [];

async function loadSecurityLogs() {
    try {
        const res = await fetch('api/security-logs.php');
        const result = await res.json();
        currentLogs = result.success ? result.data : [];
    } catch (error) {
        currentLogs = [];
    }

    renderSecurityLogs(currentLogs);

    document.getElementById('logSearch')?.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();
        const filtered = currentLogs.filter(log => {
            return log.event_type.toLowerCase().includes(searchTerm) ||
                   (log.username || '').toLowerCase().includes(searchTerm) ||
                   JSON.stringify(log.details || {}).toLowerCase().includes(searchTerm);
        });
        renderSecurityLogs(filtered);
    });
}

function renderSecurityLogs(logs) {
    const container = document.getElementById('securityLogsContainer');
    if (!container) return;

    if (logs.length === 0) {
        container.innerHTML = `
            <div style="text-align:center; padding:40px; color:var(--text-secondary);">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin:0 auto 12px; display:block; opacity:0.3;">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                </svg>
                <p>No security logs found.</p>
            </div>
        `;
        return;
    }

    const eventIcons = {
        'LOGIN_SUCCESS': '✅',
        'LOGIN_FAILED': '❌',
        'LOGIN_BLOCKED_LOCKOUT': '🔒',
        'LOGOUT': '👋',
        'PASSWORD_CHANGED': '🔑',
        'USER_CREATED': '➕',
        'USER_UPDATED': '✏️',
        'USER_DELETED': '🗑️',
    };

    const eventColors = {
        'LOGIN_SUCCESS': '#10B981',
        'LOGIN_FAILED': '#EF4444',
        'LOGIN_BLOCKED_LOCKOUT': '#F59E0B',
        'LOGOUT': '#6B7280',
        'PASSWORD_CHANGED': '#3B82F6',
    };

    container.innerHTML = logs.map(log => {
        const icon = eventIcons[log.event_type] || '📋';
        const color = eventColors[log.event_type] || '#6B7280';
        const formattedDate = new Date(log.created_at).toLocaleString();

        return `
            <div style="padding:12px; border-bottom:1px solid var(--border-color); display:flex; gap:12px; align-items:start;">
                <div style="font-size:24px; line-height:1;">${icon}</div>
                <div style="flex:1;">
                    <div style="display:flex; justify-content:space-between; align-items:start; margin-bottom:4px;">
                        <strong style="color:${color};">${log.event_type.replace(/_/g, ' ')}</strong>
                        <span style="color:var(--text-secondary); font-size:0.85rem;">${formattedDate}</span>
                    </div>
                    <p style="color:var(--text-secondary); font-size:0.9rem; margin:0;">
                        ${log.username ? `User: ${log.username}` : 'System'}${log.ip_address ? ` | IP: ${log.ip_address}` : ''}
                    </p>
                </div>
            </div>
        `;
    }).join('');
}
