<?php
/**
 * AUDIT STOCK TRANSFERS WORKFLOW
 * Review stock transfer records and transfer proof integration
 */

require_once 'config/database.php';

$db = getDB();

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "STOCK TRANSFER WORKFLOW AUDIT\n";
echo "═══════════════════════════════════════════════════════════════════════\n\n";

// Check stock_transfers table
echo "STOCK TRANSFERS:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$transfers = $db->query("SELECT id, data, created_at FROM stock_transfers ORDER BY created_at DESC")->fetchAll();

echo "Total transfers: " . count($transfers) . "\n\n";

if (count($transfers) > 0) {
    // Analyze by status
    $byStatus = [];
    $byType = [];
    $byLocation = [];
    
    foreach ($transfers as $transfer) {
        $data = json_decode($transfer['data'], true);
        
        $status = $data['status'] ?? 'unknown';
        $type = $data['type'] ?? 'unknown';
        $from = $data['fromLocation'] ?? 'unknown';
        $to = $data['toLocation'] ?? 'unknown';
        
        if (!isset($byStatus[$status])) $byStatus[$status] = 0;
        $byStatus[$status]++;
        
        if (!isset($byType[$type])) $byType[$type] = 0;
        $byType[$type]++;
        
        $locationKey = "{$from} → {$to}";
        if (!isset($byLocation[$locationKey])) $byLocation[$locationKey] = 0;
        $byLocation[$locationKey]++;
    }
    
    echo "BY STATUS:\n";
    foreach ($byStatus as $status => $count) {
        echo "  {$status}: {$count}\n";
    }
    
    echo "\nBY TYPE:\n";
    foreach ($byType as $type => $count) {
        echo "  {$type}: {$count}\n";
    }
    
    echo "\nBY ROUTE:\n";
    foreach ($byLocation as $route => $count) {
        echo "  {$route}: {$count} transfers\n";
    }
    
    echo "\n";
}

// Check transfer_proof table
echo "TRANSFER PROOF RECORDS:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$proofs = $db->query("SELECT COUNT(*) FROM transfer_proof")->fetchColumn();
echo "Total transfer proofs: {$proofs}\n";

if ($proofs > 0) {
    $proofRecords = $db->query("SELECT id, proof_number, status, created_at FROM transfer_proof ORDER BY created_at DESC")->fetchAll();
    
    $byStatus = [];
    foreach ($proofRecords as $proof) {
        $status = $proof['status'];
        if (!isset($byStatus[$status])) $byStatus[$status] = 0;
        $byStatus[$status]++;
    }
    
    echo "\nBY STATUS:\n";
    foreach ($byStatus as $status => $count) {
        echo "  {$status}: {$count}\n";
    }
}

echo "\n";

// Check transfer_proof_items table
echo "TRANSFER PROOF ITEMS:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$proofItems = $db->query("SELECT COUNT(*) FROM transfer_proof_items")->fetchColumn();
echo "Total proof items: {$proofItems}\n\n";

// Detailed transfer analysis
if (count($transfers) > 0) {
    echo "DETAILED TRANSFER RECORDS:\n";
    echo "───────────────────────────────────────────────────────────────────────\n\n";
    
    foreach ($transfers as $i => $transfer) {
        $data = json_decode($transfer['data'], true);
        
        echo "Transfer " . ($i + 1) . ": {$transfer['id']}\n";
        echo "  Number: {$data['transferNumber']}\n";
        echo "  Status: {$data['status']}\n";
        echo "  Type: {$data['type']}\n";
        echo "  From: {$data['fromLocation']}\n";
        echo "  To: {$data['toLocation']}\n";
        echo "  Items: " . (isset($data['items']) ? count($data['items']) : 0) . "\n";
        echo "  Created: {$transfer['created_at']}\n";
        echo "  Created By: {$data['createdBy']}\n";
        
        // Check if has transfer proof (normalized table, not JSON)
        $proofStmt = $db->prepare("
            SELECT id, proof_number, status FROM transfer_proof
            WHERE transfer_id = ?
        ");
        $proofStmt->execute([$transfer['id']]);
        $proof = $proofStmt->fetch();
        
        if ($proof) {
            echo "  Transfer Proof: {$proof['proof_number']} (Status: {$proof['status']})\n";
        } else {
            echo "  Transfer Proof: ✗ NOT FOUND\n";
        }
        
        // Check inventory movements
        $movementStmt = $db->prepare("
            SELECT COUNT(*) FROM inventory_movements
            WHERE JSON_EXTRACT(data, '$.referenceId') = ?
        ");
        $movementStmt->execute([$data['transferNumber']]);
        $movCount = $movementStmt->fetchColumn();
        
        echo "  Inventory Movements: {$movCount}\n";
        
        // Show items
        if (isset($data['items']) && count($data['items']) > 0) {
            echo "  Transfer Items:\n";
            foreach ($data['items'] as $item) {
                echo "    - {$item['productName']}: {$item['quantity']} {$item['unit']}\n";
            }
        }
        
        echo "\n";
    }
}

// Check for orphaned transfer proofs
echo "ORPHANED TRANSFER PROOFS:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

if ($proofs > 0) {
    $orphanedStmt = $db->query("
        SELECT tp.id, tp.transfer_id, tp.proof_number
        FROM transfer_proof tp
        LEFT JOIN stock_transfers st ON tp.transfer_id = st.id
        WHERE st.id IS NULL
    ");
    $orphaned = $orphanedStmt->fetchAll();
    
    echo "Orphaned proofs: " . count($orphaned) . "\n";
    
    if (count($orphaned) > 0) {
        foreach ($orphaned as $orph) {
            echo "  - {$orph['proof_number']}: Transfer ID {$orph['transfer_id']} (not found)\n";
        }
    }
} else {
    echo "No transfer proofs to check\n";
}

echo "\n";

// Workflow connection analysis
echo "WORKFLOW CONNECTION ANALYSIS:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$totalTransfers = count($transfers);
$transfersWithProof = 0;
$transfersWithMovements = 0;
$completedTransfers = 0;

foreach ($transfers as $transfer) {
    $data = json_decode($transfer['data'], true);
    
    // Check proof (normalized table)
    $proofStmt = $db->prepare("
        SELECT COUNT(*) FROM transfer_proof
        WHERE transfer_id = ?
    ");
    $proofStmt->execute([$transfer['id']]);
    if ($proofStmt->fetchColumn() > 0) {
        $transfersWithProof++;
    }
    
    // Check movements
    $movementStmt = $db->prepare("
        SELECT COUNT(*) FROM inventory_movements
        WHERE JSON_EXTRACT(data, '$.referenceId') = ?
    ");
    $movementStmt->execute([$data['transferNumber']]);
    if ($movementStmt->fetchColumn() > 0) {
        $transfersWithMovements++;
    }
    
    if ($data['status'] === 'Completed' || $data['status'] === 'Delivered') {
        $completedTransfers++;
    }
}

echo "Total transfers: {$totalTransfers}\n";
echo "Transfers with proof: {$transfersWithProof}/{$totalTransfers}\n";
echo "Transfers with inventory movements: {$transfersWithMovements}/{$totalTransfers}\n";
echo "Completed/Delivered transfers: {$completedTransfers}/{$totalTransfers}\n";

echo "\n";

// Check locations table
echo "LOCATIONS SETUP:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$locations = $db->query("SELECT id, data FROM locations ORDER BY id")->fetchAll();
echo "Total locations: " . count($locations) . "\n\n";

if (count($locations) > 0) {
    foreach ($locations as $loc) {
        $data = json_decode($loc['data'], true);
        echo "  {$data['code']}: {$data['name']} ({$data['type']})\n";
    }
}

echo "\n";

// Summary
echo "═══════════════════════════════════════════════════════════════════════\n";
echo "AUDIT SUMMARY\n";
echo "═══════════════════════════════════════════════════════════════════════\n";

echo "Stock Transfers: {$totalTransfers}\n";
echo "Transfer Proofs: {$proofs}\n";
echo "Transfer Proof Items: {$proofItems}\n";
echo "Locations: " . count($locations) . "\n";

echo "\nWORKFLOW STATUS:\n";

if ($totalTransfers > 0 && $transfersWithProof < $totalTransfers) {
    echo "⚠ WARNING: " . ($totalTransfers - $transfersWithProof) . " transfers missing proof\n";
}

if ($transfersWithMovements < $totalTransfers) {
    echo "⚠ WARNING: " . ($totalTransfers - $transfersWithMovements) . " transfers missing inventory movements\n";
}

if ($totalTransfers === 0) {
    echo "ℹ INFO: No stock transfers in system\n";
} elseif ($transfersWithProof === $totalTransfers && $transfersWithMovements === $totalTransfers) {
    echo "✅ GOOD: All transfers have proof and inventory movements\n";
}

echo "\n";
echo "═══════════════════════════════════════════════════════════════════════\n";
echo "AUDIT COMPLETE\n";
echo "═══════════════════════════════════════════════════════════════════════\n";
