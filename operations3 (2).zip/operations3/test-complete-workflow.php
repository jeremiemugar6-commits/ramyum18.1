<?php
/**
 * Complete Workflow Test: PO → Receiving → POR → Inventory
 * Tests the entire supply chain workflow end-to-end
 */

require_once 'config/database.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

echo "=== RAM-YUM COMPLETE WORKFLOW TEST ===\n";
echo "Testing: Purchase Order → Receiving → Proof of Receiving → Inventory Update\n\n";

$db = getDB();
$passed = [];
$failed = [];
$testData = [];

// Simulate admin user for testing
$_SESSION['user_id'] = 'admin_test';
$_SESSION['username'] = 'admin';
$_SESSION['role'] = 'admin';

try {
    // ============================================
    // STEP 1: Verify Products Exist
    // ============================================
    echo "STEP 1: Checking Products...\n";
    $stmt = $db->query("SELECT COUNT(*) as count FROM products");
    $productCount = $stmt->fetch()['count'];
    
    if ($productCount > 0) {
        $passed[] = "✓ Products exist ($productCount products)";
        
        // Get a sample product
        $stmt = $db->query("SELECT * FROM products LIMIT 1");
        $productRow = $stmt->fetch();
        $product = json_decode($productRow['data'], true);
        $testData['product'] = $product;
        $testData['initialStock'] = floatval($product['stock'] ?? 0);
        
        $passed[] = "  - Sample product: {$product['productName']} (Stock: {$testData['initialStock']})";
    } else {
        $failed[] = "✗ No products found in database";
        throw new Exception("Cannot continue without products");
    }

    // ============================================
    // STEP 2: Verify Suppliers Exist
    // ============================================
    echo "\nSTEP 2: Checking Suppliers...\n";
    $stmt = $db->query("SELECT COUNT(*) as count FROM suppliers");
    $supplierCount = $stmt->fetch()['count'];
    
    if ($supplierCount > 0) {
        $passed[] = "✓ Suppliers exist ($supplierCount suppliers)";
        
        // Get a sample supplier
        $stmt = $db->query("SELECT * FROM suppliers LIMIT 1");
        $supplierRow = $stmt->fetch();
        $supplier = json_decode($supplierRow['data'], true);
        $testData['supplier'] = $supplier;
        
        $passed[] = "  - Sample supplier: {$supplier['company']}";
    } else {
        $failed[] = "✗ No suppliers found in database";
        throw new Exception("Cannot continue without suppliers");
    }

    // ============================================
    // STEP 3: Check Purchase Orders
    // ============================================
    echo "\nSTEP 3: Checking Purchase Orders...\n";
    $stmt = $db->query("
        SELECT * FROM purchase_orders 
        ORDER BY 
            CASE JSON_UNQUOTE(JSON_EXTRACT(data, '$.status'))
                WHEN 'Pending' THEN 1
                WHEN 'Approved' THEN 2
                ELSE 3
            END ASC,
            created_at DESC
        LIMIT 1
    ");
    $poRow = $stmt->fetch();
    
    if ($poRow) {
        $po = json_decode($poRow['data'], true);
        $testData['po'] = $po;
        $passed[] = "✓ Purchase orders exist";
        $passed[] = "  - PO#: {$po['poNumber']} | Status: {$po['status']} | Total: ₱{$po['total']}";
        
        // Count different statuses
        $stmt = $db->query("SELECT data FROM purchase_orders");
        $allPOs = $stmt->fetchAll();
        $statusCount = ['Pending' => 0, 'Approved' => 0, 'Received' => 0, 'Draft' => 0];
        foreach ($allPOs as $row) {
            $poData = json_decode($row['data'], true);
            $status = $poData['status'] ?? 'Unknown';
            if (isset($statusCount[$status])) {
                $statusCount[$status]++;
            }
        }
        $passed[] = "  - Status breakdown: Pending({$statusCount['Pending']}), Approved({$statusCount['Approved']}), Received({$statusCount['Received']}), Draft({$statusCount['Draft']})";
    } else {
        $failed[] = "✗ No purchase orders found";
    }

    // ============================================
    // STEP 4: Check Receiving Records
    // ============================================
    echo "\nSTEP 4: Checking Receiving Records...\n";
    $stmt = $db->query("SELECT * FROM receivings ORDER BY created_at DESC LIMIT 1");
    $receivingRow = $stmt->fetch();
    
    if ($receivingRow) {
        $receiving = json_decode($receivingRow['data'], true);
        $testData['receiving'] = $receiving;
        $passed[] = "✓ Receiving records exist";
        $passed[] = "  - GR#: {$receiving['receivingNumber']} | PO#: {$receiving['poNumber']} | Status: {$receiving['status']}";
        $passed[] = "  - Supplier: {$receiving['supplier']} | Total: ₱{$receiving['totalValue']}";
        
        // Count receivings
        $stmt = $db->query("SELECT COUNT(*) as count FROM receivings");
        $recCount = $stmt->fetch()['count'];
        $passed[] = "  - Total receiving records: $recCount";
    } else {
        $failed[] = "✗ No receiving records found";
    }

    // ============================================
    // STEP 5: Check Proof of Receiving (POR)
    // ============================================
    echo "\nSTEP 5: Checking Proof of Receiving (POR)...\n";
    $stmt = $db->query("
        SELECT * FROM proof_of_receiving 
        ORDER BY 
            CASE inspection_status
                WHEN 'Pending Inspection' THEN 1
                WHEN 'Pending' THEN 1
                WHEN 'Passed' THEN 2
                ELSE 3
            END ASC,
            created_at DESC
        LIMIT 1
    ");
    $porRow = $stmt->fetch();
    
    if ($porRow) {
        $testData['por'] = $porRow;
        $passed[] = "✓ Proof of Receiving records exist";
        $passed[] = "  - POR#: {$porRow['por_number']} | PO#: {$porRow['po_number']} | Status: {$porRow['inspection_status']}";
        $passed[] = "  - Accepted: {$porRow['total_accepted']} | Rejected: {$porRow['total_rejected']} | Value: ₱{$porRow['total_value']}";
        
        // Count POR records
        $stmt = $db->query("SELECT COUNT(*) as count FROM proof_of_receiving");
        $porCount = $stmt->fetch()['count'];
        $passed[] = "  - Total POR records: $porCount";
        
        // Check POR items
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM proof_of_receiving_items WHERE por_id = ?");
        $stmt->execute([$porRow['id']]);
        $itemCount = $stmt->fetch()['count'];
        $passed[] = "  - POR items: $itemCount";
    } else {
        $failed[] = "✗ No Proof of Receiving records found";
    }

    // ============================================
    // STEP 6: Check Inventory Movements
    // ============================================
    echo "\nSTEP 6: Checking Inventory Movements...\n";
    $stmt = $db->query("SELECT * FROM inventory_movements ORDER BY created_at DESC LIMIT 5");
    $movements = $stmt->fetchAll();
    
    if (count($movements) > 0) {
        $passed[] = "✓ Inventory movements exist (" . count($movements) . " recent movements)";
        
        foreach (array_slice($movements, 0, 3) as $movement) {
            $movementData = json_decode($movement['data'], true);
            $type = $movementData['type'] ?? 'Unknown';
            $product = $movementData['productName'] ?? 'Unknown';
            $qty = $movementData['quantity'] ?? 0;
            $passed[] = "  - $type: $product (Qty: $qty)";
        }
        
        // Count total movements
        $stmt = $db->query("SELECT COUNT(*) as count FROM inventory_movements");
        $totalMovements = $stmt->fetch()['count'];
        $passed[] = "  - Total inventory movements: $totalMovements";
    } else {
        $failed[] = "✗ No inventory movements found";
    }

    // ============================================
    // STEP 7: Verify Workflow Connections
    // ============================================
    echo "\nSTEP 7: Verifying Workflow Connections...\n";
    
    // Check if there are PORs linked to receivings
    $stmt = $db->query("
        SELECT COUNT(*) as count 
        FROM proof_of_receiving 
        WHERE receiving_id IS NOT NULL
    ");
    $linkedPORs = $stmt->fetch()['count'];
    
    if ($linkedPORs > 0) {
        $passed[] = "✓ POR records linked to receiving records ($linkedPORs linked)";
    } else {
        $passed[] = "ℹ No POR records linked to receiving records (manual POR creation)";
    }
    
    // Check if PORs have inventory updates
    $stmt = $db->query("
        SELECT COUNT(*) as count 
        FROM proof_of_receiving 
        WHERE inventory_updated = 1
    ");
    $updatedInventory = $stmt->fetch()['count'];
    
    if ($updatedInventory > 0) {
        $passed[] = "✓ POR records that updated inventory: $updatedInventory";
    } else {
        $passed[] = "ℹ No POR records have updated inventory yet";
    }

    // ============================================
    // STEP 8: Check Available Receivings for POR
    // ============================================
    echo "\nSTEP 8: Checking Available Receivings for POR Creation...\n";
    $stmt = $db->query("
        SELECT r.*
        FROM receivings r
        LEFT JOIN proof_of_receiving por ON por.receiving_id = r.id
        WHERE por.id IS NULL
        ORDER BY r.created_at DESC
    ");
    $availableReceivings = $stmt->fetchAll();
    
    $approvedCount = 0;
    foreach ($availableReceivings as $r) {
        $data = json_decode($r['data'] ?? '{}', true);
        $status = $data['status'] ?? '';
        if ($status === 'Approved' || $status === 'Completed') {
            $approvedCount++;
        }
    }
    
    if ($approvedCount > 0) {
        $passed[] = "✓ Available receivings ready for POR creation: $approvedCount";
    } else {
        $passed[] = "ℹ No receivings available for POR creation (all have PORs)";
    }

    // ============================================
    // STEP 9: Check Stock Transfer System
    // ============================================
    echo "\nSTEP 9: Checking Stock Transfer System...\n";
    $stmt = $db->query("SELECT COUNT(*) as count FROM stock_transfers");
    $transferCount = $stmt->fetch()['count'];
    
    if ($transferCount > 0) {
        $passed[] = "✓ Stock transfer records exist ($transferCount transfers)";
        
        // Get sample transfer
        $stmt = $db->query("SELECT * FROM stock_transfers ORDER BY created_at DESC LIMIT 1");
        $transferRow = $stmt->fetch();
        $transfer = json_decode($transferRow['data'], true);
        $passed[] = "  - Latest: {$transfer['transferNumber']} | Status: {$transfer['status']}";
    } else {
        $passed[] = "ℹ No stock transfers yet";
    }

    // ============================================
    // STEP 10: Check Locations
    // ============================================
    echo "\nSTEP 10: Checking Locations...\n";
    $stmt = $db->query("SELECT COUNT(*) as count FROM locations");
    $locationCount = $stmt->fetch()['count'];
    
    if ($locationCount > 0) {
        $passed[] = "✓ Locations exist ($locationCount locations)";
        
        $stmt = $db->query("SELECT * FROM locations LIMIT 3");
        $locations = $stmt->fetchAll();
        foreach ($locations as $loc) {
            $locData = json_decode($loc['data'], true);
            $passed[] = "  - {$locData['name']} ({$locData['type']})";
        }
    } else {
        $failed[] = "✗ No locations found";
    }

} catch (Exception $e) {
    $failed[] = "✗ Workflow test error: " . $e->getMessage();
}

// ============================================
// OUTPUT RESULTS
// ============================================
echo "\n";
echo "===========================================\n";
echo "           TEST RESULTS SUMMARY            \n";
echo "===========================================\n\n";

echo "PASSED (" . count($passed) . "):\n";
foreach ($passed as $p) {
    echo "$p\n";
}

if (!empty($failed)) {
    echo "\nFAILED (" . count($failed) . "):\n";
    foreach ($failed as $f) {
        echo "$f\n";
    }
    echo "\n❌ Some workflow tests failed!\n";
} else {
    echo "\n✅ Complete workflow verified successfully!\n";
}

echo "\n===========================================\n";
echo "         WORKFLOW STATUS: ";
echo empty($failed) ? "READY ✓" : "NEEDS ATTENTION ⚠";
echo "\n===========================================\n";
