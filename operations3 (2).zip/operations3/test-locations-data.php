<?php
/**
 * Quick test to verify locations data is available
 */

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';

$currentUser = require_login_page();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Locations Data</title>
    <link rel="stylesheet" href="assets/css/main.css">
    <style>
        body { font-family: system-ui, sans-serif; margin: 40px; }
        .container { max-width: 800px; margin: 0 auto; }
        .status { padding: 16px; border-radius: 8px; margin: 16px 0; }
        .success { background: #d1fae5; border: 1px solid #10b981; color: #065f46; }
        .error { background: #fee2e2; border: 1px solid #ef4444; color: #991b1b; }
        .warning { background: #fef3c7; border: 1px solid #f59e0b; color: #92400e; }
        .location-card {
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 16px;
            margin: 12px 0;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        .btn {
            background: #3b82f6;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 6px;
            cursor: pointer;
            margin: 8px 4px;
        }
        .btn:hover { background: #2563eb; }
        pre { background: #f9fafb; padding: 16px; border-radius: 8px; overflow-x: auto; }
        .debug { font-size: 12px; color: #6b7280; margin-top: 8px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🧪 Locations Data Test</h1>
        <p>This page tests if the locations data is properly available for the Stock Transfer module.</p>

        <div id="testResults">
            <div class="status warning">
                <strong>Testing...</strong> Checking locations data availability.
            </div>
        </div>

        <h3>Actions</h3>
        <button class="btn" onclick="testApiCall()">🔍 Test API Call</button>
        <button class="btn" onclick="testDatabaseDirect()">🗄️ Test Database Direct</button>
        <button class="btn" onclick="location.href='setup-stock-transfer-db.php'">🛠️ Setup Database</button>
        <button class="btn" onclick="location.href='dashboard.php'">📊 Back to Dashboard</button>

        <h3>Test Results</h3>
        <div id="apiResults"></div>
        <div id="dbResults"></div>

        <h3>Debug Information</h3>
        <div id="debugInfo"></div>
    </div>

    <script>
        async function testApiCall() {
            const resultsDiv = document.getElementById('apiResults');
            resultsDiv.innerHTML = '<div class="status warning">Testing API call...</div>';

            try {
                const response = await fetch('api/stock-transfers.php?action=locations');
                const data = await response.json();

                console.log('API Response:', data);

                if (data.success && data.data && data.data.length > 0) {
                    let html = '<div class="status success"><strong>✅ API Test Passed!</strong> Found ' + data.data.length + ' locations.</div>';
                    
                    data.data.forEach(location => {
                        html += `
                            <div class="location-card">
                                <strong>${location.name || 'Unnamed Location'}</strong> (ID: ${location.id})<br>
                                <small>Type: ${location.type || 'Unknown'} | Status: ${location.status || 'Unknown'}</small>
                                ${location.address ? '<br><small>Address: ' + location.address + '</small>' : ''}
                            </div>
                        `;
                    });

                    html += '<pre>' + JSON.stringify(data, null, 2) + '</pre>';
                    resultsDiv.innerHTML = html;
                } else if (data.success && data.data && data.data.length === 0) {
                    resultsDiv.innerHTML = '<div class="status warning"><strong>⚠️ No Locations Found!</strong> The API works but returned no locations. Database may need setup.</div>';
                } else {
                    resultsDiv.innerHTML = '<div class="status error"><strong>❌ API Error!</strong> ' + (data.error || 'Unknown error') + '</div>';
                }
            } catch (error) {
                console.error('API Test Error:', error);
                resultsDiv.innerHTML = '<div class="status error"><strong>❌ API Test Failed!</strong> ' + error.message + '</div>';
            }
        }

        async function testDatabaseDirect() {
            const resultsDiv = document.getElementById('dbResults');
            resultsDiv.innerHTML = '<div class="status warning">Testing database directly...</div>';

            try {
                const response = await fetch('test-locations-data.php?action=direct-db-test', {
                    method: 'POST'
                });
                const result = await response.text();
                resultsDiv.innerHTML = '<div class="status success"><strong>Database Test Results:</strong></div><pre>' + result + '</pre>';
            } catch (error) {
                resultsDiv.innerHTML = '<div class="status error"><strong>❌ Database Test Failed!</strong> ' + error.message + '</div>';
            }
        }

        // Auto-run API test on load
        document.addEventListener('DOMContentLoaded', () => {
            testApiCall();
            
            // Add debug info
            document.getElementById('debugInfo').innerHTML = `
                <div class="debug">
                    <strong>Current User:</strong> <?php echo htmlspecialchars($currentUser['username'] ?? 'Unknown'); ?> (Role: <?php echo htmlspecialchars($currentUser['role'] ?? 'Unknown'); ?>)<br>
                    <strong>Timestamp:</strong> <?php echo date('Y-m-d H:i:s'); ?><br>
                    <strong>PHP Version:</strong> <?php echo PHP_VERSION; ?><br>
                    <strong>Database:</strong> <?php echo isset($dbName) ? $dbName : 'ram_yum_inventory'; ?>
                </div>
            `;
        });
    </script>

    <?php
    // Handle direct database test
    if (isset($_POST) && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['action']) && $_GET['action'] === 'direct-db-test') {
        try {
            $db = getDB();
            
            echo "=== DIRECT DATABASE TEST ===\n";
            
            // Check if locations table exists
            $stmt = $db->query("SHOW TABLES LIKE 'locations'");
            $tableExists = $stmt->fetch();
            
            if ($tableExists) {
                echo "✅ Locations table exists\n";
                
                // Get all locations
                $stmt = $db->query("SELECT id, data FROM locations");
                $locations = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                echo "📊 Found " . count($locations) . " location records\n\n";
                
                foreach ($locations as $loc) {
                    $data = json_decode($loc['data'], true);
                    echo "Location ID: " . $loc['id'] . "\n";
                    echo "Name: " . ($data['name'] ?? 'Unknown') . "\n";
                    echo "Status: " . ($data['status'] ?? 'Unknown') . "\n";
                    echo "Data: " . substr(json_encode($data), 0, 100) . "...\n\n";
                }
            } else {
                echo "❌ Locations table does not exist!\n";
                echo "Run setup-stock-transfer-db.php to create the table.\n";
            }
            
        } catch (Exception $e) {
            echo "❌ Database Error: " . $e->getMessage() . "\n";
        }
        exit;
    }
    ?>
</body>
</html>