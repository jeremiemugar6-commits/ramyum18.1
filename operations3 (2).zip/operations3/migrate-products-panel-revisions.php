<?php
/**
 * RAM-YUM Panel Revisions - Product Data Migration
 * 
 * This script migrates existing product data to include the new fields
 * required by the panel revisions:
 * - unit (default: "Pack")
 * - costingPrice (migrated from existing 'price' field)
 * - srp (calculated as costingPrice * 1.15 for demo purposes)
 * - minimumStock (default: based on reorderLevel)
 * - maximumStock (default: reorderLevel * 5)
 */

require_once __DIR__ . '/config/database.php';

echo "=============================================================\n";
echo "RAM-YUM PANEL REVISIONS - PRODUCT DATA MIGRATION\n";
echo "=============================================================\n\n";

try {
    // Get database connection
    $pdo = getDBConnection();
    
    echo "✓ Database connection established\n\n";
    
    // First, create the new tables
    echo "Step 1: Creating new database tables...\n";
    $sqlFile = file_get_contents(__DIR__ . '/database/panel-revisions-migration.sql');
    
    // Split by semicolon and execute each statement
    $statements = array_filter(array_map('trim', explode(';', $sqlFile)));
    foreach ($statements as $statement) {
        if (empty($statement) || strpos($statement, '--') === 0) continue;
        if (strpos($statement, 'CREATE TABLE') !== false) {
            try {
                $pdo->exec($statement);
            } catch (PDOException $e) {
                // Table might already exist, that's okay
                if (strpos($e->getMessage(), 'already exists') === false) {
                    throw $e;
                }
            }
        }
    }
    echo "✓ Database tables created/verified\n\n";
    
    // Step 2: Fetch all products
    echo "Step 2: Fetching existing products...\n";
    $stmt = $pdo->query("SELECT id, data FROM products");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "✓ Found " . count($products) . " products\n\n";
    
    // Step 3: Migrate each product
    echo "Step 3: Migrating product data...\n";
    $updateStmt = $pdo->prepare("UPDATE products SET data = :data, updated_at = NOW() WHERE id = :id");
    
    $migrated = 0;
    $skipped = 0;
    
    foreach ($products as $product) {
        $data = json_decode($product['data'], true);
        
        if (!$data) {
            echo "  ⚠ Skipped product {$product['id']}: Invalid JSON\n";
            $skipped++;
            continue;
        }
        
        $needsUpdate = false;
        
        // Add 'unit' field if missing
        if (!isset($data['unit'])) {
            $data['unit'] = 'Pack'; // Default unit
            $needsUpdate = true;
        }
        
        // Migrate 'price' to 'costingPrice' and add 'srp'
        if (isset($data['price']) && !isset($data['costingPrice'])) {
            $data['costingPrice'] = $data['price'];
            $needsUpdate = true;
        }
        
        if (!isset($data['srp'])) {
            // Calculate SRP as costingPrice + 15% markup (for demo)
            $costingPrice = $data['costingPrice'] ?? $data['price'] ?? 0;
            $data['srp'] = round($costingPrice * 1.15, 2);
            $needsUpdate = true;
        }
        
        // Add minimumStock if missing
        if (!isset($data['minimumStock'])) {
            // Use reorderLevel as basis, or default to 10
            $data['minimumStock'] = $data['reorderLevel'] ?? 10;
            $needsUpdate = true;
        }
        
        // Add maximumStock if missing
        if (!isset($data['maximumStock'])) {
            // Set maximum as 5x minimum stock
            $minStock = $data['minimumStock'] ?? 10;
            $data['maximumStock'] = $minStock * 5;
            $needsUpdate = true;
        }
        
        // Update lastUpdated timestamp
        if ($needsUpdate) {
            $data['lastUpdated'] = date('Y-m-d\TH:i:s.000\Z');
            
            // Execute update
            $updateStmt->execute([
                'id' => $product['id'],
                'data' => json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
            ]);
            
            $migrated++;
            echo "  ✓ Migrated product: {$data['name']} ({$product['id']})\n";
        } else {
            $skipped++;
        }
    }
    
    echo "\n";
    echo "=============================================================\n";
    echo "MIGRATION SUMMARY\n";
    echo "=============================================================\n";
    echo "Total products: " . count($products) . "\n";
    echo "Migrated: {$migrated}\n";
    echo "Skipped (already up-to-date): {$skipped}\n";
    echo "\n";
    
    // Step 4: Create uploads directories
    echo "Step 4: Creating upload directories...\n";
    $uploadDirs = [
        __DIR__ . '/uploads',
        __DIR__ . '/uploads/damage-evidence',
        __DIR__ . '/uploads/product-images'
    ];
    
    foreach ($uploadDirs as $dir) {
        if (!is_dir($dir)) {
            if (mkdir($dir, 0755, true)) {
                echo "  ✓ Created directory: {$dir}\n";
            } else {
                echo "  ⚠ Could not create directory: {$dir}\n";
            }
        } else {
            echo "  ✓ Directory exists: {$dir}\n";
        }
    }
    
    // Create .htaccess for uploads directory
    $htaccessContent = "# Prevent PHP execution in uploads directory\n";
    $htaccessContent .= "php_flag engine off\n";
    $htaccessContent .= "AddType text/plain .php .php3 .php4 .php5 .phtml\n";
    $htaccessContent .= "\n# Allow image files\n";
    $htaccessContent .= "<FilesMatch \"\\.(jpg|jpeg|png|gif|webp)$\">\n";
    $htaccessContent .= "    Allow from all\n";
    $htaccessContent .= "</FilesMatch>\n";
    
    file_put_contents(__DIR__ . '/uploads/.htaccess', $htaccessContent);
    echo "  ✓ Created .htaccess for uploads security\n";
    
    echo "\n";
    echo "=============================================================\n";
    echo "✓ MIGRATION COMPLETED SUCCESSFULLY\n";
    echo "=============================================================\n";
    echo "\n";
    echo "Next steps:\n";
    echo "1. Verify product data in the application\n";
    echo "2. Test product catalog with new fields\n";
    echo "3. Test purchase orders with units displayed\n";
    echo "4. Test receiving with damage evidence upload\n";
    echo "\n";
    
} catch (Exception $e) {
    echo "\n";
    echo "=============================================================\n";
    echo "✗ MIGRATION FAILED\n";
    echo "=============================================================\n";
    echo "Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
    echo "\n";
    exit(1);
}
