<?php
require_once __DIR__ . '/includes/auth.php';
$currentUser = require_login_page();
$podId = $_GET['id'] ?? '';
$transferId = $_GET['transferId'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proof of Delivery - RAM-YUM</title>
    <link rel="stylesheet" href="assets/css/main.css">
    <style>
        .pod-container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 24px;
        }
        
        .pod-header {
            background: var(--bg-primary);
            border-radius: 12px;
            padding: 32px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            margin-bottom: 24px;
            text-align: center;
        }
        
        .pod-header h1 {
            font-size: 32px;
            color: var(--text-primary);
            margin-bottom: 8px;
        }
        
        .pod-status {
            display: inline-block;
            padding: 8px 24px;
            border-radius: 20px;
            font-size: 16px;
            font-weight: 600;
            margin-top: 16px;
        }
        
        .status-received {
            background: #d4edda;
            color: #155724;
        }
        
        .status-pending {
            background: #fff3cd;
            color: #856404;
        }
        
        .pod-info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 24px;
            margin-bottom: 32px;
        }
        
        .info-card {
            background: var(--bg-primary);
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        
        .info-card h3 {
            font-size: 14px;
            color: var(--text-secondary);
            text-transform: uppercase;
            font-weight: 600;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .info-item {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid var(--border-color);
        }
        
        .info-item:last-child {
            border-bottom: none;
        }
        
        .info-label {
            font-size: 14px;
            color: var(--text-secondary);
            font-weight: 500;
        }
        
        .info-value {
            font-size: 14px;
            color: var(--text-primary);
            font-weight: 600;
            text-align: right;
        }
        
        .items-section {
            background: var(--bg-primary);
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 24px;
        }
        
        .items-section h2 {
            font-size: 20px;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 16px;
        }
        
        .items-table th {
            background: var(--bg-secondary);
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: var(--text-secondary);
            font-size: 12px;
            text-transform: uppercase;
            border-bottom: 2px solid var(--border-color);
        }
        
        .items-table td {
            padding: 16px 12px;
            border-bottom: 1px solid var(--border-color);
        }
        
        .items-table tr:last-child td {
            border-bottom: none;
        }
        
        .condition-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .condition-good {
            background: #d4edda;
            color: #155724;
        }
        
        .condition-damaged {
            background: #f8d7da;
            color: #721c24;
        }
        
        .condition-missing {
            background: #fff3cd;
            color: #856404;
        }
        
        .condition-incorrect {
            background: #e2e3e5;
            color: #383d41;
        }
        
        .photos-section {
            background: var(--bg-primary);
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 24px;
        }
        
        .photos-section h2 {
            font-size: 20px;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .photos-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 16px;
            margin-top: 16px;
        }
        
        .photo-card {
            border-radius: 8px;
            overflow: hidden;
            border: 1px solid var(--border-color);
            cursor: pointer;
            transition: transform 0.2s;
        }
        
        .photo-card:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        
        .photo-card img {
            width: 100%;
            aspect-ratio: 1;
            object-fit: cover;
        }
        
        .photo-caption {
            padding: 8px;
            background: var(--bg-secondary);
            font-size: 12px;
            color: var(--text-secondary);
        }
        
        .notes-section {
            background: var(--bg-primary);
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 24px;
        }
        
        .notes-section h2 {
            font-size: 20px;
            margin-bottom: 16px;
        }
        
        .notes-content {
            background: var(--bg-secondary);
            padding: 16px;
            border-radius: 8px;
            border-left: 4px solid var(--primary-orange);
            color: var(--text-primary);
            line-height: 1.6;
        }
        
        .action-buttons {
            display: flex;
            gap: 12px;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: var(--primary-orange);
            color: white;
        }
        
        .btn-primary:hover {
            background: var(--primary-red);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255, 122, 0, 0.3);
        }
        
        .btn-secondary {
            background: var(--bg-secondary);
            color: var(--text-primary);
            border: 2px solid var(--border-color);
        }
        
        .btn-secondary:hover {
            background: var(--bg-gray);
            border-color: var(--primary-orange);
        }
        
        .loading {
            text-align: center;
            padding: 60px;
            color: var(--text-secondary);
        }
        
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 16px;
            border-radius: 8px;
            border-left: 4px solid #f5c6cb;
            margin-bottom: 24px;
        }
        
        .no-data {
            text-align: center;
            padding: 40px;
            color: var(--text-secondary);
        }
        
        .qty-comparison {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .qty-match {
            color: #28a745;
            font-weight: 600;
        }
        
        .qty-mismatch {
            color: #dc3545;
            font-weight: 600;
        }
        
        .signature-section {
            background: var(--bg-primary);
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 24px;
            text-align: center;
        }
        
        .signature-box {
            background: white;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            padding: 40px;
            margin: 16px auto;
            max-width: 400px;
        }
        
        @media print {
            .action-buttons {
                display: none;
            }
            
            .pod-container {
                margin: 0;
                padding: 0;
            }
        }
    </style>
</head>
<body>
    <div class="pod-container">
        <div class="loading" id="loading">
            <p>Loading Proof of Delivery...</p>
        </div>
        <div id="content" style="display: none;"></div>
    </div>

    <script>
        const podId = '<?php echo htmlspecialchars($podId); ?>';
        const transferId = '<?php echo htmlspecialchars($transferId); ?>';

        window.addEventListener('DOMContentLoaded', () => {
            if (podId) {
                loadPODById(podId);
            } else if (transferId) {
                loadPODByTransfer(transferId);
            } else {
                showError('No POD ID or Transfer ID provided');
            }
        });

        async function loadPODById(id) {
            try {
                const res = await fetch(`/api/proof-of-delivery.php?action=pod&id=${id}`);
                const data = await res.json();

                if (!data.success) {
                    throw new Error(data.error || 'Failed to load POD');
                }

                displayPOD(data.data);

            } catch (error) {
                console.error('Error loading POD:', error);
                showError(error.message);
            }
        }

        async function loadPODByTransfer(transferId) {
            try {
                const res = await fetch(`/api/proof-of-delivery.php?action=by-transfer&transferId=${transferId}`);
                const data = await res.json();

                if (!data.success) {
                    throw new Error(data.error || 'Failed to load POD');
                }

                displayPOD(data.data);

            } catch (error) {
                console.error('Error loading POD:', error);
                showError(error.message);
            }
        }

        function displayPOD(data) {
            const { pod, items, photos } = data;
            
            const html = `
                <div class="pod-header">
                    <h1>📋 Proof of Delivery</h1>
                    <p style="color: var(--text-secondary); margin-top: 8px;">
                        Transfer: <strong>${pod.transfer_number}</strong>
                    </p>
                    <div class="pod-status status-${pod.status.toLowerCase()}">
                        ${pod.status}
                    </div>
                </div>

                <div class="pod-info-grid">
                    <div class="info-card">
                        <h3>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                                <circle cx="12" cy="10" r="3"/>
                            </svg>
                            Transfer Route
                        </h3>
                        <div class="info-item">
                            <span class="info-label">From</span>
                            <span class="info-value">${pod.source_location_name}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">To</span>
                            <span class="info-value">${pod.destination_location_name}</span>
                        </div>
                    </div>

                    <div class="info-card">
                        <h3>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="12" cy="12" r="10"/>
                                <path d="M12 6v6l4 2"/>
                            </svg>
                            Timeline
                        </h3>
                        <div class="info-item">
                            <span class="info-label">Created</span>
                            <span class="info-value">${formatDateTime(pod.created_at)}</span>
                        </div>
                        ${pod.scanned_at ? `
                            <div class="info-item">
                                <span class="info-label">Scanned</span>
                                <span class="info-value">${formatDateTime(pod.scanned_at)}</span>
                            </div>
                        ` : ''}
                        ${pod.received_at ? `
                            <div class="info-item">
                                <span class="info-label">Received</span>
                                <span class="info-value">${formatDateTime(pod.received_at)}</span>
                            </div>
                        ` : ''}
                    </div>

                    <div class="info-card">
                        <h3>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/>
                                <circle cx="12" cy="7" r="4"/>
                            </svg>
                            Personnel
                        </h3>
                        ${pod.scanned_by_name ? `
                            <div class="info-item">
                                <span class="info-label">Scanned By</span>
                                <span class="info-value">${pod.scanned_by_name}</span>
                            </div>
                        ` : ''}
                        ${pod.received_by_name ? `
                            <div class="info-item">
                                <span class="info-label">Received By</span>
                                <span class="info-value">${pod.received_by_name}</span>
                            </div>
                        ` : ''}
                    </div>
                </div>

                ${items.length > 0 ? `
                    <div class="items-section">
                        <h2>
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
                            </svg>
                            Received Items
                        </h2>
                        <table class="items-table">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Expected</th>
                                    <th>Received</th>
                                    <th>Unit</th>
                                    <th>Condition</th>
                                    <th>Notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${items.map(item => {
                                    const qtyMatch = parseFloat(item.expected_quantity) === parseFloat(item.received_quantity);
                                    return `
                                        <tr>
                                            <td>
                                                <strong>${item.product_name}</strong><br>
                                                <small style="color: var(--text-secondary);">SKU: ${item.sku || 'N/A'}</small>
                                            </td>
                                            <td>${item.expected_quantity}</td>
                                            <td class="${qtyMatch ? 'qty-match' : 'qty-mismatch'}">
                                                ${item.received_quantity}
                                                ${!qtyMatch ? '<span style="font-size: 16px;">⚠️</span>' : ''}
                                            </td>
                                            <td>${item.unit}</td>
                                            <td>
                                                <span class="condition-badge condition-${item.condition_status.toLowerCase()}">
                                                    ${item.condition_status}
                                                </span>
                                            </td>
                                            <td>${item.notes || '-'}</td>
                                        </tr>
                                    `;
                                }).join('')}
                            </tbody>
                        </table>
                    </div>
                ` : '<div class="no-data">No items recorded</div>'}

                ${photos.length > 0 ? `
                    <div class="photos-section">
                        <h2>
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z"/>
                                <circle cx="12" cy="13" r="4"/>
                            </svg>
                            Photo Evidence (${photos.length})
                        </h2>
                        <div class="photos-grid">
                            ${photos.map(photo => `
                                <div class="photo-card" onclick="viewPhoto('${photo.file_path}')">
                                    <img src="/${photo.file_path}" alt="${photo.caption || 'POD Photo'}" />
                                    ${photo.caption ? `<div class="photo-caption">${photo.caption}</div>` : ''}
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}

                ${pod.confirmation_notes ? `
                    <div class="notes-section">
                        <h2>📝 Receiving Notes</h2>
                        <div class="notes-content">
                            ${escapeHtml(pod.confirmation_notes)}
                        </div>
                    </div>
                ` : ''}

                ${pod.status === 'Received' ? `
                    <div class="signature-section">
                        <h2>✓ Confirmed Delivery</h2>
                        <div class="signature-box">
                            <p style="margin: 0; font-weight: 600; font-size: 18px;">${pod.received_by_name}</p>
                            <p style="margin: 8px 0 0 0; color: var(--text-secondary); font-size: 14px;">
                                ${formatDateTime(pod.received_at)}
                            </p>
                        </div>
                    </div>
                ` : ''}

                <div class="action-buttons">
                    <button class="btn btn-primary" onclick="window.print()">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M6 9V2h12v7M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/>
                            <path d="M6 14h12v8H6z"/>
                        </svg>
                        Print POD
                    </button>
                    <button class="btn btn-secondary" onclick="window.close()">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M18 6L6 18M6 6l12 12"/>
                        </svg>
                        Close
                    </button>
                </div>
            `;

            document.getElementById('content').innerHTML = html;
            document.getElementById('content').style.display = 'block';
            document.getElementById('loading').style.display = 'none';
        }

        function formatDateTime(dateString) {
            if (!dateString) return 'N/A';
            const date = new Date(dateString);
            return date.toLocaleString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        function viewPhoto(path) {
            window.open('/' + path, '_blank');
        }

        function showError(message) {
            const html = `
                <div class="error-message">
                    <strong>Error:</strong> ${message}
                </div>
                <div class="action-buttons">
                    <button class="btn btn-secondary" onclick="window.close()">Close</button>
                </div>
            `;
            document.getElementById('content').innerHTML = html;
            document.getElementById('content').style.display = 'block';
            document.getElementById('loading').style.display = 'none';
        }
    </script>
</body>
</html>
