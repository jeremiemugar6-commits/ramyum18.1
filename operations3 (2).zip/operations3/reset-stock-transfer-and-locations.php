<?php
/**
 * Reset Stock Transfer and Location Data
 * Clears existing data and sets up proper connections
 */

require_once 'includes/auth.php';

$db = getDB();

echo "=================================================\n";
echo "  RESET STOCK TRANSFER & LOCATION DATA\n";
echo "=================================================\n\n";

try {
    $db->beginTransaction();
    
    // STEP 1: Clear existing stock transfer data
    echo "STEP 1: Clearing Stock Transfer Data\n";
    echo "-------------------------------------------------\n";
    
    $stmt = $db->query("DELETE FROM stock_transfers");
    $deletedTransfers = $stmt->rowCount();
    echo "✓ Deleted $deletedTransfers stock transfer(s)\n";
    
    $stmt = $db->query("DELETE FROM stock_transfer_audit");
    $deletedAudit = $stmt->rowCount();
    echo "✓ Deleted $deletedAudit audit record(s)\n\n";
    
    // STEP 2: Verify locations exist
    echo "STEP 2: Verifying Locations\n";
    echo "-------------------------------------------------\n";
    
    $stmt = $db->query("SELECT id, data FROM locations WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) = 'Active'");
    $locations = [];
    while ($row = $stmt->fetch()) {
        $data = json_decode($row['data'], true);
        $locations[] = [
            'id' => $row['id'],
            'name' => $data['name'],
            'address' => $data['address'] ?? '',
            'type' => $data['type'] ?? 'Branch'
        ];
        echo "✓ " . $row['id'] . " - " . $data['name'] . "\n";
    }
    
    if (count($locations) < 2) {
        echo "\n⚠ Warning: Need at least 2 active locations for stock transfers\n";
        echo "Creating additional locations...\n\n";
        
        // Create sample locations if needed
        $defaultLocations = [
            [
                'id' => 'loc_main_warehouse',
                'name' => 'Main Warehouse',
                'address' => '123 Main St, Manila',
                'type' => 'Warehouse',
                'contactPerson' => 'Warehouse Manager',
                'contactNumber' => '+63 2 1234 5678',
                'status' => 'Active'
            ],
            [
                'id' => 'loc_branch_makati',
                'name' => 'Makati Branch',
                'address' => '456 Ayala Ave, Makati City',
                'type' => 'Branch',
                'contactPerson' => 'Branch Manager',
                'contactNumber' => '+63 2 8765 4321',
                'status' => 'Active'
            ],
            [
                'id' => 'loc_branch_qc',
                'name' => 'Quezon City Branch',
                'address' => '789 Commonwealth Ave, Quezon City',
                'type' => 'Branch',
                'contactPerson' => 'QC Manager',
                'contactNumber' => '+63 2 9876 5432',
                'status' => 'Active'
            ]
        ];
        
        foreach ($defaultLocations as $loc) {
            // Check if exists
            $checkStmt = $db->prepare("SELECT COUNT(*) FROM locations WHERE id = ?");
            $checkStmt->execute([$loc['id']]);
            if ($checkStmt->fetchColumn() == 0) {
                $insertStmt = $db->prepare("INSERT INTO locations (id, data, created_at, updated_at) VALUES (?, ?, NOW(), NOW())");
                $insertStmt->execute([$loc['id'], json_encode($loc)]);
                $locations[] = [
                    'id' => $loc['id'],
                    'name' => $loc['name'],
                    'address' => $loc['address'],
                    'type' => $loc['type']
                ];
                echo "  ✓ Created: " . $loc['name'] . "\n";
            }
        }
    }
    
    echo "\n";
    
    // STEP 3: Verify inventory exists at locations
    echo "STEP 3: Verifying Inventory at Locations\n";
    echo "-------------------------------------------------\n";
    
    foreach ($locations as $location) {
        $stmt = $db->prepare("
            SELECT COUNT(*) as item_count, 
                   SUM(JSON_UNQUOTE(JSON_EXTRACT(data, '$.availableQuantity'))) as total_qty
            FROM inventory_locations
            WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.locationId')) = ?
        ");
        $stmt->execute([$location['id']]);
        $inv = $stmt->fetch();
        
        echo "  " . $location['name'] . ": ";
        echo $inv['item_count'] . " products, ";
        echo "Total Qty: " . ($inv['total_qty'] ?? 0) . "\n";
    }
    
    echo "\n";
    
    // STEP 4: Remove demo data indicators
    echo "STEP 4: Removing Demo Data Indicators\n";
    echo "-------------------------------------------------\n";
    
    // Check for demo config
    if (file_exists('api/demo-config.php')) {
        echo "✓ Demo config file exists (not deleted, just informational)\n";
    }
    
    // Remove any demo flags from locations
    foreach ($locations as $location) {
        $stmt = $db->prepare("SELECT data FROM locations WHERE id = ?");
        $stmt->execute([$location['id']]);
        $row = $stmt->fetch();
        $data = json_decode($row['data'], true);
        
        if (isset($data['isDemo']) || isset($data['demo'])) {
            unset($data['isDemo']);
            unset($data['demo']);
            $updateStmt = $db->prepare("UPDATE locations SET data = ? WHERE id = ?");
            $updateStmt->execute([json_encode($data), $location['id']]);
            echo "  ✓ Removed demo flag from: " . $location['name'] . "\n";
        }
    }
    
    echo "✓ No demo data indicators found\n\n";
    
    $db->commit();
    
    echo "=================================================\n";
    echo "           RESET COMPLETE!\n";
    echo "=================================================\n\n";
    
    echo "Summary:\n";
    echo "- Stock Transfers: Cleared ($deletedTransfers removed)\n";
    echo "- Locations: " . count($locations) . " active\n";
    echo "- System ready for new stock transfers\n\n";
    
    echo "Available Locations:\n";
    foreach ($locations as $loc) {
        echo "  • " . $loc['id'] . " - " . $loc['name'] . "\n";
    }
    echo "\n";
    
    echo "You can now create stock transfers between these locations.\n";
    echo "Access: http://localhost/operations3/\n\n";
    
} catch (Exception $e) {
    $db->rollBack();
    echo "\n✗ ERROR: " . $e->getMessage() . "\n\n";
    exit(1);
}
