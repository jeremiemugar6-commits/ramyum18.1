<?php
/**
 * FIX POR WORKFLOW ISSUES
 * 1. Link POR to Receiving records (match by PO number)
 * 2. Update inventory for completed PORs
 * 3. Fix broken PO references
 */

require_once 'config/database.php';
require_once 'includes/functions.php';

$db = getDB();

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "FIX POR WORKFLOW\n";
echo "═══════════════════════════════════════════════════════════════════════\n\n";

try {
    $db->beginTransaction();
    
    // STEP 1: Link POR to Receiving by matching PO numbers
    echo "STEP 1: Link POR to Receiving Records\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    $porStmt = $db->query("SELECT id, po_number, purchase_order_id FROM proof_of_receiving");
    $pors = $porStmt->fetchAll();
    
    $linkedCount = 0;
    $alreadyLinked = 0;
    $notFound = 0;
    
    foreach ($pors as $por) {
        // Check if already linked
        if (!empty($por['receiving_id'])) {
            $alreadyLinked++;
            continue;
        }
        
        $poNumber = $por['po_number'];
        echo "\nPOR: {$por['id']} (PO: {$poNumber})\n";
        
        // Find receiving by PO number
        $recStmt = $db->prepare("
            SELECT id, data FROM receivings 
            WHERE JSON_EXTRACT(data, '$.poNumber') = ?
            LIMIT 1
        ");
        $recStmt->execute([$poNumber]);
        $receiving = $recStmt->fetch();
        
        if (!$receiving) {
            echo "  ✗ No receiving found for PO {$poNumber}\n";
            $notFound++;
            continue;
        }
        
        $receivingData = json_decode($receiving['data'], true);
        $receivingId = $receiving['id'];
        
        // Update POR with receiving_id
        $updateStmt = $db->prepare("
            UPDATE proof_of_receiving 
            SET receiving_id = ?,
                updated_at = NOW()
            WHERE id = ?
        ");
        $updateStmt->execute([$receivingId, $por['id']]);
        
        echo "  ✓ Linked to receiving: {$receivingId}\n";
        $linkedCount++;
    }
    
    echo "\nStep 1 Results:\n";
    echo "  Linked: {$linkedCount}\n";
    echo "  Already linked: {$alreadyLinked}\n";
    echo "  Not found: {$notFound}\n";
    
    echo "\n";
    
    // STEP 2: Fix broken PO references (match by PO number)
    echo "STEP 2: Fix Broken PO References\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    $porStmt = $db->query("SELECT id, po_number, purchase_order_id FROM proof_of_receiving");
    $pors = $porStmt->fetchAll();
    
    $fixedPOLinks = 0;
    $validPOLinks = 0;
    
    foreach ($pors as $por) {
        $poNumber = $por['po_number'];
        $currentPOId = $por['purchase_order_id'];
        
        // Check if current PO ID is valid
        if ($currentPOId) {
            $checkStmt = $db->prepare("SELECT COUNT(*) FROM purchase_orders WHERE id = ?");
            $checkStmt->execute([$currentPOId]);
            if ($checkStmt->fetchColumn() > 0) {
                $validPOLinks++;
                continue;
            }
        }
        
        // Find correct PO by PO number
        $poStmt = $db->prepare("
            SELECT id FROM purchase_orders 
            WHERE JSON_EXTRACT(data, '$.poNumber') = ?
            LIMIT 1
        ");
        $poStmt->execute([$poNumber]);
        $correctPO = $poStmt->fetch();
        
        if ($correctPO) {
            $updateStmt = $db->prepare("
                UPDATE proof_of_receiving 
                SET purchase_order_id = ?,
                    updated_at = NOW()
                WHERE id = ?
            ");
            $updateStmt->execute([$correctPO['id'], $por['id']]);
            
            echo "✓ Fixed PO link for {$poNumber}: {$correctPO['id']}\n";
            $fixedPOLinks++;
        }
    }
    
    echo "\nStep 2 Results:\n";
    echo "  Fixed PO links: {$fixedPOLinks}\n";
    echo "  Valid PO links: {$validPOLinks}\n";
    
    echo "\n";
    
    // STEP 3: Update inventory for completed PORs
    echo "STEP 3: Update Inventory for Completed PORs\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    $completedPORs = $db->query("
        SELECT * FROM proof_of_receiving
        WHERE status = 'Completed' 
        AND (inventory_updated = 0 OR inventory_updated IS NULL)
    ")->fetchAll();
    
    echo "Found " . count($completedPORs) . " completed PORs needing inventory update\n\n";
    
    $inventoryUpdated = 0;
    
    foreach ($completedPORs as $por) {
        echo "Processing POR: {$por['por_number']}\n";
        
        // Get POR items
        $itemsStmt = $db->prepare("
            SELECT * FROM proof_of_receiving_items 
            WHERE por_id = ?
        ");
        $itemsStmt->execute([$por['id']]);
        $items = $itemsStmt->fetchAll();
        
        echo "  Items: " . count($items) . "\n";
        
        foreach ($items as $item) {
            $productId = $item['product_id'];
            $acceptedQty = floatval($item['accepted_quantity']);
            
            if ($acceptedQty <= 0) {
                echo "  - {$item['product_name']}: Skipped (0 accepted)\n";
                continue;
            }
            
            // Get current product stock
            $prodStmt = $db->prepare("SELECT data FROM products WHERE id = ?");
            $prodStmt->execute([$productId]);
            $productRow = $prodStmt->fetch();
            
            if (!$productRow) {
                echo "  - {$item['product_name']}: ✗ Product not found\n";
                continue;
            }
            
            $productData = json_decode($productRow['data'], true);
            $previousStock = floatval($productData['stock'] ?? 0);
            $newStock = $previousStock + $acceptedQty;
            
            // Update product stock
            $productData['stock'] = $newStock;
            $productData['lastUpdated'] = date('Y-m-d\TH:i:s.v\Z');
            
            $updateProdStmt = $db->prepare("UPDATE products SET data = ?, updated_at = NOW() WHERE id = ?");
            $updateProdStmt->execute([json_encode($productData), $productId]);
            
            // Create inventory movement record
            $movementId = generate_id('inv_mov');
            $movementData = [
                'id' => $movementId,
                'productId' => $productId,
                'productName' => $item['product_name'],
                'sku' => $item['sku'],
                'date' => date('Y-m-d\TH:i:s.v\Z'),
                'type' => 'Stock In',
                'referenceType' => 'POR',
                'referenceId' => $por['por_number'],
                'quantity' => $acceptedQty,
                'previousBalance' => $previousStock,
                'newBalance' => $newStock,
                'change' => $acceptedQty,
                'reason' => 'Proof of Receiving - Accepted Quantity',
                'notes' => "POR {$por['por_number']} - {$por['supplier_name']}",
                'user' => 'system',
                'unitCost' => floatval($item['unit_cost'] ?? 0)
            ];
            
            $movStmt = $db->prepare("INSERT INTO inventory_movements (id, data, created_at) VALUES (?, ?, NOW())");
            $movStmt->execute([$movementId, json_encode($movementData)]);
            
            echo "  ✓ {$item['product_name']}: {$previousStock} + {$acceptedQty} = {$newStock}\n";
        }
        
        // Mark POR as inventory updated
        $updatePORStmt = $db->prepare("
            UPDATE proof_of_receiving 
            SET inventory_updated = 1,
                inventory_updated_at = NOW(),
                updated_at = NOW()
            WHERE id = ?
        ");
        $updatePORStmt->execute([$por['id']]);
        
        echo "  ✓ Inventory updated for {$por['por_number']}\n\n";
        $inventoryUpdated++;
    }
    
    echo "Step 3 Results:\n";
    echo "  Inventory updated: {$inventoryUpdated} PORs\n";
    
    echo "\n";
    
    $db->commit();
    
    // VERIFICATION
    echo "═══════════════════════════════════════════════════════════════════════\n";
    echo "VERIFICATION\n";
    echo "═══════════════════════════════════════════════════════════════════════\n";
    
    $porWithReceiving = $db->query("
        SELECT COUNT(*) FROM proof_of_receiving
        WHERE receiving_id IS NOT NULL AND receiving_id != ''
    ")->fetchColumn();
    
    $porWithValidPO = $db->query("
        SELECT COUNT(*) FROM proof_of_receiving por
        INNER JOIN purchase_orders po ON por.purchase_order_id = po.id
    ")->fetchColumn();
    
    $porInventoryComplete = $db->query("
        SELECT COUNT(*) FROM proof_of_receiving
        WHERE status = 'Completed' AND inventory_updated = 1
    ")->fetchColumn();
    
    $totalPOR = $db->query("SELECT COUNT(*) FROM proof_of_receiving")->fetchColumn();
    $completedPOR = $db->query("SELECT COUNT(*) FROM proof_of_receiving WHERE status = 'Completed'")->fetchColumn();
    
    echo "POR with receiving link: {$porWithReceiving}/{$totalPOR}\n";
    echo "POR with valid PO link: {$porWithValidPO}/{$totalPOR}\n";
    echo "Completed POR with inventory: {$porInventoryComplete}/{$completedPOR}\n";
    
    echo "\n";
    echo "═══════════════════════════════════════════════════════════════════════\n";
    echo "FIX COMPLETE\n";
    echo "═══════════════════════════════════════════════════════════════════════\n";
    
} catch (Exception $e) {
    $db->rollBack();
    echo "\n✗ ERROR: " . $e->getMessage() . "\n";
    echo $e->getTraceAsString() . "\n";
    exit(1);
}
