<?php
/**
 * Authentication & Session Management Test
 * Verifies login flow, OTP, session handling, and API protection
 */

require_once 'config/database.php';
require_once 'includes/auth.php';

echo "=== RAM-YUM AUTHENTICATION TEST ===\n\n";

$db = getDB();
$passed = [];
$failed = [];

// Test 1: Check if users table exists and has test users
try {
    $stmt = $db->query("SELECT id, username, email, role, verified FROM users WHERE username IN ('admin', 'manager', 'staff')");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($users) >= 3) {
        $passed[] = "✓ Test users exist (admin, manager, staff)";
        foreach ($users as $user) {
            $passed[] = "  - {$user['username']} ({$user['role']}) - Email: {$user['email']} - Verified: " . ($user['verified'] ? 'Yes' : 'No');
        }
    } else {
        $failed[] = "✗ Missing test users (found " . count($users) . ", expected 3)";
    }
} catch (Exception $e) {
    $failed[] = "✗ Users table test failed: " . $e->getMessage();
}

// Test 2: Check login_attempts table
try {
    $stmt = $db->query("SELECT COUNT(*) as count FROM login_attempts");
    $result = $stmt->fetch();
    $passed[] = "✓ Login attempts tracking table exists (" . $result['count'] . " records)";
} catch (Exception $e) {
    $failed[] = "✗ Login attempts table test failed: " . $e->getMessage();
}

// Test 3: Check otp_codes table
try {
    $stmt = $db->query("SELECT COUNT(*) as count FROM otp_codes");
    $result = $stmt->fetch();
    $passed[] = "✓ OTP codes table exists (" . $result['count'] . " records)";
} catch (Exception $e) {
    $failed[] = "✗ OTP codes table test failed: " . $e->getMessage();
}

// Test 4: Check security_logs table
try {
    $stmt = $db->query("SELECT COUNT(*) as count FROM security_logs");
    $result = $stmt->fetch();
    $passed[] = "✓ Security logs table exists (" . $result['count'] . " records)";
} catch (Exception $e) {
    $failed[] = "✗ Security logs table test failed: " . $e->getMessage();
}

// Test 5: Check password hashing for test users
try {
    $stmt = $db->query("SELECT username, password_hash FROM users WHERE username IN ('admin', 'manager', 'staff')");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $allHashed = true;
    foreach ($users as $user) {
        if (empty($user['password_hash']) || !str_starts_with($user['password_hash'], '$')) {
            $failed[] = "✗ User {$user['username']} has invalid password hash";
            $allHashed = false;
        }
    }
    
    if ($allHashed && count($users) >= 3) {
        $passed[] = "✓ All test users have valid password hashes";
    }
} catch (Exception $e) {
    $failed[] = "✗ Password hash test failed: " . $e->getMessage();
}

// Test 6: Check session configuration
try {
    if (session_status() === PHP_SESSION_ACTIVE) {
        $passed[] = "✓ PHP session is active";
    } else {
        $failed[] = "✗ PHP session is not active";
    }
    
    // Check session settings
    $sessionName = session_name();
    $passed[] = "  - Session name: $sessionName";
    
} catch (Exception $e) {
    $failed[] = "✗ Session configuration test failed: " . $e->getMessage();
}

// Test 7: Check authentication helper functions exist
try {
    $functions = [
        'is_logged_in',
        'current_user',
        'require_login_api',
        'require_admin_api',
        'require_manager_api',
        'check_lockout',
        'record_failed_login',
        'clear_login_attempts',
        'generate_and_store_otp',
        'verify_otp',
        'verify_otp_reason',
        'send_otp_email'
    ];
    
    $allExist = true;
    foreach ($functions as $func) {
        if (!function_exists($func)) {
            $failed[] = "✗ Function $func does not exist";
            $allExist = false;
        }
    }
    
    if ($allExist) {
        $passed[] = "✓ All authentication helper functions exist (" . count($functions) . " functions)";
    }
} catch (Exception $e) {
    $failed[] = "✗ Helper functions test failed: " . $e->getMessage();
}

// Test 8: Check OTP configuration constants
try {
    $constants = [
        'MAX_LOGIN_ATTEMPTS' => MAX_LOGIN_ATTEMPTS,
        'LOCKOUT_MINUTES' => LOCKOUT_MINUTES,
        'OTP_LENGTH' => OTP_LENGTH,
        'OTP_TTL_MINUTES' => OTP_TTL_MINUTES,
        'OTP_MAX_ATTEMPTS' => OTP_MAX_ATTEMPTS,
        'OTP_RESEND_COOLDOWN_SECONDS' => OTP_RESEND_COOLDOWN_SECONDS
    ];
    
    $passed[] = "✓ Authentication constants configured:";
    foreach ($constants as $name => $value) {
        $passed[] = "  - $name = $value";
    }
} catch (Exception $e) {
    $failed[] = "✗ Constants test failed: " . $e->getMessage();
}

// Test 9: Check if OTP_DEMO_MODE is enabled
try {
    if (defined('OTP_DEMO_MODE') && OTP_DEMO_MODE === true) {
        $passed[] = "✓ OTP_DEMO_MODE is enabled (codes will be shown in responses)";
    } else {
        $passed[] = "ℹ OTP_DEMO_MODE is disabled (production mode)";
    }
} catch (Exception $e) {
    $failed[] = "✗ OTP_DEMO_MODE check failed: " . $e->getMessage();
}

// Test 10: Check API endpoint files exist
try {
    $endpoints = [
        'api/login.php',
        'api/verify-otp.php',
        'api/logout.php',
        'api/resend-otp.php',
        'api/profile.php',
        'api/change-password.php'
    ];
    
    $allExist = true;
    foreach ($endpoints as $endpoint) {
        if (!file_exists($endpoint)) {
            $failed[] = "✗ API endpoint missing: $endpoint";
            $allExist = false;
        }
    }
    
    if ($allExist) {
        $passed[] = "✓ All authentication API endpoints exist (" . count($endpoints) . " endpoints)";
    }
} catch (Exception $e) {
    $failed[] = "✗ API endpoints test failed: " . $e->getMessage();
}

// Test 11: Simulate lockout check (without actually failing logins)
try {
    [$locked, $remaining] = check_lockout('test_nonexistent_user_12345');
    if (!$locked && $remaining === 0) {
        $passed[] = "✓ Lockout mechanism works (no lockout for non-existent attempts)";
    } else {
        $failed[] = "✗ Lockout mechanism returned unexpected result";
    }
} catch (Exception $e) {
    $failed[] = "✗ Lockout test failed: " . $e->getMessage();
}

// Test 12: Check session handlers don't throw errors
try {
    // Test session functions exist and don't throw
    if (function_exists('session_regenerate_id') && 
        function_exists('session_destroy') && 
        function_exists('session_unset')) {
        $passed[] = "✓ PHP session functions available";
    } else {
        $failed[] = "✗ Some PHP session functions are missing";
    }
} catch (Exception $e) {
    $failed[] = "✗ Session handlers test failed: " . $e->getMessage();
}

// Output results
echo "\n=== PASSED (" . count($passed) . ") ===\n";
foreach ($passed as $p) {
    echo "$p\n";
}

if (!empty($failed)) {
    echo "\n=== FAILED (" . count($failed) . ") ===\n";
    foreach ($failed as $f) {
        echo "$f\n";
    }
    echo "\n❌ Some authentication tests failed!\n";
} else {
    echo "\n✅ All authentication tests passed!\n";
}

echo "\n=== TEST USER CREDENTIALS ===\n";
echo "Admin:   username: admin   | email: jeremiemugar6@gmail.com | password: admin123\n";
echo "Manager: username: manager | email: jeremiemugar7@gmail.com | password: manager123\n";
echo "Staff:   username: staff   | email: jeremiemugar8@gmail.com | password: staff123\n";

echo "\n=== AUTHENTICATION TEST COMPLETE ===\n";
