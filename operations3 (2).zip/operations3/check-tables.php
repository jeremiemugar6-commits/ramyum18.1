<?php
require_once 'includes/auth.php';

$db = getDB();

echo "=== DATABASE TABLES ===\n";
$stmt = $db->query('SHOW TABLES');
$tables = [];
while($row = $stmt->fetch(PDO::FETCH_NUM)) {
    $tables[] = $row[0];
    echo "- " . $row[0] . "\n";
}

// Check stock_transfers data
if (in_array('stock_transfers', $tables)) {
    echo "\n=== STOCK TRANSFERS ===\n";
    $stmt = $db->query('SELECT id, data FROM stock_transfers LIMIT 5');
    while($row = $stmt->fetch()) {
        $data = json_decode($row['data'], true);
        echo "ID: " . $row['id'] . "\n";
        echo "Number: " . ($data['transferNumber'] ?? 'N/A') . "\n";
        echo "Status: " . ($data['status'] ?? 'N/A') . "\n";
        echo "From: " . ($data['sourceLocationId'] ?? 'N/A') . " - " . ($data['sourceLocationName'] ?? 'N/A') . "\n";
        echo "To: " . ($data['destinationLocationId'] ?? 'N/A') . " - " . ($data['destinationLocationName'] ?? 'N/A') . "\n";
        echo "---\n";
    }
}

// Check locations data
if (in_array('locations', $tables)) {
    echo "\n=== LOCATIONS ===\n";
    $stmt = $db->query('SELECT id, data FROM locations');
    while($row = $stmt->fetch()) {
        $data = json_decode($row['data'], true);
        echo "ID: " . $row['id'] . " - Name: " . ($data['name'] ?? 'N/A') . " - Status: " . ($data['status'] ?? 'N/A') . "\n";
    }
}

// Check inventory_locations
if (in_array('inventory_locations', $tables)) {
    echo "\n=== INVENTORY LOCATIONS (Sample) ===\n";
    $stmt = $db->query('SELECT data FROM inventory_locations LIMIT 5');
    while($row = $stmt->fetch()) {
        $data = json_decode($row['data'], true);
        echo "Location: " . ($data['locationId'] ?? 'N/A') . " - Product: " . ($data['productId'] ?? 'N/A') . " - Qty: " . ($data['availableQuantity'] ?? 0) . "\n";
    }
}
