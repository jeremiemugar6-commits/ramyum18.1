<?php
/**
 * Debug and Fix POR Status
 * Comprehensive check and auto-fix for all POR records
 */

require_once __DIR__ . '/config/database.php';

$db = getDB();

// Handle AJAX request for badge counts
if (isset($_GET['ajax']) && $_GET['ajax'] === 'refresh_counts') {
    try {
        $stmt = $db->query("
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN inspection_status IN ('Pending', 'Pending Inspection') THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN inspection_status IN ('Passed', 'Approved') THEN 1 ELSE 0 END) as passed,
                SUM(CASE WHEN inspection_status IN ('Failed', 'Rejected') THEN 1 ELSE 0 END) as failed,
                SUM(CASE WHEN inspection_status IN ('Partial', 'Partially Approved') THEN 1 ELSE 0 END) as damaged
            FROM proof_of_receiving
            WHERE inspection_status != 'Archived'
        ");
        
        $stats = $stmt->fetch(PDO::FETCH_ASSOC);
        
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'data' => [
                'all' => (int)$stats['total'],
                'pending' => (int)$stats['pending'],
                'passed' => (int)$stats['passed'],
                'failed' => (int)$stats['failed'],
                'damaged' => (int)$stats['damaged']
            ]
        ]);
        exit;
    } catch (Exception $e) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        exit;
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Debug & Fix POR Status</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1400px; margin: 30px auto; padding: 20px; background: #f5f5f5; }
        h1 { color: #1F2937; }
        table { width: 100%; border-collapse: collapse; background: white; margin: 20px 0; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #E5E7EB; }
        th { background: #3B82F6; color: white; font-weight: 600; position: sticky; top: 0; }
        tr:hover { background: #F9FAFB; }
        .badge { padding: 4px 12px; border-radius: 4px; font-size: 0.875rem; font-weight: 600; display: inline-block; }
        .pending { background: #FEF3C7; color: #92400E; }
        .passed { background: #D1FAE5; color: #065F46; }
        .failed { background: #FEE2E2; color: #991B1B; }
        .partial { background: #DBEAFE; color: #1E40AF; }
        .info { background: #DBEAFE; padding: 15px; border-left: 4px solid #3B82F6; margin: 20px 0; border-radius: 4px; }
        .success { background: #D1FAE5; padding: 15px; border-left: 4px solid #10B981; margin: 20px 0; border-radius: 4px; }
        .warning { background: #FEF3C7; padding: 15px; border-left: 4px solid #F59E0B; margin: 20px 0; border-radius: 4px; }
        .error-box { background: #FEE2E2; padding: 15px; border-left: 4px solid #EF4444; margin: 20px 0; border-radius: 4px; }
        .btn { padding: 10px 20px; border: none; border-radius: 6px; font-weight: 600; cursor: pointer; font-size: 0.95rem; text-decoration: none; display: inline-block; margin: 5px; }
        .btn-primary { background: #10B981; color: white; }
        .btn-primary:hover { background: #059669; }
        .btn-secondary { background: #6B7280; color: white; }
        .btn-secondary:hover { background: #4B5563; }
        .stats { display: grid; grid-template-columns: repeat(5, 1fr); gap: 15px; margin: 20px 0; }
        .stat-card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); text-align: center; }
        .stat-number { font-size: 2rem; font-weight: 700; margin: 10px 0; }
        .stat-label { color: #6B7280; font-size: 0.875rem; font-weight: 600; text-transform: uppercase; }
        .logic-box { background: #F3F4F6; padding: 15px; border-radius: 8px; margin: 10px 0; font-family: monospace; font-size: 0.875rem; }
    </style>
</head>
<body>

<h1>🔍 POR Status Debugger & Fixer</h1>

<?php

try {
    // Get all POR records
    $stmt = $db->query("
        SELECT * FROM proof_of_receiving 
        WHERE inspection_status != 'Archived'
        ORDER BY created_at DESC
    ");
    $allPORs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($allPORs)) {
        echo "<div class='warning'><strong>⚠️ No POR records found!</strong></div>";
        exit;
    }
    
    // Analyze each POR
    $analysis = [];
    $needsFix = 0;
    
    foreach ($allPORs as $por) {
        // Get items
        $stmt = $db->prepare("SELECT * FROM proof_of_receiving_items WHERE por_id = ?");
        $stmt->execute([$por['id']]);
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Calculate totals from items table (source of truth)
        $totalOrdered = 0;
        $totalReceived = 0;
        $totalAccepted = 0;
        $totalRejected = 0;
        
        foreach ($items as $item) {
            $totalOrdered += (int)$item['ordered_quantity'];
            $totalReceived += (int)$item['received_quantity'];
            $totalAccepted += (int)$item['accepted_quantity'];
            $totalRejected += (int)$item['rejected_quantity'];
        }
        
        // Calculate correct status
        $correctStatus = 'Pending';
        $logic = '';
        
        if ($totalRejected > 0) {
            $correctStatus = 'Failed';
            $logic = "totalRejected ({$totalRejected}) > 0 → Failed";
        } elseif ($totalAccepted > 0 && $totalRejected == 0) {
            if ($totalAccepted == $totalReceived) {
                $correctStatus = 'Passed';
                $logic = "totalAccepted ({$totalAccepted}) == totalReceived ({$totalReceived}) AND no rejections → Passed";
            } else {
                $correctStatus = 'Partial';
                $logic = "totalAccepted ({$totalAccepted}) != totalReceived ({$totalReceived}) → Partial";
            }
        } else {
            $correctStatus = 'Pending';
            $logic = "No items accepted yet → Pending";
        }
        
        $mismatch = ($correctStatus !== $por['inspection_status']);
        if ($mismatch) $needsFix++;
        
        $analysis[] = [
            'por' => $por,
            'items' => $items,
            'totals' => [
                'ordered' => $totalOrdered,
                'received' => $totalReceived,
                'accepted' => $totalAccepted,
                'rejected' => $totalRejected
            ],
            'current_status' => $por['inspection_status'],
            'correct_status' => $correctStatus,
            'logic' => $logic,
            'mismatch' => $mismatch
        ];
    }
    
    // Display stats
    $countPending = count(array_filter($analysis, fn($a) => $a['current_status'] === 'Pending' || $a['current_status'] === 'Pending Inspection'));
    $countPassed = count(array_filter($analysis, fn($a) => $a['current_status'] === 'Passed' || $a['current_status'] === 'Approved'));
    $countFailed = count(array_filter($analysis, fn($a) => $a['current_status'] === 'Failed' || $a['current_status'] === 'Rejected'));
    $countPartial = count(array_filter($analysis, fn($a) => $a['current_status'] === 'Partial'));
    
    echo "<div class='stats'>";
    echo "<div class='stat-card'><div class='stat-label'>Total PORs</div><div class='stat-number' style='color:#3B82F6;'>" . count($allPORs) . "</div></div>";
    echo "<div class='stat-card'><div class='stat-label'>Pending</div><div class='stat-number' style='color:#F59E0B;'>{$countPending}</div></div>";
    echo "<div class='stat-card'><div class='stat-label'>Passed</div><div class='stat-number' style='color:#10B981;'>{$countPassed}</div></div>";
    echo "<div class='stat-card'><div class='stat-label'>Failed</div><div class='stat-number' style='color:#EF4444;'>{$countFailed}</div></div>";
    echo "<div class='stat-card'><div class='stat-label'>Needs Fix</div><div class='stat-number' style='color:#DC2626;'>{$needsFix}</div></div>";
    echo "</div>";
    
    if ($needsFix > 0) {
        echo "<div class='warning'><strong>⚠️ Found {$needsFix} POR records with incorrect status!</strong></div>";
        echo "<form method='POST' style='margin: 20px 0;'>";
        echo "<button type='submit' name='fix_all' value='1' class='btn btn-primary'>✓ Fix All {$needsFix} Records</button>";
        echo "<a href='dashboard.php' class='btn btn-secondary'>Cancel</a>";
        echo "</form>";
    } else {
        echo "<div class='success'><strong>✅ All POR status records are correct!</strong></div>";
    }
    
    // Handle fix
    if (isset($_POST['fix_all'])) {
        echo "<div class='info'><h3>🔄 Fixing POR Status Records...</h3></div>";
        
        $db->beginTransaction();
        $fixed = 0;
        
        foreach ($analysis as $record) {
            if ($record['mismatch']) {
                $stmt = $db->prepare("UPDATE proof_of_receiving SET inspection_status = ? WHERE id = ?");
                $stmt->execute([$record['correct_status'], $record['por']['id']]);
                $fixed++;
                
                echo "<div style='padding:8px; background:#D1FAE5; margin:4px 0; border-radius:4px;'>";
                echo "✓ {$record['por']['por_number']}: <span class='badge pending'>{$record['current_status']}</span> → <span class='badge passed'>{$record['correct_status']}</span>";
                echo "</div>";
            }
        }
        
        $db->commit();
        
        echo "<div class='success'>";
        echo "<h3>✅ Fixed {$fixed} POR records!</h3>";
        echo "<p><a href='debug-and-fix-por.php' class='btn btn-primary'>↻ Refresh Page</a></p>";
        echo "</div>";
    }
    
    // Display table
    echo "<h2>POR Status Analysis:</h2>";
    echo "<table>";
    echo "<tr>";
    echo "<th>POR #</th>";
    echo "<th>PO #</th>";
    echo "<th>Supplier</th>";
    echo "<th>Ordered</th>";
    echo "<th>Received</th>";
    echo "<th>Accepted</th>";
    echo "<th>Rejected</th>";
    echo "<th>Current Status</th>";
    echo "<th>Should Be</th>";
    echo "<th>Logic</th>";
    echo "</tr>";
    
    foreach ($analysis as $record) {
        $rowStyle = $record['mismatch'] ? 'background:#FEF3C7;' : '';
        $currentBadge = strtolower(str_replace(' ', '-', $record['current_status']));
        $correctBadge = strtolower($record['correct_status']);
        
        if ($currentBadge === 'pending-inspection') $currentBadge = 'pending';
        if ($currentBadge === 'approved') $currentBadge = 'passed';
        if ($currentBadge === 'rejected') $currentBadge = 'failed';
        
        echo "<tr style='{$rowStyle}'>";
        echo "<td><strong>{$record['por']['por_number']}</strong></td>";
        echo "<td>{$record['por']['po_number']}</td>";
        echo "<td>{$record['por']['supplier_name']}</td>";
        echo "<td>{$record['totals']['ordered']}</td>";
        echo "<td>{$record['totals']['received']}</td>";
        echo "<td style='color:#10B981; font-weight:600;'>{$record['totals']['accepted']}</td>";
        echo "<td style='color:#EF4444; font-weight:600;'>{$record['totals']['rejected']}</td>";
        echo "<td><span class='badge {$currentBadge}'>{$record['current_status']}</span></td>";
        
        if ($record['mismatch']) {
            echo "<td><span class='badge {$correctBadge}'><strong>→ {$record['correct_status']}</strong></span></td>";
        } else {
            echo "<td><span style='color:#10B981;'>✓ Correct</span></td>";
        }
        
        echo "<td><code style='font-size:0.8rem;'>{$record['logic']}</code></td>";
        echo "</tr>";
    }
    
    echo "</table>";
    
} catch (Exception $e) {
    echo "<div class='error-box'><strong>❌ Error:</strong> {$e->getMessage()}</div>";
}

?>

<p style='margin-top:30px;'>
    <a href='dashboard.php' class='btn btn-secondary'>← Back to Dashboard</a>
</p>

</body>
</html>
