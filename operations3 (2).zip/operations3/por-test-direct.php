<?php
require_once __DIR__ . '/includes/auth.php';
$currentUser = require_login_page();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POR Module Direct Test</title>
    <link rel="stylesheet" href="assets/css/main.css">
</head>
<body style="padding: 0; margin: 0; background: #f5f5f5;">
    <div style="max-width: 1200px; margin: 0 auto; padding: 40px 20px;">
        <div style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); margin-bottom: 30px;">
            <h1 style="color: #E31C1C; margin: 0 0 10px 0;">🧪 POR Module Direct Test</h1>
            <p style="color: #666; margin: 0;">Testing if POR module HTML can be loaded directly</p>
        </div>

        <div id="testResults" style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);"></div>
    </div>

    <script type="module">
        const results = document.getElementById('testResults');
        
        function addResult(icon, title, message, type = 'info') {
            const colors = {
                success: { bg: '#F0FDF4', border: '#10B981', text: '#065F46' },
                error: { bg: '#FEE2E2', border: '#EF4444', text: '#991B1B' },
                info: { bg: '#EFF6FF', border: '#3B82F6', text: '#1E40AF' }
            };
            const color = colors[type];
            
            const div = document.createElement('div');
            div.style.cssText = `background: ${color.bg}; border-left: 4px solid ${color.border}; padding: 20px; margin-bottom: 20px; border-radius: 6px;`;
            div.innerHTML = `
                <h3 style="margin: 0 0 10px 0; color: ${color.text};">${icon} ${title}</h3>
                <p style="margin: 0; color: ${color.text};">${message}</p>
            `;
            results.appendChild(div);
        }

        async function runTests() {
            addResult('🔍', 'Test 1: Import POR Module', 'Attempting to import modules/por/por.js...', 'info');
            
            try {
                const module = await import('./modules/por/por.js');
                addResult('✅', 'Module Import Success', `Successfully imported! Found exports: ${Object.keys(module).join(', ')}`, 'success');
                
                if (module.renderPOR && typeof module.renderPOR === 'function') {
                    addResult('✅', 'renderPOR Found', 'The renderPOR function exists and is callable', 'success');
                    
                    addResult('🔍', 'Test 2: Call renderPOR()', 'Attempting to render the POR module...', 'info');
                    
                    try {
                        await module.renderPOR();
                        addResult('✅', 'Render Success', 'renderPOR() executed without errors. Check above for the module content.', 'success');
                    } catch (renderError) {
                        addResult('❌', 'Render Error', `renderPOR() failed: ${renderError.message}`, 'error');
                        console.error('Render error:', renderError);
                    }
                } else {
                    addResult('❌', 'Function Missing', 'renderPOR function not found in module exports', 'error');
                }
                
            } catch (error) {
                addResult('❌', 'Import Failed', `Could not import module: ${error.message}`, 'error');
                console.error('Import error:', error);
                
                addResult('💡', 'Suggestion', 'Check browser console (F12) for detailed error stack trace', 'info');
            }
        }

        // Run tests on load
        runTests();
    </script>
</body>
</html>
