<?php
/**
 * COMPREHENSIVE DATABASE AUDIT
 * Fixed version with proper column detection
 */

require_once 'config/database.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$db = getDB();

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "RAM-YUM COMPREHENSIVE SYSTEM AUDIT\n";
echo "Date: " . date('Y-m-d H:i:s') . "\n";
echo "═══════════════════════════════════════════════════════════════════════\n\n";

// 1. DATABASE STRUCTURE
echo "1. DATABASE STRUCTURE\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$tables = $db->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
echo "✓ Total Tables: " . count($tables) . "\n\n";

// 2. CRITICAL TABLES WITH RECORD COUNTS
echo "2. CRITICAL TABLES STATUS\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$criticalTables = [
    'users' => 'User accounts',
    'products' => 'Product catalog',
    'suppliers' => 'Suppliers',
    'purchase_orders' => 'Purchase orders',
    'receivings' => 'Receiving records',
    'proof_of_receiving' => 'POR records',
    'proof_of_receiving_items' => 'POR line items',
    'inventory_movements' => 'Inventory transactions',
    'stock_transfers' => 'Stock transfers',
    'transfer_proof' => 'Transfer proof',
    'transfer_proof_items' => 'Transfer proof items',
    'locations' => 'Warehouse locations',
    'security_logs' => 'Audit trail',
    'login_attempts' => 'Login tracking'
];

foreach ($criticalTables as $table => $desc) {
    if (in_array($table, $tables)) {
        $count = $db->query("SELECT COUNT(*) FROM {$table}")->fetchColumn();
        echo "✓ {$table}: {$count} records - {$desc}\n";
    } else {
        echo "✗ {$table}: MISSING - {$desc}\n";
    }
}
echo "\n";

// 3. DATA INTEGRITY CHECKS
echo "3. DATA INTEGRITY\n";
echo "───────────────────────────────────────────────────────────────────────\n";

// Products
$prodCount = $db->query("SELECT COUNT(*) FROM products")->fetchColumn();
$prodWithSKU = $db->query("SELECT COUNT(*) FROM products WHERE JSON_EXTRACT(data, '$.sku') IS NOT NULL")->fetchColumn();
$prodWithStock = $db->query("SELECT COUNT(*) FROM products WHERE JSON_EXTRACT(data, '$.stock') IS NOT NULL")->fetchColumn();
echo "✓ Products: {$prodCount} total\n";
echo "  - With SKU: {$prodWithSKU}\n";
echo "  - With stock data: {$prodWithStock}\n";

// Duplicate SKUs
$dupSKUs = $db->query("
    SELECT JSON_EXTRACT(data, '$.sku') as sku, COUNT(*) as cnt 
    FROM products 
    WHERE JSON_EXTRACT(data, '$.sku') IS NOT NULL
    GROUP BY sku 
    HAVING cnt > 1
")->fetchAll();
if (count($dupSKUs) > 0) {
    echo "⚠ WARNING: " . count($dupSKUs) . " duplicate SKUs found:\n";
    foreach ($dupSKUs as $dup) {
        echo "  - SKU {$dup['sku']}: {$dup['cnt']} occurrences\n";
    }
} else {
    echo "✓ No duplicate SKUs\n";
}

// Users
$userCount = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
$adminCount = $db->query("SELECT COUNT(*) FROM users WHERE role = 'admin'")->fetchColumn();
$staffCount = $db->query("SELECT COUNT(*) FROM users WHERE role = 'staff'")->fetchColumn();
$managerCount = $db->query("SELECT COUNT(*) FROM users WHERE role = 'manager'")->fetchColumn();
echo "\n✓ Users: {$userCount} total\n";
echo "  - Admins: {$adminCount}\n";
echo "  - Managers: {$managerCount}\n";
echo "  - Staff: {$staffCount}\n";

// Check password hashing
$bcryptPasswords = $db->query("SELECT COUNT(*) FROM users WHERE password_hash LIKE '\$2y\$%'")->fetchColumn();
echo "  - Using bcrypt: {$bcryptPasswords}/{$userCount}\n";
if ($bcryptPasswords < $userCount) {
    echo "⚠ WARNING: Some users have weak password hashes\n";
}

// Purchase Orders
$poCount = $db->query("SELECT COUNT(*) FROM purchase_orders")->fetchColumn();
$poByStatus = $db->query("
    SELECT JSON_EXTRACT(data, '$.status') as status, COUNT(*) as cnt
    FROM purchase_orders
    GROUP BY status
")->fetchAll();
echo "\n✓ Purchase Orders: {$poCount} total\n";
foreach ($poByStatus as $status) {
    $statusName = trim($status['status'], '"');
    echo "  - {$statusName}: {$status['cnt']}\n";
}

// Receiving Records
$recCount = $db->query("SELECT COUNT(*) FROM receivings")->fetchColumn();
echo "\n✓ Receiving Records: {$recCount} total\n";

// Proof of Receiving
$porCount = $db->query("SELECT COUNT(*) FROM proof_of_receiving")->fetchColumn();
$porByStatus = $db->query("
    SELECT status, COUNT(*) as cnt
    FROM proof_of_receiving
    GROUP BY status
")->fetchAll();
$porByInspection = $db->query("
    SELECT inspection_status, COUNT(*) as cnt
    FROM proof_of_receiving
    GROUP BY inspection_status
")->fetchAll();
echo "\n✓ Proof of Receiving: {$porCount} total\n";
echo "  By Status:\n";
foreach ($porByStatus as $status) {
    echo "    - {$status['status']}: {$status['cnt']}\n";
}
echo "  By Inspection:\n";
foreach ($porByInspection as $insp) {
    echo "    - {$insp['inspection_status']}: {$insp['cnt']}\n";
}

// POR Items
$porItemCount = $db->query("SELECT COUNT(*) FROM proof_of_receiving_items")->fetchColumn();
echo "  - Total line items: {$porItemCount}\n";

// Stock Transfers
$stCount = $db->query("SELECT COUNT(*) FROM stock_transfers")->fetchColumn();
$stByStatus = $db->query("
    SELECT JSON_EXTRACT(data, '$.status') as status, COUNT(*) as cnt
    FROM stock_transfers
    GROUP BY status
")->fetchAll();
echo "\n✓ Stock Transfers: {$stCount} total\n";
foreach ($stByStatus as $status) {
    $statusName = trim($status['status'], '"');
    echo "  - {$statusName}: {$status['cnt']}\n";
}

// Transfer Proof
$tpCount = $db->query("SELECT COUNT(*) FROM transfer_proof")->fetchColumn();
$tpItemCount = $db->query("SELECT COUNT(*) FROM transfer_proof_items")->fetchColumn();
echo "\n✓ Transfer Proof: {$tpCount} records, {$tpItemCount} items\n";

// Inventory Movements
$invMovCount = $db->query("SELECT COUNT(*) FROM inventory_movements")->fetchColumn();
$invMovByType = $db->query("
    SELECT JSON_EXTRACT(data, '$.type') as type, COUNT(*) as cnt
    FROM inventory_movements
    GROUP BY type
    ORDER BY cnt DESC
    LIMIT 5
")->fetchAll();
echo "\n✓ Inventory Movements: {$invMovCount} transactions\n";
if (count($invMovByType) > 0) {
    echo "  Top transaction types:\n";
    foreach ($invMovByType as $type) {
        $typeName = trim($type['type'], '"');
        echo "    - {$typeName}: {$type['cnt']}\n";
    }
}

// Locations
$locCount = $db->query("SELECT COUNT(*) FROM locations")->fetchColumn();
echo "\n✓ Locations: {$locCount} locations\n";

echo "\n";

// 4. ORPHAN RECORDS CHECK
echo "4. ORPHAN RECORDS CHECK\n";
echo "───────────────────────────────────────────────────────────────────────\n";

// POR items without parent
$orphanPORItems = $db->query("
    SELECT COUNT(*) FROM proof_of_receiving_items pri
    LEFT JOIN proof_of_receiving pr ON pri.por_id = pr.id
    WHERE pr.id IS NULL
")->fetchColumn();
echo ($orphanPORItems > 0 ? "⚠" : "✓") . " POR items without parent: {$orphanPORItems}\n";

// Transfer proof items without parent
$orphanTPItems = $db->query("
    SELECT COUNT(*) FROM transfer_proof_items tpi
    LEFT JOIN transfer_proof tp ON tpi.proof_id = tp.id
    WHERE tp.id IS NULL
")->fetchColumn();
echo ($orphanTPItems > 0 ? "⚠" : "✓") . " Transfer proof items without parent: {$orphanTPItems}\n";

// POR without receiving reference (optional, some may be created directly)
$porWithoutReceiving = $db->query("
    SELECT COUNT(*) FROM proof_of_receiving
    WHERE receiving_id IS NULL OR receiving_id = ''
")->fetchColumn();
echo "ℹ POR records without receiving reference: {$porWithoutReceiving} (may be normal)\n";

echo "\n";

// 5. WORKFLOW INTEGRITY
echo "5. WORKFLOW INTEGRITY\n";
echo "───────────────────────────────────────────────────────────────────────\n";

// POs with receiving records
$poWithReceiving = $db->query("
    SELECT COUNT(DISTINCT po.id) FROM purchase_orders po
    INNER JOIN receivings r ON JSON_EXTRACT(r.data, '$.poId') = po.id
")->fetchColumn();
echo "✓ POs with receiving: {$poWithReceiving}/{$poCount}\n";

// Receivings with POR
$recWithPOR = $db->query("
    SELECT COUNT(DISTINCT pr.receiving_id) FROM proof_of_receiving pr
    WHERE pr.receiving_id IS NOT NULL AND pr.receiving_id != ''
")->fetchColumn();
echo "✓ Receivings with POR: {$recWithPOR}/{$recCount}\n";

// Transfers with proof
$stWithProof = $db->query("
    SELECT COUNT(DISTINCT tp.transfer_id) FROM transfer_proof tp
    WHERE tp.transfer_id IS NOT NULL AND tp.transfer_id != ''
")->fetchColumn();
echo "✓ Transfers with proof: {$stWithProof}/{$stCount}\n";

// POR with inventory updates
$porInventoryUpdated = $db->query("
    SELECT COUNT(*) FROM proof_of_receiving
    WHERE inventory_updated = 1
")->fetchColumn();
$porCompleted = $db->query("
    SELECT COUNT(*) FROM proof_of_receiving
    WHERE status = 'Completed'
")->fetchColumn();
echo "✓ POR with inventory updated: {$porInventoryUpdated}/{$porCompleted} completed\n";

echo "\n";

// 6. SECURITY AUDIT
echo "6. SECURITY AUDIT\n";
echo "───────────────────────────────────────────────────────────────────────\n";

// Login attempts
$loginAttemptsCount = $db->query("SELECT COUNT(*) FROM login_attempts")->fetchColumn();
$recentLockouts = $db->query("
    SELECT COUNT(*) FROM login_attempts
    WHERE failed_attempts >= 5 AND locked_until > NOW()
")->fetchColumn();
echo "✓ Login attempts logged: {$loginAttemptsCount}\n";
echo ($recentLockouts > 0 ? "⚠" : "✓") . " Currently locked accounts: {$recentLockouts}\n";

// Security logs
$secLogCount = $db->query("SELECT COUNT(*) FROM security_logs")->fetchColumn();
$recentLogs = $db->query("
    SELECT COUNT(*) FROM security_logs
    WHERE JSON_EXTRACT(data, '$.timestamp') > DATE_SUB(NOW(), INTERVAL 7 DAY)
")->fetchColumn();
echo "✓ Security log entries: {$secLogCount} total, {$recentLogs} in last 7 days\n";

echo "\n";

// 7. ISSUES SUMMARY
echo "7. ISSUES SUMMARY\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$criticalIssues = [];
$warnings = [];

if ($bcryptPasswords < $userCount) {
    $criticalIssues[] = "Weak password hashes detected";
}
if ($orphanPORItems > 0) {
    $warnings[] = "Orphan POR items found";
}
if ($orphanTPItems > 0) {
    $warnings[] = "Orphan transfer proof items found";
}
if (count($dupSKUs) > 0) {
    $criticalIssues[] = "Duplicate SKUs detected";
}
if ($tpCount == 0 && $stCount > 0) {
    $warnings[] = "Stock transfers exist but no transfer proofs";
}

if (empty($criticalIssues) && empty($warnings)) {
    echo "✓ NO CRITICAL ISSUES OR WARNINGS\n";
    echo "  System appears to be in good condition\n";
} else {
    if (!empty($criticalIssues)) {
        echo "⚠ CRITICAL ISSUES:\n";
        foreach ($criticalIssues as $issue) {
            echo "  • {$issue}\n";
        }
        echo "\n";
    }
    if (!empty($warnings)) {
        echo "⚠ WARNINGS:\n";
        foreach ($warnings as $warning) {
            echo "  • {$warning}\n";
        }
    }
}

echo "\n";
echo "═══════════════════════════════════════════════════════════════════════\n";
echo "AUDIT COMPLETE\n";
echo "═══════════════════════════════════════════════════════════════════════\n";
