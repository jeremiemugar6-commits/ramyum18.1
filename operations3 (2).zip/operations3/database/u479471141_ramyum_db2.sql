-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 04, 2026 at 02:52 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u479471141_ramyum_db2`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` varchar(40) NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`data`)),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `damage_evidence`
--

CREATE TABLE `damage_evidence` (
  `id` varchar(40) NOT NULL,
  `receiving_id` varchar(40) NOT NULL,
  `po_id` varchar(40) NOT NULL,
  `po_number` varchar(50) NOT NULL,
  `product_id` varchar(40) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `ordered_quantity` decimal(12,2) NOT NULL DEFAULT 0.00,
  `received_quantity` decimal(12,2) NOT NULL DEFAULT 0.00,
  `damaged_quantity` decimal(12,2) NOT NULL DEFAULT 0.00,
  `damage_description` text DEFAULT NULL,
  `evidence_image_path` varchar(500) DEFAULT NULL,
  `recorded_by` varchar(100) NOT NULL,
  `recorded_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_locations`
--

CREATE TABLE `inventory_locations` (
  `id` varchar(40) NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`data`)),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `quantity_value` decimal(10,2) GENERATED ALWAYS AS (cast(json_unquote(json_extract(`data`,'$.quantity')) as decimal(10,2))) STORED,
  `available_quantity_value` decimal(10,2) GENERATED ALWAYS AS (cast(json_unquote(json_extract(`data`,'$.availableQuantity')) as decimal(10,2))) STORED
) ;

--
-- Dumping data for table `inventory_locations`
--

INSERT INTO `inventory_locations` (`id`, `data`, `created_at`, `updated_at`) VALUES
('inv_p1_loc1', '{\"id\": \"inv_p1_loc1\", \"productId\": \"p1\", \"locationId\": \"loc1\", \"quantity\": 150, \"reservedQuantity\": 0, \"availableQuantity\": 140, \"lastUpdated\": \"2026-10-02T19:58:35.000Z\"}', '2026-10-01 02:21:59', '2026-10-04 18:42:34'),
('inv_p1_loc2', '{\"id\": \"inv_p1_loc2\", \"productId\": \"p1\", \"locationId\": \"loc2\", \"quantity\": 30, \"reservedQuantity\": 0, \"availableQuantity\": 40, \"lastUpdated\": \"2026-10-02T19:58:35.000Z\"}', '2026-10-01 02:21:59', '2026-10-04 18:42:34'),
('inv_p1_loc3', '{\"id\": \"inv_p1_loc3\", \"productId\": \"p1\", \"locationId\": \"loc3\", \"quantity\": 20, \"reservedQuantity\": 0, \"availableQuantity\": 20, \"lastUpdated\": \"2026-10-01T02:21:59.000Z\"}', '2026-10-01 02:21:59', '2026-10-01 02:21:59'),
('inv_p10_loc1', '{\"id\": \"inv_p10_loc1\", \"productId\": \"p10\", \"locationId\": \"loc1\", \"quantity\": 120, \"reservedQuantity\": 0, \"availableQuantity\": 120, \"lastUpdated\": \"2026-10-01T02:21:59.000Z\"}', '2026-10-01 02:21:59', '2026-10-01 02:21:59'),
('inv_p10_loc2', '{\"id\": \"inv_p10_loc2\", \"productId\": \"p10\", \"locationId\": \"loc2\", \"quantity\": 50, \"reservedQuantity\": 0, \"availableQuantity\": 50, \"lastUpdated\": \"2026-10-01T02:21:59.000Z\"}', '2026-10-01 02:21:59', '2026-10-01 02:21:59'),
('inv_p10_loc4', '{\"id\": \"inv_p10_loc4\", \"productId\": \"p10\", \"locationId\": \"loc4\", \"quantity\": 30, \"reservedQuantity\": 0, \"availableQuantity\": 30, \"lastUpdated\": \"2026-10-01T02:21:59.000Z\"}', '2026-10-01 02:21:59', '2026-10-01 02:21:59'),
('inv_p2_loc1', '{\"id\": \"inv_p2_loc1\", \"productId\": \"p2\", \"locationId\": \"loc1\", \"quantity\": 200, \"reservedQuantity\": 0, \"availableQuantity\": 200, \"lastUpdated\": \"2026-10-02T19:58:35.000Z\"}', '2026-10-01 02:21:59', '2026-10-02 19:58:35'),
('inv_p2_loc2', '{\"id\": \"inv_p2_loc2\", \"productId\": \"p2\", \"locationId\": \"loc2\", \"quantity\": 25, \"reservedQuantity\": 0, \"availableQuantity\": 25, \"lastUpdated\": \"2026-10-02T19:58:35.000Z\"}', '2026-10-01 02:21:59', '2026-10-02 19:58:35'),
('inv_p2_loc4', '{\"id\": \"inv_p2_loc4\", \"productId\": \"p2\", \"locationId\": \"loc4\", \"quantity\": 15, \"reservedQuantity\": 0, \"availableQuantity\": 15, \"lastUpdated\": \"2026-10-01T02:21:59.000Z\"}', '2026-10-01 02:21:59', '2026-10-01 02:21:59'),
('inv_p3_loc1', '{\"id\": \"inv_p3_loc1\", \"productId\": \"p3\", \"locationId\": \"loc1\", \"quantity\": 60, \"reservedQuantity\": 0, \"availableQuantity\": 60, \"lastUpdated\": \"2026-10-01T02:21:59.000Z\"}', '2026-10-01 02:21:59', '2026-10-01 02:21:59'),
('inv_p3_loc3', '{\"id\": \"inv_p3_loc3\", \"productId\": \"p3\", \"locationId\": \"loc3\", \"quantity\": 40, \"reservedQuantity\": 0, \"availableQuantity\": 40, \"lastUpdated\": \"2026-10-01T02:21:59.000Z\"}', '2026-10-01 02:21:59', '2026-10-01 02:21:59');

-- --------------------------------------------------------

--
-- Table structure for table `inventory_movements`
--

CREATE TABLE `inventory_movements` (
  `id` varchar(40) NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`data`)),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `inventory_movements`
--

INSERT INTO `inventory_movements` (`id`, `data`, `created_at`, `updated_at`) VALUES
('demo_mov_001', '{\"id\": \"demo_mov_001\", \"productId\": \"p10\", \"productName\": \"Korean Seaweed Snack\", \"sku\": \"KS-010\", \"date\": \"2026-10-01T02:21:39.000Z\", \"type\": \"Stock In\", \"quantity\": 15, \"previousBalance\": 40, \"newBalance\": 55, \"change\": 15, \"reason\": \"Purchase Order Receiving\", \"notes\": \"Received from Asia Grocery Supply via PO-2026-0003\", \"user\": \"Admin User\", \"referenceType\": \"RECEIVING\", \"referenceId\": \"GR-2026-0001\", \"referencePO\": \"PO-2026-0003\", \"unitCost\": 95.00}', '2026-10-01 02:21:39', '2026-10-01 02:21:39'),
('demo_mov_002', '{\"id\": \"demo_mov_002\", \"productId\": \"p1\", \"productName\": \"Samyang Buldak Original\", \"sku\": \"SB-001\", \"date\": \"2026-09-29T02:21:39.000Z\", \"type\": \"Adjustment\", \"quantity\": 5, \"previousBalance\": 50, \"newBalance\": 45, \"change\": -5, \"reason\": \"Inventory Count\", \"notes\": \"Cycle count adjustment - damaged items removed\", \"user\": \"Admin User\", \"referenceType\": \"MANUAL\", \"referenceId\": \"ADJ-001234\"}', '2026-10-01 02:21:39', '2026-10-01 02:21:39'),
('demo_mov_003', '{\"id\": \"demo_mov_003\", \"productId\": \"p2\", \"productName\": \"Shin Ramyun\", \"sku\": \"SR-002\", \"date\": \"2026-09-30T02:21:39.000Z\", \"type\": \"Stock Out\", \"quantity\": 8, \"previousBalance\": 40, \"newBalance\": 32, \"change\": -8, \"reason\": \"Sales\", \"notes\": \"Customer order fulfillment\", \"user\": \"Staff User\", \"referenceType\": \"MANUAL\", \"referenceId\": \"SALE-001\"}', '2026-10-01 02:21:39', '2026-10-01 02:21:39'),
('inv_mov_1791020404196_4908d9', '{\"id\":\"inv_mov_1791020404196_4908d9\",\"productId\":\"p1\",\"productName\":\"Samyang Buldak Original\",\"sku\":\"SB-001\",\"date\":\"2026-10-03T11:40:04.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0002\",\"referencePO\":\"PO-2026-0002\",\"quantity\":36,\"previousBalance\":45,\"newBalance\":81,\"change\":36,\"reason\":\"Proof of Receiving - Accepted Quantity\",\"notes\":\"POR POR-2026-0002 - Davao Meat Products Inc.\",\"user\":\"System (POR Integration)\",\"unitCost\":15}', '2026-10-03 11:40:04', '2026-10-03 11:40:04'),
('inv_mov_1791020404197_4afe45', '{\"id\":\"inv_mov_1791020404197_4afe45\",\"productId\":\"OIL001\",\"productName\":\"Sesame Oil (1L)\",\"sku\":\"OIL001\",\"date\":\"2026-10-03T11:40:04.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0002\",\"referencePO\":\"PO-2026-0002\",\"quantity\":41,\"previousBalance\":15,\"newBalance\":56,\"change\":41,\"reason\":\"Proof of Receiving - Accepted Quantity\",\"notes\":\"POR POR-2026-0002 - Davao Meat Products Inc.\",\"user\":\"System (POR Integration)\",\"unitCost\":120}', '2026-10-03 11:40:04', '2026-10-03 11:40:04'),
('inv_mov_1791020404198_515ad1', '{\"id\":\"inv_mov_1791020404198_515ad1\",\"productId\":\"SAU001\",\"productName\":\"Bulgogi Sauce\",\"sku\":\"SAU001\",\"date\":\"2026-10-03T11:40:04.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0003\",\"referencePO\":\"PO-2026-0003\",\"quantity\":63,\"previousBalance\":28,\"newBalance\":91,\"change\":63,\"reason\":\"Proof of Receiving - Accepted Quantity\",\"notes\":\"POR POR-2026-0003 - Davao Meat Products Inc.\",\"user\":\"System (POR Integration)\",\"unitCost\":45}', '2026-10-03 11:40:04', '2026-10-03 11:40:04'),
('inv_mov_1791020404199_07b52b', '{\"id\":\"inv_mov_1791020404199_07b52b\",\"productId\":\"MEAT001\",\"productName\":\"Beef Bulgogi (500g)\",\"sku\":\"MEAT001\",\"date\":\"2026-10-03T11:40:04.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0003\",\"referencePO\":\"PO-2026-0003\",\"quantity\":72,\"previousBalance\":20,\"newBalance\":92,\"change\":72,\"reason\":\"Proof of Receiving - Accepted Quantity\",\"notes\":\"POR POR-2026-0003 - Davao Meat Products Inc.\",\"user\":\"System (POR Integration)\",\"unitCost\":450}', '2026-10-03 11:40:04', '2026-10-03 11:40:04'),
('inv_mov_1791020404199_4e0265', '{\"id\":\"inv_mov_1791020404199_4e0265\",\"productId\":\"OIL001\",\"productName\":\"Sesame Oil (1L)\",\"sku\":\"OIL001\",\"date\":\"2026-10-03T11:40:04.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0003\",\"referencePO\":\"PO-2026-0003\",\"quantity\":31,\"previousBalance\":56,\"newBalance\":87,\"change\":31,\"reason\":\"Proof of Receiving - Accepted Quantity\",\"notes\":\"POR POR-2026-0003 - Davao Meat Products Inc.\",\"user\":\"System (POR Integration)\",\"unitCost\":120}', '2026-10-03 11:40:04', '2026-10-03 11:40:04'),
('inv_mov_1791020404201_99b650', '{\"id\":\"inv_mov_1791020404201_99b650\",\"productId\":\"SAU001\",\"productName\":\"Bulgogi Sauce\",\"sku\":\"SAU001\",\"date\":\"2026-10-03T11:40:04.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0006\",\"referencePO\":\"PO-2026-0006\",\"quantity\":60,\"previousBalance\":91,\"newBalance\":151,\"change\":60,\"reason\":\"Proof of Receiving - Accepted Quantity\",\"notes\":\"POR POR-2026-0006 - Cebu Fresh Foods Corp.\",\"user\":\"System (POR Integration)\",\"unitCost\":45}', '2026-10-03 11:40:04', '2026-10-03 11:40:04'),
('inv_mov_1791020404202_1ae05c', '{\"id\":\"inv_mov_1791020404202_1ae05c\",\"productId\":\"MEAT001\",\"productName\":\"Beef Bulgogi (500g)\",\"sku\":\"MEAT001\",\"date\":\"2026-10-03T11:40:04.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0006\",\"referencePO\":\"PO-2026-0006\",\"quantity\":57,\"previousBalance\":92,\"newBalance\":149,\"change\":57,\"reason\":\"Proof of Receiving - Accepted Quantity\",\"notes\":\"POR POR-2026-0006 - Cebu Fresh Foods Corp.\",\"user\":\"System (POR Integration)\",\"unitCost\":450}', '2026-10-03 11:40:04', '2026-10-03 11:40:04'),
('inv_mov_1791020404204_4a8f12', '{\"id\":\"inv_mov_1791020404204_4a8f12\",\"productId\":\"SAU001\",\"productName\":\"Bulgogi Sauce\",\"sku\":\"SAU001\",\"date\":\"2026-10-03T11:40:04.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0007\",\"referencePO\":\"PO-2026-0007\",\"quantity\":30,\"previousBalance\":151,\"newBalance\":181,\"change\":30,\"reason\":\"Proof of Receiving - Accepted Quantity\",\"notes\":\"POR POR-2026-0007 - Davao Meat Products Inc.\",\"user\":\"System (POR Integration)\",\"unitCost\":45}', '2026-10-03 11:40:04', '2026-10-03 11:40:04'),
('inv_mov_1791020404204_b1f518', '{\"id\":\"inv_mov_1791020404204_b1f518\",\"productId\":\"MEAT001\",\"productName\":\"Beef Bulgogi (500g)\",\"sku\":\"MEAT001\",\"date\":\"2026-10-03T11:40:04.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0007\",\"referencePO\":\"PO-2026-0007\",\"quantity\":23,\"previousBalance\":149,\"newBalance\":172,\"change\":23,\"reason\":\"Proof of Receiving - Accepted Quantity\",\"notes\":\"POR POR-2026-0007 - Davao Meat Products Inc.\",\"user\":\"System (POR Integration)\",\"unitCost\":450}', '2026-10-03 11:40:04', '2026-10-03 11:40:04'),
('inv_mov_1791020404205_cef434', '{\"id\":\"inv_mov_1791020404205_cef434\",\"productId\":\"MEAT002\",\"productName\":\"Lotte Luncheon Meat (340g)\",\"sku\":\"MEAT002\",\"date\":\"2026-10-03T11:40:04.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0007\",\"referencePO\":\"PO-2026-0007\",\"quantity\":22,\"previousBalance\":35,\"newBalance\":57,\"change\":22,\"reason\":\"Proof of Receiving - Accepted Quantity\",\"notes\":\"POR POR-2026-0007 - Davao Meat Products Inc.\",\"user\":\"System (POR Integration)\",\"unitCost\":380}', '2026-10-03 11:40:04', '2026-10-03 11:40:04'),
('inv_mov_1791020404205_f46c6d', '{\"id\":\"inv_mov_1791020404205_f46c6d\",\"productId\":\"OIL001\",\"productName\":\"Sesame Oil (1L)\",\"sku\":\"OIL001\",\"date\":\"2026-10-03T11:40:04.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0007\",\"referencePO\":\"PO-2026-0007\",\"quantity\":69,\"previousBalance\":87,\"newBalance\":156,\"change\":69,\"reason\":\"Proof of Receiving - Accepted Quantity\",\"notes\":\"POR POR-2026-0007 - Davao Meat Products Inc.\",\"user\":\"System (POR Integration)\",\"unitCost\":120}', '2026-10-03 11:40:04', '2026-10-03 11:40:04'),
('inv_mov_1791020404206_b6415e', '{\"id\":\"inv_mov_1791020404206_b6415e\",\"productId\":\"MEAT001\",\"productName\":\"Beef Bulgogi (500g)\",\"sku\":\"MEAT001\",\"date\":\"2026-10-03T11:40:04.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0008\",\"referencePO\":\"PO-2026-0008\",\"quantity\":38,\"previousBalance\":172,\"newBalance\":210,\"change\":38,\"reason\":\"Proof of Receiving - Accepted Quantity\",\"notes\":\"POR POR-2026-0008 - Quezon Wholesale Supplies\",\"user\":\"System (POR Integration)\",\"unitCost\":450}', '2026-10-03 11:40:04', '2026-10-03 11:40:04'),
('inv_mov_1791020404207_61d383', '{\"id\":\"inv_mov_1791020404207_61d383\",\"productId\":\"MEAT003\",\"productName\":\"Korean Sausage\",\"sku\":\"MEAT003\",\"date\":\"2026-10-03T11:40:04.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0008\",\"referencePO\":\"PO-2026-0008\",\"quantity\":54,\"previousBalance\":18,\"newBalance\":72,\"change\":54,\"reason\":\"Proof of Receiving - Accepted Quantity\",\"notes\":\"POR POR-2026-0008 - Quezon Wholesale Supplies\",\"user\":\"System (POR Integration)\",\"unitCost\":220}', '2026-10-03 11:40:04', '2026-10-03 11:40:04'),
('inv_mov_1791021193165_5a867d', '{\"id\":\"inv_mov_1791021193165_5a867d\",\"productId\":\"RAM002\",\"productName\":\"Samyang Buldak Quattro Cheese\",\"sku\":\"RAM002\",\"date\":\"2026-10-03T11:53:13.000Z\",\"type\":\"Stock Out\",\"referenceType\":\"STOCK_TRANSFER\",\"referenceId\":\"ST-2026-0007\",\"quantity\":15,\"previousBalance\":40,\"newBalance\":25,\"change\":-15,\"reason\":\"Stock Transfer - Out\",\"notes\":\"Transfer ST-2026-0007 from Main Warehouse to Makati Branch\",\"user\":\"System Admin\",\"location\":\"WH\"}', '2026-10-03 17:53:13', '2026-10-03 17:53:13'),
('inv_mov_1791021193165_6d39b9', '{\"id\":\"inv_mov_1791021193165_6d39b9\",\"productId\":\"MEAT001\",\"productName\":\"Beef Bulgogi (500g)\",\"sku\":\"MEAT001\",\"date\":\"2026-10-03T11:53:13.000Z\",\"type\":\"Stock Out\",\"referenceType\":\"STOCK_TRANSFER\",\"referenceId\":\"ST-2026-0007\",\"quantity\":15,\"previousBalance\":210,\"newBalance\":195,\"change\":-15,\"reason\":\"Stock Transfer - Out\",\"notes\":\"Transfer ST-2026-0007 from Main Warehouse to Makati Branch\",\"user\":\"System Admin\",\"location\":\"WH\"}', '2026-10-03 17:53:13', '2026-10-03 17:53:13'),
('inv_mov_1791021193165_d9324a', '{\"id\":\"inv_mov_1791021193165_d9324a\",\"productId\":\"RAM001\",\"productName\":\"Samyang Buldak Cheese\",\"sku\":\"RAM001\",\"date\":\"2026-10-03T11:53:13.000Z\",\"type\":\"Stock Out\",\"referenceType\":\"STOCK_TRANSFER\",\"referenceId\":\"ST-2026-0007\",\"quantity\":15,\"previousBalance\":50,\"newBalance\":35,\"change\":-15,\"reason\":\"Stock Transfer - Out\",\"notes\":\"Transfer ST-2026-0007 from Main Warehouse to Makati Branch\",\"user\":\"System Admin\",\"location\":\"WH\"}', '2026-10-03 17:53:13', '2026-10-03 17:53:13'),
('inventory_movement_1791050065677_c51afd', '{\"id\":\"inventory_movement_1791050065677_c51afd\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-03T19:54:25.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0012\",\"referencePO\":\"PO-2026-0033\",\"quantity\":1,\"previousBalance\":219,\"newBalance\":220,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 01:54:25', '2026-10-04 01:54:25'),
('inventory_movement_1791050254738_2f7b6a', '{\"id\":\"inventory_movement_1791050254738_2f7b6a\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-03T19:57:34.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0015\",\"referencePO\":\"PO-2026-0036\",\"quantity\":1,\"previousBalance\":220,\"newBalance\":221,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 01:57:34', '2026-10-04 01:57:34'),
('inventory_movement_1791050358372_b7fe12', '{\"id\":\"inventory_movement_1791050358372_b7fe12\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-03T19:59:18.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0017\",\"referencePO\":\"PO-2026-0037\",\"quantity\":1,\"previousBalance\":221,\"newBalance\":222,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 01:59:18', '2026-10-04 01:59:18'),
('inventory_movement_1791050838393_2ebb81', '{\"id\":\"inventory_movement_1791050838393_2ebb81\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-03T20:07:18.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0019\",\"referencePO\":\"PO-2026-0039\",\"quantity\":1,\"previousBalance\":222,\"newBalance\":223,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 02:07:18', '2026-10-04 02:07:18'),
('inventory_movement_1791051397755_054216', '{\"id\":\"inventory_movement_1791051397755_054216\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-03T20:16:37.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0021\",\"referencePO\":\"PO-2026-0034\",\"quantity\":1,\"previousBalance\":223,\"newBalance\":224,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 02:16:37', '2026-10-04 02:16:37'),
('inventory_movement_1791052182019_d07337', '{\"id\":\"inventory_movement_1791052182019_d07337\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-03T20:29:42.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0022\",\"referencePO\":\"PO-2026-0041\",\"quantity\":1,\"previousBalance\":224,\"newBalance\":225,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 02:29:42', '2026-10-04 02:29:42'),
('inventory_movement_1791052421741_8bc2e5', '{\"id\":\"inventory_movement_1791052421741_8bc2e5\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-03T20:33:41.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0023\",\"referencePO\":\"PO-2026-0042\",\"quantity\":1,\"previousBalance\":225,\"newBalance\":226,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 02:33:41', '2026-10-04 02:33:41'),
('inventory_movement_1791052637626_8ee3cc', '{\"id\":\"inventory_movement_1791052637626_8ee3cc\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-03T20:37:17.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0024\",\"referencePO\":\"PO-2026-0018\",\"quantity\":5,\"previousBalance\":226,\"newBalance\":231,\"change\":5,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 02:37:17', '2026-10-04 02:37:17'),
('inventory_movement_1791052975788_c0319d', '{\"id\":\"inventory_movement_1791052975788_c0319d\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-03T20:42:55.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0025\",\"referencePO\":\"PO-2026-0043\",\"quantity\":1,\"previousBalance\":231,\"newBalance\":232,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 02:42:55', '2026-10-04 02:42:55'),
('inventory_movement_1791053248566_83e722', '{\"id\":\"inventory_movement_1791053248566_83e722\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-03T20:47:28.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0026\",\"referencePO\":\"PO-2026-0044\",\"quantity\":1,\"previousBalance\":232,\"newBalance\":233,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 02:47:28', '2026-10-04 02:47:28'),
('inventory_movement_1791054383900_44f864', '{\"id\":\"inventory_movement_1791054383900_44f864\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-03T21:06:23.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0027\",\"referencePO\":\"PO-2026-0045\",\"quantity\":1,\"previousBalance\":233,\"newBalance\":234,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 03:06:23', '2026-10-04 03:06:23'),
('inventory_movement_1791054431261_04314f', '{\"id\":\"inventory_movement_1791054431261_04314f\",\"productId\":\"DRK002\",\"productName\":\"Welchs Strawberry\",\"sku\":\"N\\/A\",\"date\":\"2026-10-03T21:07:11.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0028\",\"referencePO\":\"PO-2026-0046\",\"quantity\":1,\"previousBalance\":15,\"newBalance\":16,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 03:07:11', '2026-10-04 03:07:11'),
('inventory_movement_1791054914093_66960d', '{\"id\":\"inventory_movement_1791054914093_66960d\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-03T21:15:14.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0029\",\"referencePO\":\"PO-2026-0047\",\"quantity\":1,\"previousBalance\":234,\"newBalance\":235,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 03:15:14', '2026-10-04 03:15:14'),
('inventory_movement_1791055146882_66f36c', '{\"id\":\"inventory_movement_1791055146882_66f36c\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-03T21:19:06.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0030\",\"referencePO\":\"PO-2026-0048\",\"quantity\":1,\"previousBalance\":235,\"newBalance\":236,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 03:19:06', '2026-10-04 03:19:06'),
('inventory_movement_1791055925443_08da4d', '{\"id\":\"inventory_movement_1791055925443_08da4d\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-03T21:32:05.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0031\",\"referencePO\":\"PO-2026-0049\",\"quantity\":1,\"previousBalance\":236,\"newBalance\":237,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 03:32:05', '2026-10-04 03:32:05'),
('inventory_movement_1791056136564_52868f', '{\"id\":\"inventory_movement_1791056136564_52868f\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-03T21:35:36.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0032\",\"referencePO\":\"PO-2026-0050\",\"quantity\":1,\"previousBalance\":237,\"newBalance\":238,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 03:35:36', '2026-10-04 03:35:36'),
('inventory_movement_1791056525675_55d7a1', '{\"id\":\"inventory_movement_1791056525675_55d7a1\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-03T21:42:05.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0033\",\"referencePO\":\"PO-2026-0051\",\"quantity\":1,\"previousBalance\":238,\"newBalance\":239,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 03:42:05', '2026-10-04 03:42:05'),
('inventory_movement_1791056581824_9a498c', '{\"id\":\"inventory_movement_1791056581824_9a498c\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-03T21:43:01.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0034\",\"referencePO\":\"PO-2026-0052\",\"quantity\":1,\"previousBalance\":239,\"newBalance\":240,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 03:43:01', '2026-10-04 03:43:01'),
('inventory_movement_1791056896184_47e6d1', '{\"id\":\"inventory_movement_1791056896184_47e6d1\",\"productId\":\"DRK002\",\"productName\":\"Welchs Strawberry\",\"sku\":\"N\\/A\",\"date\":\"2026-10-03T21:48:16.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0037\",\"referencePO\":\"PO-2026-0056\",\"quantity\":1,\"previousBalance\":16,\"newBalance\":17,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 03:48:16', '2026-10-04 03:48:16'),
('inventory_movement_1791096348210_e90bd4', '{\"id\":\"inventory_movement_1791096348210_e90bd4\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-04T08:45:48.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0038\",\"referencePO\":\"PO-2026-0057\",\"quantity\":1,\"previousBalance\":240,\"newBalance\":241,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 14:45:48', '2026-10-04 14:45:48'),
('inventory_movement_1791096631723_7677a9', '{\"id\":\"inventory_movement_1791096631723_7677a9\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-04T08:50:31.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0039\",\"referencePO\":\"PO-2026-0058\",\"quantity\":1,\"previousBalance\":241,\"newBalance\":242,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 14:50:31', '2026-10-04 14:50:31'),
('inventory_movement_1791097267729_75980b', '{\"id\":\"inventory_movement_1791097267729_75980b\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-04T09:01:07.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0040\",\"referencePO\":\"PO-2026-0059\",\"quantity\":1,\"previousBalance\":242,\"newBalance\":243,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 15:01:07', '2026-10-04 15:01:07'),
('inventory_movement_1791098990804_e4acc6', '{\"id\":\"inventory_movement_1791098990804_e4acc6\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-04T09:29:50.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0001\",\"referencePO\":\"PO-2026-0001\",\"quantity\":1,\"previousBalance\":243,\"newBalance\":244,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 15:29:50', '2026-10-04 15:29:50'),
('inventory_movement_1791099133660_02bace', '{\"id\":\"inventory_movement_1791099133660_02bace\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-04T09:32:13.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0001\",\"referencePO\":\"PO-2026-0001\",\"quantity\":1,\"previousBalance\":244,\"newBalance\":245,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 15:32:13', '2026-10-04 15:32:13'),
('inventory_movement_1791099457315_308f8b', '{\"id\":\"inventory_movement_1791099457315_308f8b\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-04T09:37:37.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0002\",\"referencePO\":\"PO-2026-0002\",\"quantity\":1,\"previousBalance\":245,\"newBalance\":246,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 15:37:37', '2026-10-04 15:37:37'),
('inventory_movement_1791100675610_ab2282', '{\"id\":\"inventory_movement_1791100675610_ab2282\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-04T09:57:55.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0003\",\"referencePO\":\"PO-2026-0003\",\"quantity\":1,\"previousBalance\":246,\"newBalance\":247,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 15:57:55', '2026-10-04 15:57:55'),
('inventory_movement_1791108342901_b19937', '{\"id\":\"inventory_movement_1791108342901_b19937\",\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"date\":\"2026-10-04T12:05:42.000Z\",\"type\":\"Stock In\",\"referenceType\":\"POR\",\"referenceId\":\"POR-2026-0006\",\"referencePO\":\"PO-2026-0006\",\"quantity\":1,\"previousBalance\":247,\"newBalance\":248,\"change\":1,\"reason\":\"Purchase Order Receiving - Inspected & Accepted\",\"notes\":\"Supplier: Seoul Food Distribution | Rejected: 0 | Damaged: 0\",\"user\":\"Admin User\",\"unitCost\":55,\"batchNumber\":null,\"expirationDate\":null}', '2026-10-04 18:05:42', '2026-10-04 18:05:42'),
('inventory_movements_1790821914611_fe308e', '{\"productId\":\"DRK001\",\"productName\":\"Welch&#x27;s Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-01T02:31:54.560Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0002\",\"referencePO\":\"PO-2026-0004\",\"quantity\":5,\"previousBalance\":35,\"newBalance\":40,\"change\":5,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from Seoul Food Distribution via PO-2026-0004\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1790821914611_fe308e\"}', '2026-10-01 02:31:54', '2026-10-01 02:31:54'),
('inventory_movements_1790842447571_6542d3', '{\"productId\":\"DRK001\",\"productName\":\"Welch&#x27;s Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-01T08:14:07.726Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0003\",\"referencePO\":\"PO-2026-0005\",\"quantity\":10,\"previousBalance\":40,\"newBalance\":50,\"change\":10,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from Seoul Food Distribution via PO-2026-0005\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1790842447571_6542d3\"}', '2026-10-01 08:14:07', '2026-10-01 08:14:07'),
('inventory_movements_1790842905446_536748', '{\"productId\":\"DRK001\",\"productName\":\"Welch&#x27;s Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-01T08:21:45.551Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0004\",\"referencePO\":\"PO-2026-0006\",\"quantity\":5,\"previousBalance\":50,\"newBalance\":55,\"change\":5,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from Seoul Food Distribution via PO-2026-0006\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1790842905446_536748\"}', '2026-10-01 08:21:45', '2026-10-01 08:21:45'),
('inventory_movements_1790848399232_7e7455', '{\"productId\":\"DRK001\",\"productName\":\"Welch&#x27;s Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-01T09:53:18.357Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0005\",\"referencePO\":\"PO-2026-0008\",\"quantity\":10,\"previousBalance\":55,\"newBalance\":65,\"change\":10,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from Seoul Food Distribution via PO-2026-0008\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1790848399232_7e7455\"}', '2026-10-01 09:53:19', '2026-10-01 09:53:19'),
('inventory_movements_1790942019029_475344', '{\"productId\":\"DRK001\",\"productName\":\"Welch&#x27;s Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-02T11:53:39.002Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0006\",\"referencePO\":\"PO-2026-0009\",\"quantity\":10,\"previousBalance\":65,\"newBalance\":75,\"change\":10,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from Seoul Food Distribution via PO-2026-0009\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1790942019029_475344\"}', '2026-10-02 19:53:39', '2026-10-02 19:53:39'),
('inventory_movements_1790961723464_ad0203', '{\"productId\":\"DRK004\",\"productName\":\"Pororo Apple\",\"sku\":\"DRK004\",\"date\":\"2026-10-02T17:22:03.456Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0007\",\"referencePO\":\"PO-2026-0010\",\"quantity\":5,\"previousBalance\":40,\"newBalance\":45,\"change\":5,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from Seoul Food Distribution via PO-2026-0010\",\"user\":\"Admin User\",\"unitCost\":45,\"id\":\"inventory_movements_1790961723464_ad0203\"}', '2026-10-03 01:22:03', '2026-10-03 01:22:03'),
('inventory_movements_1790998132607_b082c2', '{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-03T03:28:52.598Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0008\",\"referencePO\":\"PO-2026-0007\",\"quantity\":10,\"previousBalance\":159,\"newBalance\":169,\"change\":10,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from Seoul Food Distribution via PO-2026-0007\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1790998132607_b082c2\"}', '2026-10-03 11:28:52', '2026-10-03 11:28:52'),
('inventory_movements_1791012558480_066e27', '{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-03T07:29:18.468Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0009\",\"referencePO\":\"PO-2026-0011\",\"quantity\":5,\"previousBalance\":169,\"newBalance\":174,\"change\":5,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from Seoul Food Distribution via PO-2026-0011\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1791012558480_066e27\"}', '2026-10-03 15:29:18', '2026-10-03 15:29:18'),
('inventory_movements_1791023988977_a43799', '{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-03T10:39:48.968Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0010\",\"referencePO\":\"PO-2026-0012\",\"quantity\":5,\"previousBalance\":174,\"newBalance\":179,\"change\":5,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from Seoul Food Distribution via PO-2026-0012\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1791023988977_a43799\"}', '2026-10-03 18:39:48', '2026-10-03 18:39:48'),
('inventory_movements_1791025860209_1fa859', '{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-03T11:11:00.199Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0011\",\"referencePO\":\"PO-2026-0013\",\"quantity\":5,\"previousBalance\":179,\"newBalance\":184,\"change\":5,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from Seoul Food Distribution via PO-2026-0013\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1791025860209_1fa859\"}', '2026-10-03 19:11:00', '2026-10-03 19:11:00'),
('inventory_movements_1791031196265_e26e23', '{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-03T12:39:56.255Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0012\",\"referencePO\":\"PO-2026-0014\",\"quantity\":5,\"previousBalance\":184,\"newBalance\":189,\"change\":5,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from Seoul Food Distribution via PO-2026-0014\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1791031196265_e26e23\"}', '2026-10-03 20:39:56', '2026-10-03 20:39:56'),
('inventory_movements_1791031237014_e30c8b', '{\"productId\":\"DRK002\",\"productName\":\"Welchs Strawberry\",\"sku\":\"DRK002\",\"date\":\"2026-10-03T12:40:36.987Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0013\",\"referencePO\":\"PO-2026-0015\",\"quantity\":5,\"previousBalance\":10,\"newBalance\":15,\"change\":5,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from Seoul Food Distribution via PO-2026-0015\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1791031237014_e30c8b\"}', '2026-10-03 20:40:37', '2026-10-03 20:40:37'),
('inventory_movements_1791032948134_8cc3c7', '{\"productId\":\"p5\",\"productName\":\"Nongshim Neoguri\",\"sku\":\"NN-005\",\"date\":\"2026-10-03T13:09:08.125Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0014\",\"referencePO\":\"PO-2026-0002\",\"quantity\":25,\"previousBalance\":18,\"newBalance\":43,\"change\":25,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from K-Food Wholesale Trading via PO-2026-0002\",\"user\":\"Admin User\",\"unitCost\":72,\"id\":\"inventory_movements_1791032948134_8cc3c7\"}', '2026-10-03 21:09:08', '2026-10-03 21:09:08'),
('inventory_movements_1791032948158_8dc0d1', '{\"productId\":\"p6\",\"productName\":\"Nongshim Chapagetti\",\"sku\":\"NC-006\",\"date\":\"2026-10-03T13:09:08.149Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0014\",\"referencePO\":\"PO-2026-0002\",\"quantity\":20,\"previousBalance\":35,\"newBalance\":55,\"change\":20,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from K-Food Wholesale Trading via PO-2026-0002\",\"user\":\"Admin User\",\"unitCost\":69,\"id\":\"inventory_movements_1791032948158_8dc0d1\"}', '2026-10-03 21:09:08', '2026-10-03 21:09:08'),
('inventory_movements_1791033011580_b0a037', '{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-03T13:10:11.571Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0015\",\"referencePO\":\"PO-2026-0016\",\"quantity\":5,\"previousBalance\":189,\"newBalance\":194,\"change\":5,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from Seoul Food Distribution via PO-2026-0016\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1791033011580_b0a037\"}', '2026-10-03 21:10:11', '2026-10-03 21:10:11'),
('inventory_movements_1791034075322_e911cb', '{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-03T13:27:55.313Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0016\",\"referencePO\":\"PO-2026-0017\",\"quantity\":5,\"previousBalance\":194,\"newBalance\":199,\"change\":5,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from Seoul Food Distribution via PO-2026-0017\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1791034075322_e911cb\"}', '2026-10-03 21:27:55', '2026-10-03 21:27:55'),
('inventory_movements_1791037828859_276e79', '{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-03T14:30:28.849Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0017\",\"referencePO\":\"PO-2026-0019\",\"quantity\":5,\"previousBalance\":199,\"newBalance\":204,\"change\":5,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from Seoul Food Distribution via PO-2026-0019\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1791037828859_276e79\"}', '2026-10-03 22:30:28', '2026-10-03 22:30:28'),
('inventory_movements_1791039408225_81a11f', '{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-03T14:56:48.211Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0018\",\"referencePO\":\"PO-2026-0020\",\"quantity\":5,\"previousBalance\":204,\"newBalance\":209,\"change\":5,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from Seoul Food Distribution via PO-2026-0020\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1791039408225_81a11f\"}', '2026-10-03 22:56:48', '2026-10-03 22:56:48'),
('inventory_movements_1791040336934_809dc5', '{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-03T15:12:16.925Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0019\",\"referencePO\":\"PO-2026-0021\",\"quantity\":1,\"previousBalance\":209,\"newBalance\":210,\"change\":1,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from Seoul Food Distribution via PO-2026-0021\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1791040336934_809dc5\"}', '2026-10-03 23:12:16', '2026-10-03 23:12:16'),
('inventory_movements_1791040404943_ecf42d', '{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-03T15:13:24.934Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0020\",\"referencePO\":\"PO-2026-0022\",\"quantity\":1,\"previousBalance\":210,\"newBalance\":211,\"change\":1,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from Seoul Food Distribution via PO-2026-0022\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1791040404943_ecf42d\"}', '2026-10-03 23:13:24', '2026-10-03 23:13:24'),
('inventory_movements_1791040532536_6e45bb', '{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-03T15:15:32.526Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0021\",\"referencePO\":\"PO-2026-0023\",\"quantity\":1,\"previousBalance\":211,\"newBalance\":212,\"change\":1,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from Seoul Food Distribution via PO-2026-0023\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1791040532536_6e45bb\"}', '2026-10-03 23:15:32', '2026-10-03 23:15:32'),
('inventory_movements_1791041653852_528237', '{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-03T15:34:13.841Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0022\",\"referencePO\":\"PO-2026-0024\",\"quantity\":1,\"previousBalance\":212,\"newBalance\":213,\"change\":1,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from undefined via PO-2026-0024\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1791041653852_528237\"}', '2026-10-03 23:34:13', '2026-10-03 23:34:13'),
('inventory_movements_1791043049821_30968c', '{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-03T15:57:29.811Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0023\",\"referencePO\":\"PO-2026-0025\",\"quantity\":1,\"previousBalance\":213,\"newBalance\":214,\"change\":1,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from undefined via PO-2026-0025\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1791043049821_30968c\"}', '2026-10-03 23:57:29', '2026-10-03 23:57:29'),
('inventory_movements_1791043146119_3c4a93', '{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-03T15:59:06.088Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0024\",\"referencePO\":\"PO-2026-0026\",\"quantity\":1,\"previousBalance\":214,\"newBalance\":215,\"change\":1,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from undefined via PO-2026-0026\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1791043146119_3c4a93\"}', '2026-10-03 23:59:06', '2026-10-03 23:59:06'),
('inventory_movements_1791043209770_f32c70', '{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-03T16:00:09.742Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0025\",\"referencePO\":\"PO-2026-0027\",\"quantity\":1,\"previousBalance\":215,\"newBalance\":216,\"change\":1,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from undefined via PO-2026-0027\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1791043209770_f32c70\"}', '2026-10-04 00:00:09', '2026-10-04 00:00:09'),
('inventory_movements_1791044421871_4f0d9d', '{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-03T16:20:21.835Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0026\",\"referencePO\":\"PO-2026-0028\",\"quantity\":1,\"previousBalance\":216,\"newBalance\":217,\"change\":1,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from undefined via PO-2026-0028\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1791044421871_4f0d9d\"}', '2026-10-04 00:20:21', '2026-10-04 00:20:21'),
('inventory_movements_1791045842627_9fcee8', '{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-03T16:44:02.593Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0027\",\"referencePO\":\"PO-2026-0030\",\"quantity\":1,\"previousBalance\":217,\"newBalance\":218,\"change\":1,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from undefined via PO-2026-0030\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1791045842627_9fcee8\"}', '2026-10-04 00:44:02', '2026-10-04 00:44:02'),
('inventory_movements_1791045933556_6a0e88', '{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"sku\":\"DRK001\",\"date\":\"2026-10-03T16:45:33.546Z\",\"type\":\"Stock In\",\"referenceType\":\"RECEIVING\",\"referenceId\":\"GR-2026-0028\",\"referencePO\":\"PO-2026-0031\",\"quantity\":1,\"previousBalance\":218,\"newBalance\":219,\"change\":1,\"reason\":\"Purchase Order Receiving\",\"notes\":\"Received from undefined via PO-2026-0031\",\"user\":\"Admin User\",\"unitCost\":55,\"id\":\"inventory_movements_1791045933556_6a0e88\"}', '2026-10-04 00:45:33', '2026-10-04 00:45:33'),
('mov_st_demo_003_in', '{\"id\": \"mov_st_demo_003_in\", \"productId\": \"p3\", \"productName\": \"Ottogi Jin Ramen\", \"locationId\": \"loc4\", \"locationName\": \"Storage Area - BGC\", \"movementType\": \"Stock In\", \"quantity\": 30, \"previousStock\": 0, \"newStock\": 30, \"referenceType\": \"STOCK_TRANSFER\", \"referenceId\": \"ST-2026-0003\", \"performedBy\": \"u1\", \"performedByName\": \"Admin User\", \"reason\": \"Stock Transfer - In\", \"notes\": \"Transfer from Main Warehouse\", \"createdAt\": \"2026-09-30T02:22:26.000Z\"}', '2026-10-01 02:22:26', '2026-10-01 02:22:26'),
('mov_st_demo_003_out', '{\"id\": \"mov_st_demo_003_out\", \"productId\": \"p3\", \"productName\": \"Ottogi Jin Ramen\", \"locationId\": \"loc1\", \"locationName\": \"Main Warehouse\", \"movementType\": \"Stock Out\", \"quantity\": -30, \"previousStock\": 90, \"newStock\": 60, \"referenceType\": \"STOCK_TRANSFER\", \"referenceId\": \"ST-2026-0003\", \"performedBy\": \"u1\", \"performedByName\": \"Admin User\", \"reason\": \"Stock Transfer - Out\", \"notes\": \"Transfer to Storage Area - BGC\", \"createdAt\": \"2026-09-30T02:22:26.000Z\"}', '2026-10-01 02:22:26', '2026-10-01 02:22:26');

-- --------------------------------------------------------

--
-- Table structure for table `inventory_predictions`
--

CREATE TABLE `inventory_predictions` (
  `prediction_id` varchar(40) NOT NULL,
  `product_id` varchar(40) NOT NULL,
  `prediction_date` date NOT NULL,
  `historical_quantity` decimal(12,2) NOT NULL DEFAULT 0.00,
  `predicted_quantity` decimal(12,2) NOT NULL DEFAULT 0.00,
  `demand_status` varchar(20) NOT NULL DEFAULT 'Stable',
  `recommended_stock` decimal(12,2) NOT NULL DEFAULT 0.00,
  `accuracy_score` decimal(5,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `inventory_predictions`
--

INSERT INTO `inventory_predictions` (`prediction_id`, `product_id`, `prediction_date`, `historical_quantity`, `predicted_quantity`, `demand_status`, `recommended_stock`, `accuracy_score`, `created_at`) VALUES
('pred_1790842681409_5c0b0d', 'DRK004', '2026-11-01', 0.00, 0.00, 'Stable', 15.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681409_62787d', 'DRK003', '2026-11-01', 0.00, 0.00, 'Stable', 15.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681409_69583f', 'DRK001', '2026-11-01', 0.00, 0.00, 'Stable', 15.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681409_8e82e3', 'DRK002', '2026-11-01', 0.00, 0.00, 'Stable', 5.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681410_47a27d', 'DRK009', '2026-11-01', 0.00, 0.00, 'Stable', 10.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681410_60d9a2', 'DRK007', '2026-11-01', 0.00, 0.00, 'Stable', 10.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681410_6c1026', 'MEAT002', '2026-11-01', 0.00, 0.00, 'Stable', 10.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681410_938df1', 'DRK006', '2026-11-01', 0.00, 0.00, 'Stable', 15.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681410_9cb1a5', 'DRK008', '2026-11-01', 0.00, 0.00, 'Stable', 10.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681410_aa49cf', 'MEAT001', '2026-11-01', 15.00, 15.00, 'Stable', 18.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681410_bd5ab5', 'DRK005', '2026-11-01', 0.00, 0.00, 'Stable', 15.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681411_2689a2', 'p3', '2026-11-01', 0.00, 0.00, 'Stable', 20.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681411_481962', 'p4', '2026-11-01', 0.00, 0.00, 'Stable', 15.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681411_4f21c7', 'p5', '2026-11-01', 0.00, 0.00, 'Stable', 12.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681411_686cb4', 'p1', '2026-11-01', 0.00, 0.00, 'Stable', 20.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681411_6b0a38', 'MEAT003', '2026-11-01', 0.00, 0.00, 'Stable', 5.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681411_8cdf60', 'p10', '2026-11-01', 0.00, 0.00, 'Stable', 20.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681411_ba1e20', 'OIL001', '2026-11-01', 0.00, 0.00, 'Stable', 5.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681411_be503f', 'p2', '2026-11-01', 8.00, 8.00, 'Stable', 15.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681412_0dc9f7', 'RAM002', '2026-11-01', 15.00, 15.00, 'Stable', 18.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681412_14cc98', 'p9', '2026-11-01', 0.00, 0.00, 'Stable', 8.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681412_1b701e', 'p8', '2026-11-01', 0.00, 0.00, 'Stable', 8.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681412_416912', 'p7', '2026-11-01', 0.00, 0.00, 'Stable', 10.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681412_63f432', 'p6', '2026-11-01', 0.00, 0.00, 'Stable', 18.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681412_7e560a', 'PAN001', '2026-11-01', 0.00, 0.00, 'Stable', 8.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681412_819844', 'RAM001', '2026-11-01', 15.00, 15.00, 'Stable', 18.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681412_d88c40', 'PAN002', '2026-11-01', 0.00, 0.00, 'Stable', 15.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681413_04187a', 'RAM011', '2026-11-01', 0.00, 0.00, 'Stable', 15.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681413_15e645', 'RAM007', '2026-11-01', 0.00, 0.00, 'Stable', 15.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681413_284d57', 'RAM010', '2026-11-01', 0.00, 0.00, 'Stable', 20.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681413_4252bf', 'RAM004', '2026-11-01', 0.00, 0.00, 'Stable', 15.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681413_53466c', 'RAM009', '2026-11-01', 0.00, 0.00, 'Stable', 20.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681413_720bbd', 'RAM006', '2026-11-01', 0.00, 0.00, 'Stable', 15.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681413_9c5b17', 'RAM003', '2026-11-01', 0.00, 0.00, 'Stable', 15.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681413_b9d9c8', 'RAM008', '2026-11-01', 0.00, 0.00, 'Stable', 15.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681413_d6ad9d', 'RAM005', '2026-11-01', 0.00, 0.00, 'Stable', 15.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681414_3b4f9e', 'SEA001', '2026-11-01', 0.00, 0.00, 'Stable', 8.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681414_4724ba', 'RAM012', '2026-11-01', 0.00, 0.00, 'Stable', 10.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681414_6bddde', 'SNK002', '2026-11-01', 0.00, 0.00, 'Stable', 10.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681414_72a662', 'SNK003', '2026-11-01', 0.00, 0.00, 'Stable', 20.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681414_91d4f6', 'SNK001', '2026-11-01', 0.00, 0.00, 'Stable', 20.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681414_b610d5', 'SAU001', '2026-11-01', 0.00, 0.00, 'Stable', 10.00, 0.00, '2026-10-04 16:40:29'),
('pred_1790842681414_f8ee57', 'SNK004', '2026-11-01', 0.00, 0.00, 'Stable', 20.00, 0.00, '2026-10-04 16:40:29');

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `id` varchar(40) NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`data`)),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`id`, `data`, `created_at`, `updated_at`) VALUES
('loc1', '{\"id\": \"loc1\", \"name\": \"Main Warehouse\", \"code\": \"WH\", \"type\": \"Warehouse\", \"address\": \"123 Industrial Avenue, Manila\", \"manager\": \"Juan dela Cruz\", \"phone\": \"+63 2 8555 0001\", \"email\": \"warehouse@ramyum.com\", \"status\": \"Active\", \"capacity\": 2000, \"description\": \"Primary storage and distribution center\"}', '2026-10-01 02:21:59', '2026-10-01 02:22:49'),
('loc2', '{\"id\": \"loc2\", \"name\": \"Branch 1 - Makati\", \"code\": \"MKT\", \"type\": \"Branch\", \"address\": \"456 Ayala Avenue, Makati City\", \"manager\": \"Maria Santos\", \"phone\": \"+63 2 8555 0002\", \"email\": \"makati@ramyum.com\", \"status\": \"Active\", \"capacity\": 500, \"description\": \"Makati retail branch with premium location\"}', '2026-10-01 02:21:59', '2026-10-01 02:22:49'),
('loc3', '{\"id\": \"loc3\", \"name\": \"Branch 2 - Quezon City\", \"code\": \"QC\", \"type\": \"Branch\", \"address\": \"789 Commonwealth Avenue, Quezon City\", \"manager\": \"Ana Rodriguez\", \"phone\": \"+63 2 8555 0003\", \"email\": \"qc@ramyum.com\", \"status\": \"Active\", \"capacity\": 400, \"description\": \"Quezon City retail branch with cold storage\"}', '2026-10-01 02:21:59', '2026-10-01 02:22:49'),
('loc4', '{\"id\": \"loc4\", \"name\": \"Storage Area - BGC\", \"code\": \"BGC\", \"type\": \"Storage\", \"address\": \"321 Bonifacio Global City, Taguig\", \"manager\": \"Roberto Kim\", \"phone\": \"+63 2 8555 0004\", \"email\": \"bgc@ramyum.com\", \"status\": \"Active\", \"capacity\": 1500, \"description\": \"Secondary storage facility for overflow inventory\"}', '2026-10-01 02:21:59', '2026-10-01 02:22:49');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `identifier` varchar(150) NOT NULL,
  `attempt_count` int(11) NOT NULL DEFAULT 0,
  `last_attempt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `login_attempts`
--

INSERT INTO `login_attempts` (`identifier`, `attempt_count`, `last_attempt`) VALUES
('alghazi', 3, '2026-10-01 15:20:44'),
('jeremiemugar7@gmail.com', 1, '2026-10-03 21:42:40'),
('juremiemugar6@gmail.com', 2, '2026-10-03 18:29:44'),
('staff', 1, '2026-10-03 21:42:03');

-- --------------------------------------------------------

--
-- Table structure for table `otp_codes`
--

CREATE TABLE `otp_codes` (
  `id` varchar(40) NOT NULL,
  `user_id` varchar(40) NOT NULL,
  `code_hash` varchar(255) NOT NULL,
  `purpose` varchar(30) NOT NULL DEFAULT 'login',
  `attempts` int(11) NOT NULL DEFAULT 0,
  `expires_at` datetime NOT NULL,
  `consumed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `otp_codes`
--

INSERT INTO `otp_codes` (`id`, `user_id`, `code_hash`, `purpose`, `attempts`, `expires_at`, `consumed_at`, `created_at`) VALUES
('otp_1790821843933_9b6a96', 'u1', '$2y$10$/9Lr83HprtBQ.DMhTFYPKOsf8yqxQblq2OiiHrbxMIXVsf.xvpI/O', 'login', 0, '2026-10-01 02:35:43', '2026-10-01 02:31:01', '2026-10-01 02:30:43'),
('otp_1790842219428_f28ed0', 'u1', '$2y$10$W1ktJl3eWBZgz6y9.zJzOuC1aSFgwIvD/6NfN9ZZFOu/X2ZxWluNC', 'login', 0, '2026-10-01 08:15:19', '2026-10-01 08:10:40', '2026-10-01 08:10:19'),
('otp_1790843283320_f14e17', 'u1', '$2y$10$71a1R8EbZe9dt.WWe0Z6/egAf/Y9szm2o.TSKNU/G8ahJtjPNzNDW', 'login', 0, '2026-10-01 08:33:03', '2026-10-01 08:28:42', '2026-10-01 08:28:03'),
('otp_1790848146088_b7a627', 'u1', '$2y$10$HyuMPk7lhpZbcTp/mTAwtu1Q.qLrEgJlnmG6N3t6fNZiT5vQx4BES', 'login', 0, '2026-10-01 09:54:06', '2026-10-01 09:49:26', '2026-10-01 09:49:06'),
('otp_1790850132452_6ea91a', 'u1', '$2y$10$fRQC/n0.a5YDAy/QynbRQOu0b6Z1ccsdB42gXqnYlvxPwO0jpp1ke', 'login', 0, '2026-10-01 10:27:12', '2026-10-01 10:22:30', '2026-10-01 10:22:12'),
('otp_1790856593062_febf4c', 'u1', '$2y$10$5J0Y4rH4Xj4uQB6RWPlpUuyxfcOFK.D72nri.RnQIKyeOhUEDe/32', 'login', 0, '2026-10-01 12:14:53', '2026-10-01 12:11:35', '2026-10-01 12:09:53'),
('otp_1790857819369_83e911', 'u1', '$2y$10$Rl8veHHx3PRmS8u4UCuyBe//HTEYhgrafFM1hckXbTzxqiBGoXL2e', 'login', 0, '2026-10-01 12:35:19', '2026-10-01 12:30:50', '2026-10-01 12:30:19'),
('otp_1790859382237_e0ff96', 'u1', '$2y$10$rfHWZ7gEDq/n1CCghTuwluQtp8wvq2BqJtNyc4HmxlJ2.lqAC8R7K', 'login', 0, '2026-10-01 13:01:22', '2026-10-01 12:56:53', '2026-10-01 12:56:22'),
('otp_1790871461333_8f5e07', 'u1', '$2y$10$PlvsJYdK3pEaityHJ/.2de6GAsrbkfu2Q8yhgSX3jGeBMACi1yA4.', 'login', 0, '2026-10-01 16:22:41', '2026-10-01 16:17:58', '2026-10-01 16:17:41'),
('otp_1790941823025_24c140', 'u1', '$2y$10$2dr7YqmbPIT/qODrqib5.uz.N6yLIw1o/dI6kJ479gTch2csDQ4EO', 'login', 0, '2026-10-02 19:55:23', '2026-10-02 19:50:42', '2026-10-02 19:50:23'),
('otp_1790964831393_a7d622', 'u1', '$2y$10$gwqgl09j0cajLCl7hMJio.bwTuME2KIK/.xphHWGPagmoviLikLEi', 'login', 0, '2026-10-03 02:18:51', '2026-10-03 02:14:44', '2026-10-03 02:13:51'),
('otp_1790965385946_cb9723', 'u1', '$2y$10$pfsCmtCyU3uE.2PYzczvvOwXBNkd0SvyBT4yDDZ7az0nG3wwCB/O.', 'login', 0, '2026-10-03 02:28:05', '2026-10-03 02:23:20', '2026-10-03 02:23:05'),
('otp_1790995811862_269ba8', 'u1', '$2y$10$V6QPLY2ulm/zx5PF.xmpJ.nVa8hH8kLAtm5NlCDJrcNC02ZpdrAEy', 'login', 0, '2026-10-03 10:55:11', '2026-10-03 10:50:32', '2026-10-03 10:50:11'),
('otp_1790996807055_11c671', 'u1', '$2y$10$G/yoxn92xZ8Tc4OnfW91VeRedqSAahc3Xfb8WSIYez6XlTW8r4wgS', 'login', 0, '2026-10-03 11:11:47', '2026-10-03 11:07:02', '2026-10-03 11:06:47'),
('otp_1790998387147_22962f', 'u1', '$2y$10$cI0vlb2Us960xrqtIU5Vk..uBSAezs91YfwW/GOk4jr0Op.5v6dei', 'login', 0, '2026-10-03 11:38:07', '2026-10-03 11:33:21', '2026-10-03 11:33:07'),
('otp_1791002194212_fdaed0', 'u1', '$2y$10$gHrwUEVUsULXK7Uh58z6J.KeCeF4DzkeVHK1NzH3GuCdicWRfhOAS', 'login', 0, '2026-10-03 12:41:34', '2026-10-03 12:36:50', '2026-10-03 12:36:34'),
('otp_1791002927122_34b830', 'u1', '$2y$10$Sa9tvb/4OIG8g.dTaX5D5OEtAjimfLXtFsCkI2vhFu.R240no10aa', 'login', 0, '2026-10-03 12:53:47', '2026-10-03 12:49:04', '2026-10-03 12:48:47'),
('otp_1791007131595_f65356', 'u1', '$2y$10$5Tx8L4Xwc6tZoRc3I/grE.cMmB3IOmqvHCmLh5JsYCjbyOy3BbPDy', 'login', 1, '2026-10-03 14:03:51', '2026-10-03 14:05:22', '2026-10-03 13:58:51'),
('otp_1791035453938_eca3ac', 'u1', '$2y$10$0COgv70zbOju3aFgkRp1V.xYVjgkerLVhlCenfhd1Q38STB7QjP0m', 'login', 0, '2026-10-03 21:55:53', '2026-10-03 21:51:13', '2026-10-03 21:50:53'),
('otp_1791035635522_6b8d91', 'u1', '$2y$10$8OAttISX7KwvQxIOGFu3uuGPGpjEqwMYSErZw43OzCWu9lp2AAwg2', 'login', 0, '2026-10-03 21:58:55', '2026-10-03 21:54:09', '2026-10-03 21:53:55'),
('otp_1791038643116_d3cb67', 'u1', '$2y$10$LmOJQrWjOkjN51Sy2115wObR46ZHwhp99sTFii6PDfDO5PH05o.5y', 'login', 0, '2026-10-03 22:49:03', '2026-10-03 22:44:18', '2026-10-03 22:44:03'),
('otp_1791096258622_c65fce', 'u1', '$2y$10$KyM1jyPdJj0SYTfu2r3bfuowLwZJjFQtBAfpQhU8B6JMAFgEJH7iq', 'login', 0, '2026-10-04 14:49:18', '2026-10-04 14:44:44', '2026-10-04 14:44:18'),
('otp_1791106450640_08c569', 'u1', '$2y$10$nWgnfCTEY.iYwjFJ1HnOd.JKquZmGxzjbXFTjizzkJ1af2sCqSwNS', 'login', 0, '2026-10-04 17:39:10', '2026-10-04 17:34:57', '2026-10-04 17:34:10'),
('otp_1791110072795_0b7894', 'u1', '$2y$10$Yqq34K17cNUC0ZdpeoqpPO1yiTQE2BhVacJj2f4/OPl/N5GvIa0HW', 'login', 0, '2026-10-04 18:39:32', '2026-10-04 18:35:02', '2026-10-04 18:34:32'),
('otp_1791112098609_25f51f', 'u1', '$2y$10$jHuoPG6IH.6o6e5Hr9nPFepQiXgq2VLJth9avQM1XFfGxodCv7eyy', 'login', 0, '2026-10-04 19:13:18', '2026-10-04 19:08:38', '2026-10-04 19:08:18');

-- --------------------------------------------------------

--
-- Table structure for table `pod_items`
--

CREATE TABLE `pod_items` (
  `id` varchar(40) NOT NULL,
  `pod_id` varchar(40) NOT NULL,
  `transfer_id` varchar(40) NOT NULL,
  `product_id` varchar(40) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `sku` varchar(50) DEFAULT NULL,
  `expected_quantity` decimal(12,2) NOT NULL DEFAULT 0.00,
  `received_quantity` decimal(12,2) NOT NULL DEFAULT 0.00,
  `unit` varchar(50) NOT NULL DEFAULT 'pcs',
  `condition_status` varchar(30) NOT NULL DEFAULT 'Good',
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pod_photos`
--

CREATE TABLE `pod_photos` (
  `id` varchar(40) NOT NULL,
  `pod_id` varchar(40) NOT NULL,
  `pod_item_id` varchar(40) DEFAULT NULL,
  `transfer_id` varchar(40) NOT NULL,
  `photo_type` varchar(30) NOT NULL DEFAULT 'delivery',
  `file_path` varchar(500) NOT NULL,
  `file_size` int(11) DEFAULT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `caption` text DEFAULT NULL,
  `uploaded_by_id` varchar(40) NOT NULL,
  `uploaded_by_name` varchar(100) NOT NULL,
  `uploaded_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `por_backup_20261003`
--

CREATE TABLE `por_backup_20261003` (
  `id` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `por_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `purchase_order_id` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `po_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `receiving_id` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplier_id` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `received_by` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `received_by_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `receiving_date` datetime NOT NULL,
  `receiving_time` time NOT NULL,
  `inspection_status` enum('Pending','In Progress','Completed','Failed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `status` enum('Draft','Completed','Cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Draft',
  `total_items` int(11) DEFAULT 0,
  `total_ordered` decimal(10,2) DEFAULT 0.00,
  `total_received` decimal(10,2) DEFAULT 0.00,
  `total_accepted` decimal(10,2) DEFAULT 0.00,
  `total_rejected` decimal(10,2) DEFAULT 0.00,
  `total_value` decimal(10,2) DEFAULT 0.00,
  `inspection_notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `evidence_files` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'JSON array of uploaded file paths',
  `inventory_updated` tinyint(1) DEFAULT 0 COMMENT 'Prevent duplicate inventory updates',
  `inventory_updated_at` datetime DEFAULT NULL,
  `completed_by` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `completed_by_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `cancelled_by` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancelled_by_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `cancellation_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `por_backup_20261003`
--

INSERT INTO `por_backup_20261003` (`id`, `por_number`, `purchase_order_id`, `po_number`, `receiving_id`, `supplier_id`, `supplier_name`, `received_by`, `received_by_name`, `receiving_date`, `receiving_time`, `inspection_status`, `status`, `total_items`, `total_ordered`, `total_received`, `total_accepted`, `total_rejected`, `total_value`, `inspection_notes`, `remarks`, `evidence_files`, `inventory_updated`, `inventory_updated_at`, `completed_by`, `completed_by_name`, `completed_at`, `cancelled_by`, `cancelled_by_name`, `cancelled_at`, `cancellation_reason`, `created_at`, `updated_at`) VALUES
('por_1791010048916_c4d25a', 'POR-2026-0001', 'demo_po_001', 'PO-2026-0001', NULL, 'SUP003', 'Cebu Fresh Foods Corp.', 'admin', 'System Admin', '2026-09-15 08:47:28', '08:47:28', 'In Progress', 'Draft', 3, 185.00, 179.00, 172.00, 7.00, 21695.00, 'Inspection in progress', 'Delivery on time', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-15 08:47:28', '2026-10-03 17:19:43'),
('por_1791010048923_c7d63e', 'POR-2026-0002', 'demo_po_002', 'PO-2026-0002', NULL, 'SUP004', 'Davao Meat Products Inc.', 'admin', 'System Admin', '2026-09-17 08:47:28', '08:47:28', 'Completed', 'Completed', 2, 92.00, 85.00, 77.00, 8.00, 5460.00, 'All items inspected and verified', NULL, NULL, 1, '2026-10-03 17:40:04', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-17 08:47:28', '2026-10-03 17:40:04'),
('por_1791010048927_accb96', 'POR-2026-0003', 'demo_po_003', 'PO-2026-0003', 'demo_gr_001', 'SUP004', 'Davao Meat Products Inc.', 'admin', 'System Admin', '2026-09-21 08:47:28', '08:47:28', 'Pending', 'Completed', 3, 179.00, 173.00, 166.00, 7.00, 38955.00, 'Inspection in progress', 'Delivery on time', NULL, 1, '2026-10-03 17:40:04', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-21 08:47:28', '2026-10-03 17:40:04'),
('por_1791010048928_599f86', 'POR-2026-0004', 'purchase_orders_1790821891680_555a4d', 'PO-2026-0004', 'receivings_1790821914779_290034', 'SUP004', 'Davao Meat Products Inc.', 'admin', 'System Admin', '2026-09-19 08:47:28', '08:47:28', 'Pending', 'Draft', 4, 169.00, 156.00, 146.00, 10.00, 27190.00, 'Inspection in progress', 'Delivery on time', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-19 08:47:28', '2026-10-03 17:19:43'),
('por_1791010048929_75d99a', 'POR-2026-0005', 'purchase_orders_1790842339710_f058f7', 'PO-2026-0005', 'receivings_1790842448130_c9613c', 'SUP004', 'Davao Meat Products Inc.', 'admin', 'System Admin', '2026-09-04 08:47:28', '08:47:28', 'Pending', 'Draft', 2, 67.00, 64.00, 59.00, 5.00, 1395.00, 'Inspection in progress', 'Delivery on time', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-04 08:47:28', '2026-10-03 17:19:43'),
('por_1791010048930_f87a34', 'POR-2026-0006', 'purchase_orders_1790842821065_54212e', 'PO-2026-0006', 'receivings_1790842905741_a8a7a1', 'SUP003', 'Cebu Fresh Foods Corp.', 'admin', 'System Admin', '2026-09-04 08:47:28', '08:47:28', 'Completed', 'Completed', 2, 129.00, 124.00, 117.00, 7.00, 28350.00, 'All items inspected and verified', 'Delivery on time', NULL, 1, '2026-10-03 17:40:04', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-04 08:47:28', '2026-10-03 17:40:04'),
('por_1791010048931_a6b7a5', 'POR-2026-0007', 'purchase_orders_1790848211305_2566e1', 'PO-2026-0007', 'receivings_1790998132629_cbbfdf', 'SUP004', 'Davao Meat Products Inc.', 'admin', 'System Admin', '2026-09-28 08:47:28', '08:47:28', 'Completed', 'Completed', 4, 155.00, 151.00, 144.00, 7.00, 28340.00, 'All items inspected and verified', 'Delivery on time', NULL, 1, '2026-10-03 17:40:04', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-28 08:47:28', '2026-10-03 17:40:04'),
('por_1791010048932_212899', 'POR-2026-0008', 'purchase_orders_1790848308283_a5906f', 'PO-2026-0008', 'receivings_1790848399451_9e66af', 'SUP002', 'Quezon Wholesale Supplies', 'admin', 'System Admin', '2026-09-17 08:47:28', '08:47:28', 'Pending', 'Completed', 2, 103.00, 96.00, 92.00, 4.00, 28980.00, 'Inspection in progress', 'Delivery on time', NULL, 1, '2026-10-03 17:40:04', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-17 08:47:28', '2026-10-03 17:40:04');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` varchar(40) NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`data`)),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `sku_normalized` varchar(100) GENERATED ALWAYS AS (json_unquote(json_extract(`data`,'$.sku'))) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `data`, `created_at`, `updated_at`) VALUES
('DRK001', '{\"id\":\"DRK001\",\"name\":\"Welchs Grape\",\"sku\":\"DRK001\",\"category\":\"Beverages\",\"price\":55,\"stock\":248,\"reorderLevel\":15,\"status\":\"Overstock\",\"description\":\"Welch&#x27;s grape juice drink\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790950715_a4e736473623ec2a.jpg\",\"lastUpdated\":\"2026-10-04T12:05:42.000Z\",\"supplierId\":\"s2\",\"expirationDate\":\"2027-10-01\",\"batchNumber\":\"BT202608025\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":55,\"srp\":65,\"minimumStock\":15,\"maximumStock\":150}', '2026-10-01 02:20:38', '2026-10-04 18:05:42'),
('DRK002', '{\"id\":\"DRK002\",\"name\":\"Welchs Strawberry\",\"sku\":\"DRK002\",\"category\":\"Beverages\",\"price\":55,\"stock\":17,\"reorderLevel\":5,\"status\":\"Low Stock\",\"description\":\"Welch&#x27;s strawberry juice drink\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790950843_46487fd41327a8b7.jpg\",\"lastUpdated\":\"2026-10-03T21:48:16.000Z\",\"supplierId\":\"s2\",\"expirationDate\":\"2027-10-01\",\"batchNumber\":\"BT202608026\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":55,\"srp\":65,\"minimumStock\":5,\"maximumStock\":10}', '2026-10-01 02:20:38', '2026-10-04 03:48:16'),
('DRK003', '{\"id\":\"DRK003\",\"name\":\"Welchs Orange\",\"sku\":\"DRK003\",\"category\":\"Beverages\",\"price\":55,\"stock\":0,\"reorderLevel\":15,\"status\":\"Out of Stock\",\"description\":\"Welch&#x27;s orange juice drink\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790951438_1b4c65534e2e64c6.jpg\",\"lastUpdated\":\"2026-10-02T16:47:24.140Z\",\"supplierId\":\"s2\",\"expirationDate\":\"2027-10-01\",\"batchNumber\":\"BT202608027\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":55,\"srp\":65,\"minimumStock\":15,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-03 00:47:24'),
('DRK004', '{\"id\":\"DRK004\",\"name\":\"Pororo Apple\",\"sku\":\"DRK004\",\"category\":\"Beverages\",\"price\":45,\"stock\":45,\"reorderLevel\":15,\"status\":\"In Stock\",\"description\":\"Korean Pororo brand apple juice drink\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790951787_b8b14370d7aa0eb8.jpg\",\"lastUpdated\":\"2026-10-02T17:22:03.444Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-08-01\",\"batchNumber\":\"BT202608028\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":45,\"srp\":55,\"minimumStock\":15,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-03 01:22:03'),
('DRK005', '{\"id\":\"DRK005\",\"name\":\"Pororo Milk\",\"sku\":\"DRK005\",\"category\":\"Beverages\",\"price\":45,\"stock\":35,\"reorderLevel\":15,\"status\":\"In Stock\",\"description\":\"Korean Pororo brand milk drink\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790951861_c1112117803c98be.jpg\",\"lastUpdated\":\"2026-10-02T14:37:56.445Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-04-01\",\"batchNumber\":\"BT202608029\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":45,\"srp\":55,\"minimumStock\":15,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-02 22:37:56'),
('DRK006', '{\"id\":\"DRK006\",\"name\":\"Pororo Blueberry\",\"sku\":\"DRK006\",\"category\":\"Beverages\",\"price\":45,\"stock\":32,\"reorderLevel\":15,\"status\":\"In Stock\",\"description\":\"Korean Pororo brand blueberry juice drink\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790952317_0a71807e5ef3e2bd.jpg\",\"lastUpdated\":\"2026-10-02T14:45:33.310Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-08-01\",\"batchNumber\":\"BT202608030\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":45,\"srp\":55,\"minimumStock\":15,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-02 22:45:33'),
('DRK007', '{\"id\":\"DRK007\",\"name\":\"Ice talk Peach\",\"sku\":\"DRK007\",\"category\":\"Beverages\",\"price\":45,\"stock\":25,\"reorderLevel\":10,\"status\":\"In Stock\",\"description\":\"Korean Coldtalk premium peach drink\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790952536_eb1a2d89bf2ef9bf.jpg\",\"lastUpdated\":\"2026-10-02T14:58:08.973Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-06-01\",\"batchNumber\":\"BT202608031\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":45,\"srp\":55,\"minimumStock\":10,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-02 22:58:08'),
('DRK008', '{\"id\":\"DRK008\",\"name\":\"Ice talk Grape\",\"sku\":\"DRK008\",\"category\":\"Beverages\",\"price\":45,\"stock\":25,\"reorderLevel\":10,\"status\":\"In Stock\",\"description\":\"Korean Coldtalk premium grape drink\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790952687_a600f6642242f94d.jpg\",\"lastUpdated\":\"2026-10-02T14:58:18.813Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-06-01\",\"batchNumber\":\"BT202608032\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":45,\"srp\":55,\"minimumStock\":10,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-02 22:58:18'),
('DRK009', '{\"id\":\"DRK009\",\"name\":\"Ice talk Watermelon\",\"sku\":\"DRK009\",\"category\":\"Beverages\",\"price\":45,\"stock\":20,\"reorderLevel\":10,\"status\":\"Low Stock\",\"description\":\"Korean Coldtalk premium lychee drink\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790953029_9f6512e1f96f9ac9.png\",\"lastUpdated\":\"2026-10-02T14:58:36.541Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-06-01\",\"batchNumber\":\"BT202608033\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":45,\"srp\":55,\"minimumStock\":10,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-03 00:48:31'),
('MEAT001', '{\"id\":\"MEAT001\",\"name\":\"Beef Bulgogi (500g)\",\"sku\":\"MEAT001\",\"category\":\"Frozen Foods\",\"price\":320,\"stock\":210,\"reorderLevel\":5,\"status\":\"Low Stock\",\"description\":\"Marinated Korean beef bulgogi, frozen\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790956697_6b140ea03467e1d2.webp\",\"lastUpdated\":\"2026-10-03T11:40:04.000Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-04-01\",\"batchNumber\":\"BT202608013\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":320,\"srp\":350,\"minimumStock\":5,\"maximumStock\":30}', '2026-10-01 02:20:38', '2026-10-03 17:40:04'),
('MEAT002', '{\"id\":\"MEAT002\",\"name\":\"Lotte Luncheon Meat (340g)\",\"sku\":\"MEAT002\",\"category\":\"Frozen Foods\",\"price\":120,\"stock\":57,\"reorderLevel\":10,\"status\":\"In Stock\",\"description\":\"Korean premium luncheon meat\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790956802_9db156e376736cab.png\",\"lastUpdated\":\"2026-10-03T11:40:04.000Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2028-04-01\",\"batchNumber\":\"BT202608014\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":120,\"srp\":150,\"minimumStock\":10,\"maximumStock\":40}', '2026-10-01 02:20:38', '2026-10-03 17:40:04'),
('MEAT003', '{\"id\":\"MEAT003\",\"name\":\"Korean Sausage\",\"sku\":\"MEAT003\",\"category\":\"Frozen Foods\",\"price\":220,\"stock\":72,\"reorderLevel\":5,\"status\":\"Low Stock\",\"description\":\"Traditional Korean style sausage\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790956954_87b1dfbbc1ce35c5.jpg\",\"lastUpdated\":\"2026-10-03T11:40:04.000Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-01-01\",\"batchNumber\":\"BT202608016\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":220,\"srp\":250,\"minimumStock\":5,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-03 17:40:04'),
('OIL001', '{\"id\":\"OIL001\",\"name\":\"Sesame Oil (1L)\",\"sku\":\"OIL001\",\"category\":\"Sauces &amp; Condiments\",\"price\":450,\"stock\":156,\"reorderLevel\":5,\"status\":\"Low Stock\",\"description\":\"Premium Korean sesame oil for cooking\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790953184_5eeeae4d56684f55.jpg\",\"lastUpdated\":\"2026-10-03T11:40:04.000Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2028-10-01\",\"batchNumber\":\"BT202608017\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":450,\"srp\":500,\"minimumStock\":5,\"maximumStock\":30}', '2026-10-01 02:20:38', '2026-10-03 17:40:04'),
('p1', '{\"id\":\"p1\",\"name\":\"Samyang Buldak Original\",\"sku\":\"SB-001\",\"category\":\"Instant Noodles\",\"price\":65,\"stock\":81,\"reorderLevel\":20,\"status\":\"In Stock\",\"description\":\"Korean fire noodles with spicy chicken flavor\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790957027_5f5c9ba83078449b.webp\",\"lastUpdated\":\"2026-10-03T11:40:04.000Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-06-01\",\"batchNumber\":\"BATCH-2026-0001\",\"archived\":false,\"brand\":\"Samyang\",\"origin\":\"South Korea\",\"unitWeight\":\"140g\",\"packSize\":\"5pcs\",\"unit\":\"Piece\",\"costingPrice\":65,\"srp\":75,\"minimumStock\":20,\"maximumStock\":100}', '2026-10-01 02:21:06', '2026-10-03 17:40:04'),
('p10', '{\"id\":\"p10\",\"name\":\"Korean Seaweed Snack\",\"sku\":\"KS-010\",\"category\":\"Snacks\",\"price\":95,\"stock\":55,\"reorderLevel\":20,\"status\":\"In Stock\",\"description\":\"Crispy roasted seaweed with sesame oil\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790958815_c6be0efdbc5b85ba.jpg\",\"lastUpdated\":\"2026-10-02T16:34:19.573Z\",\"supplierId\":\"s3\",\"expirationDate\":\"2027-10-01\",\"batchNumber\":\"BATCH-2026-0010\",\"archived\":false,\"brand\":\"Kwangcheon\",\"origin\":\"South Korea\",\"unitWeight\":\"4.5g\",\"packSize\":\"12pcs\",\"unit\":\"Piece\",\"costingPrice\":95,\"srp\":125,\"minimumStock\":20,\"maximumStock\":100}', '2026-10-01 02:21:06', '2026-10-03 00:34:19'),
('p2', '{\"id\":\"p2\",\"name\":\"Shin Ramyun\",\"sku\":\"SR-002\",\"category\":\"Instant Noodles\",\"price\":75,\"stock\":32,\"reorderLevel\":15,\"status\":\"In Stock\",\"description\":\"Premium spicy Korean ramen with beef flavor\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790957064_1c2e7a2f2214c978.jpg\",\"lastUpdated\":\"2026-10-02T16:04:52.357Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-08-01\",\"batchNumber\":\"BATCH-2026-0002\",\"archived\":false,\"brand\":\"Nongshim\",\"origin\":\"South Korea\",\"unitWeight\":\"120g\",\"packSize\":\"5pcs\",\"unit\":\"Piece\",\"costingPrice\":75,\"srp\":85,\"minimumStock\":15,\"maximumStock\":100}', '2026-10-01 02:21:06', '2026-10-03 00:04:52'),
('p3', '{\"id\":\"p3\",\"name\":\"Ottogi Jin Ramen Spicy\",\"sku\":\"OJ-003\",\"category\":\"Instant Noodles\",\"price\":50,\"stock\":28,\"reorderLevel\":20,\"status\":\"In Stock\",\"description\":\"Mild Korean ramen with savory beef broth\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790957167_69cdba400b4c13dc.jpg\",\"lastUpdated\":\"2026-10-02T16:06:22.077Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-07-01\",\"batchNumber\":\"BATCH-2026-0003\",\"archived\":false,\"brand\":\"Ottogi\",\"origin\":\"South Korea\",\"unitWeight\":\"120g\",\"packSize\":\"5pcs\",\"unit\":\"Piece\",\"costingPrice\":50,\"srp\":60,\"minimumStock\":20,\"maximumStock\":100}', '2026-10-01 02:21:06', '2026-10-03 00:06:22'),
('p4', '{\"id\":\"p4\",\"name\":\"Samyang Buldak Carbonara\",\"sku\":\"SC-004\",\"category\":\"Instant Noodles\",\"price\":68,\"stock\":22,\"reorderLevel\":15,\"status\":\"In Stock\",\"description\":\"Creamy carbonara version of the famous fire noodles\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790957246_a90a6caee901e8bc.png\",\"lastUpdated\":\"2026-10-02T16:07:39.980Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-06-01\",\"batchNumber\":\"BATCH-2026-0004\",\"archived\":false,\"brand\":\"Samyang\",\"origin\":\"South Korea\",\"unitWeight\":\"130g\",\"packSize\":\"5pcs\",\"unit\":\"Piece\",\"costingPrice\":68,\"srp\":78,\"minimumStock\":15,\"maximumStock\":50}', '2026-10-01 02:21:06', '2026-10-03 00:07:40'),
('p5', '{\"id\":\"p5\",\"name\":\"Nongshim Neoguri\",\"sku\":\"NN-005\",\"category\":\"Instant Noodles\",\"price\":72,\"stock\":43,\"reorderLevel\":12,\"status\":\"In Stock\",\"description\":\"Thick udon-style Korean ramen with seafood flavor\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790957293_73bbf82dd302165e.jpg\",\"lastUpdated\":\"2026-10-03T13:09:08.088Z\",\"supplierId\":\"s2\",\"expirationDate\":\"2027-09-01\",\"batchNumber\":\"BATCH-2026-0005\",\"archived\":false,\"brand\":\"Nongshim\",\"origin\":\"South Korea\",\"unitWeight\":\"120g\",\"packSize\":\"5pcs\",\"unit\":\"Piece\",\"costingPrice\":72,\"srp\":82,\"minimumStock\":12,\"maximumStock\":50}', '2026-10-01 02:21:06', '2026-10-03 21:09:08'),
('p6', '{\"id\":\"p6\",\"name\":\"Nongshim Chapagetti\",\"sku\":\"NC-006\",\"category\":\"Instant Noodles\",\"price\":69,\"stock\":55,\"reorderLevel\":18,\"status\":\"In Stock\",\"description\":\"Korean black bean sauce noodles (jajangmyeon)\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790957391_76a076262599719c.jpg\",\"lastUpdated\":\"2026-10-03T13:09:08.137Z\",\"supplierId\":\"s2\",\"expirationDate\":\"2027-08-01\",\"batchNumber\":\"BATCH-2026-0006\",\"archived\":false,\"brand\":\"Nongshim\",\"origin\":\"South Korea\",\"unitWeight\":\"140g\",\"packSize\":\"5pcs\",\"unit\":\"Piece\",\"costingPrice\":69,\"srp\":79,\"minimumStock\":18,\"maximumStock\":100}', '2026-10-01 02:21:06', '2026-10-03 21:09:08'),
('p7', '{\"id\":\"p7\",\"name\":\"Korean Soju - Chamisul\",\"sku\":\"CS-007\",\"category\":\"Beverages\",\"price\":180,\"stock\":24,\"reorderLevel\":10,\"status\":\"In Stock\",\"description\":\"Premium Korean soju, smooth and clean taste\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790957447_a3e6a767d8805124.webp\",\"lastUpdated\":\"2026-10-02T16:11:06.996Z\",\"supplierId\":\"s3\",\"expirationDate\":\"2028-10-01\",\"batchNumber\":\"BATCH-2026-0007\",\"archived\":false,\"brand\":\"Jinro\",\"origin\":\"South Korea\",\"unitWeight\":\"360ml\",\"packSize\":\"1 bottle\",\"unit\":\"Piece\",\"costingPrice\":180,\"srp\":210,\"minimumStock\":10,\"maximumStock\":50}', '2026-10-01 02:21:06', '2026-10-03 00:11:07'),
('p8', '{\"id\":\"p8\",\"name\":\"Korean Kimchi - Napa Cabbage\",\"sku\":\"KK-008\",\"category\":\"Kimchi &amp; Pickled\",\"price\":250,\"stock\":15,\"reorderLevel\":8,\"status\":\"Low Stock\",\"description\":\"Authentic Korean fermented cabbage kimchi\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790957608_2ff2a51a21e77a0a.jpg\",\"lastUpdated\":\"2026-10-02T16:13:52.077Z\",\"supplierId\":\"s3\",\"expirationDate\":\"2027-01-01\",\"batchNumber\":\"BATCH-2026-0008\",\"archived\":false,\"brand\":\"Dongwon\",\"origin\":\"South Korea\",\"unitWeight\":\"500g\",\"packSize\":\"1 jar\",\"unit\":\"Piece\",\"costingPrice\":250,\"srp\":270,\"minimumStock\":8,\"maximumStock\":100}', '2026-10-01 02:21:06', '2026-10-03 00:48:31'),
('p9', '{\"id\":\"p9\",\"name\":\"Japanese Sushi Rice\",\"sku\":\"JSR-009\",\"category\":\"Rice &amp; Pantry\",\"price\":320,\"stock\":12,\"reorderLevel\":8,\"status\":\"Low Stock\",\"description\":\"Premium short-grain Japanese sushi rice\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790958199_9abd01bb189f8514.jpg\",\"lastUpdated\":\"2026-10-02T16:23:33.692Z\",\"supplierId\":\"s4\",\"expirationDate\":\"2028-04-01\",\"batchNumber\":\"BATCH-2026-0009\",\"archived\":false,\"brand\":\"Koshihikari\",\"origin\":\"Japan\",\"unitWeight\":\"2kg\",\"packSize\":\"1 bag\",\"unit\":\"Piece\",\"costingPrice\":320,\"srp\":350,\"minimumStock\":8,\"maximumStock\":100}', '2026-10-01 02:21:06', '2026-10-03 00:48:31'),
('PAN001', '{\"id\":\"PAN001\",\"name\":\"Kimchi (500g)\",\"sku\":\"PAN001\",\"category\":\"Rice &amp; Pantry\",\"price\":180,\"stock\":22,\"reorderLevel\":8,\"status\":\"In Stock\",\"description\":\"Traditional Korean fermented cabbage\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790953443_2df1a2acb6813045.jpg\",\"lastUpdated\":\"2026-10-02T15:04:25.429Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2026-12-01\",\"batchNumber\":\"BT202608019\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":180,\"srp\":240,\"minimumStock\":8,\"maximumStock\":30}', '2026-10-01 02:20:38', '2026-10-02 23:04:25'),
('PAN002', '{\"id\":\"PAN002\",\"name\":\"Nori Seaweed\",\"sku\":\"PAN002\",\"category\":\"Rice &amp; Pantry\",\"price\":80,\"stock\":40,\"reorderLevel\":15,\"status\":\"In Stock\",\"description\":\"Dried seaweed sheets for sushi and snacks\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790953664_9654a96b2e49b084.jpg\",\"lastUpdated\":\"2026-10-02T15:11:33.815Z\",\"supplierId\":\"s2\",\"expirationDate\":\"2027-10-01\",\"batchNumber\":\"BT202608020\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":80,\"srp\":120,\"minimumStock\":15,\"maximumStock\":50}', '2026-10-01 02:20:38', '2026-10-02 23:11:33'),
('RAM001', '{\"id\":\"RAM001\",\"name\":\"Samyang Buldak Cheese\",\"sku\":\"RAM001\",\"category\":\"Instant Noodles\",\"price\":55,\"stock\":50,\"reorderLevel\":15,\"status\":\"In Stock\",\"description\":\"Spicy Korean fire noodles with cheese flavor\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790953950_cf7893e012880294.jpg\",\"lastUpdated\":\"2026-10-02T15:12:44.253Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-10-01\",\"batchNumber\":\"BT202608001\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":55,\"srp\":65,\"minimumStock\":15,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-02 23:12:44'),
('RAM002', '{\"id\":\"RAM002\",\"name\":\"Samyang Buldak Quattro Cheese\",\"sku\":\"RAM002\",\"category\":\"Instant Noodles\",\"price\":75,\"stock\":40,\"reorderLevel\":15,\"status\":\"In Stock\",\"description\":\"Premium spicy Korean noodles with four cheese blend\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790954011_25e1b6c40e817509.jpg\",\"lastUpdated\":\"2026-10-02T15:13:53.373Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-10-01\",\"batchNumber\":\"BT202608002\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":75,\"srp\":85,\"minimumStock\":15,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-02 23:13:53'),
('RAM003', '{\"id\":\"RAM003\",\"name\":\"Samyang Buldak Carbo\",\"sku\":\"RAM003\",\"category\":\"Instant Noodles\",\"price\":60,\"stock\":45,\"reorderLevel\":15,\"status\":\"In Stock\",\"description\":\"Spicy Korean noodles with carbonara flavor\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790954061_02d970d846b4f443.jpg\",\"lastUpdated\":\"2026-10-02T15:14:32.901Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-10-01\",\"batchNumber\":\"BT202608003\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":60,\"srp\":75,\"minimumStock\":15,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-02 23:14:32'),
('RAM004', '{\"id\":\"RAM004\",\"name\":\"Samyang Buldak Cream Carbo\",\"sku\":\"RAM004\",\"category\":\"Instant Noodles\",\"price\":65,\"stock\":35,\"reorderLevel\":15,\"status\":\"In Stock\",\"description\":\"Premium spicy noodles with creamy carbonara sauce\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790954099_4e2d40143a644a50.webp\",\"lastUpdated\":\"2026-10-02T15:15:30.229Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-10-01\",\"batchNumber\":\"BT202608004\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":65,\"srp\":75,\"minimumStock\":15,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-02 23:15:30'),
('RAM005', '{\"id\":\"RAM005\",\"name\":\"Samyang Buldak Rose\",\"sku\":\"RAM005\",\"category\":\"Instant Noodles\",\"price\":75,\"stock\":30,\"reorderLevel\":15,\"status\":\"In Stock\",\"description\":\"Spicy Korean noodles with rose tteokbokki flavor\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790954162_20a1b71c399db8ad.jpg\",\"lastUpdated\":\"2026-10-02T15:16:15.053Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-10-01\",\"batchNumber\":\"BT202608005\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":75,\"srp\":85,\"minimumStock\":15,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-02 23:16:15'),
('RAM006', '{\"id\":\"RAM006\",\"name\":\"Samyang Buldak Black Original\",\"sku\":\"RAM006\",\"category\":\"Instant Noodles\",\"price\":55,\"stock\":55,\"reorderLevel\":15,\"status\":\"In Stock\",\"description\":\"Original extremely spicy Korean fire noodles\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790954209_b2466cc9900bef7e.png\",\"lastUpdated\":\"2026-10-02T15:17:01.189Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-10-01\",\"batchNumber\":\"BT202608006\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":55,\"srp\":65,\"minimumStock\":15,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-02 23:17:01'),
('RAM007', '{\"id\":\"RAM007\",\"name\":\"Ottogi Cheese Ramen\",\"sku\":\"RAM007\",\"category\":\"Instant Noodles\",\"price\":55,\"stock\":40,\"reorderLevel\":15,\"status\":\"In Stock\",\"description\":\"Korean cheese flavored instant ramen\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790954362_bcb2e8c8fad58e2d.jpg\",\"lastUpdated\":\"2026-10-02T15:19:32.861Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-10-01\",\"batchNumber\":\"BT202608007\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":55,\"srp\":65,\"minimumStock\":15,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-02 23:19:32'),
('RAM008', '{\"id\":\"RAM008\",\"name\":\"Ottogi Cheese Stir Fry\",\"sku\":\"RAM008\",\"category\":\"Instant Noodles\",\"price\":65,\"stock\":30,\"reorderLevel\":15,\"status\":\"In Stock\",\"description\":\"Korean cheese stir-fried noodles\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790954397_e82bd9c797649dd8.jpg\",\"lastUpdated\":\"2026-10-02T15:24:54.108Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-10-01\",\"batchNumber\":\"BT202608008\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":65,\"srp\":75,\"minimumStock\":15,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-02 23:24:54'),
('RAM009', '{\"id\":\"RAM009\",\"name\":\"Jin Ramen Spicy\",\"sku\":\"RAM009\",\"category\":\"Instant Noodles\",\"price\":45,\"stock\":60,\"reorderLevel\":20,\"status\":\"In Stock\",\"description\":\"Classic Korean spicy instant ramen\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790954533_6a7c6172e1582ba1.jpg\",\"lastUpdated\":\"2026-10-02T15:22:21.836Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-10-01\",\"batchNumber\":\"BT202608009\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":45,\"srp\":55,\"minimumStock\":20,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-02 23:22:21'),
('RAM010', '{\"id\":\"RAM010\",\"name\":\"Jin Ramen Mild\",\"sku\":\"RAM010\",\"category\":\"Instant Noodles\",\"price\":45,\"stock\":50,\"reorderLevel\":20,\"status\":\"In Stock\",\"description\":\"Classic Korean mild instant ramen\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790954821_4e93bdd15870bf00.jpg\",\"lastUpdated\":\"2026-10-02T15:27:12.966Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-10-01\",\"batchNumber\":\"BT202608010\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":45,\"srp\":55,\"minimumStock\":20,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-02 23:27:13'),
('RAM011', '{\"id\":\"RAM011\",\"name\":\"Shin Ramyun\",\"sku\":\"RAM011\",\"category\":\"Instant Noodles\",\"price\":60,\"stock\":45,\"reorderLevel\":15,\"status\":\"In Stock\",\"description\":\"Popular Korean spicy beef flavor ramen\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790954934_f57e09025eb6798d.jpg\",\"lastUpdated\":\"2026-10-02T15:29:06.253Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-10-01\",\"batchNumber\":\"BT202608011\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":60,\"srp\":70,\"minimumStock\":15,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-02 23:29:06'),
('RAM012', '{\"id\":\"RAM012\",\"name\":\"Shin Black\",\"sku\":\"RAM012\",\"category\":\"Instant Noodles\",\"price\":95,\"stock\":25,\"reorderLevel\":10,\"status\":\"In Stock\",\"description\":\"Premium Korean spicy ramen with beef bone broth\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790955039_d69992afdbb18f82.jpg\",\"lastUpdated\":\"2026-10-02T15:32:53.556Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-10-01\",\"batchNumber\":\"BT202608012\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":95,\"srp\":120,\"minimumStock\":10,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-02 23:32:53'),
('SAU001', '{\"id\":\"SAU001\",\"name\":\"Bulgogi Sauce\",\"sku\":\"SAU001\",\"category\":\"Sauces &amp; Condiments\",\"price\":160,\"stock\":181,\"reorderLevel\":10,\"status\":\"In Stock\",\"description\":\"Korean bulgogi marinade and sauce\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790955496_c59600326e30b759.png\",\"lastUpdated\":\"2026-10-03T11:40:04.000Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2028-04-01\",\"batchNumber\":\"BT202608018\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":160,\"srp\":180,\"minimumStock\":10,\"maximumStock\":30}', '2026-10-01 02:20:38', '2026-10-03 17:40:04'),
('SEA001', '{\"id\":\"SEA001\",\"name\":\"Fish Cake (500g)\",\"sku\":\"SEA001\",\"category\":\"Frozen Foods\",\"price\":170,\"stock\":25,\"reorderLevel\":8,\"status\":\"In Stock\",\"description\":\"Korean fish cake for soup and hot pot\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790956260_bcef6e02cb4f7f22.webp\",\"lastUpdated\":\"2026-10-02T15:52:29.589Z\",\"supplierId\":\"s2\",\"expirationDate\":\"2027-02-01\",\"batchNumber\":\"BT202608015\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":170,\"srp\":190,\"minimumStock\":8,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-02 23:52:29'),
('SNK001', '{\"id\":\"SNK001\",\"name\":\"Pepero\",\"sku\":\"SNK001\",\"category\":\"Snacks\",\"price\":55,\"stock\":60,\"reorderLevel\":20,\"status\":\"In Stock\",\"description\":\"Korean chocolate covered biscuit sticks\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790956382_27046628550490cf.webp\",\"lastUpdated\":\"2026-10-02T15:53:24.037Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-07-01\",\"batchNumber\":\"BT202608021\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":55,\"srp\":65,\"minimumStock\":20,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-02 23:53:24'),
('SNK002', '{\"id\":\"SNK002\",\"name\":\"Lotte Binch\",\"sku\":\"SNK002\",\"category\":\"Snacks\",\"price\":130,\"stock\":30,\"reorderLevel\":10,\"status\":\"In Stock\",\"description\":\"Korean premium chocolate snack\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790956477_f86bd7beb0a35777.jpg\",\"lastUpdated\":\"2026-10-02T15:54:55.679Z\",\"supplierId\":\"s1\",\"expirationDate\":\"2027-06-01\",\"batchNumber\":\"BT202608022\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":130,\"srp\":150,\"minimumStock\":10,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-02 23:54:55'),
('SNK003', '{\"id\":\"SNK003\",\"name\":\"Snickers\",\"sku\":\"SNK003\",\"category\":\"Snacks\",\"price\":45,\"stock\":50,\"reorderLevel\":20,\"status\":\"In Stock\",\"description\":\"Classic chocolate bar with peanuts and caramel\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790956523_0d1ab0371c090ea0.png\",\"lastUpdated\":\"2026-10-02T15:55:34.372Z\",\"supplierId\":\"s2\",\"expirationDate\":\"2027-04-01\",\"batchNumber\":\"BT202608023\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":45,\"srp\":55,\"minimumStock\":20,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-02 23:55:34'),
('SNK004', '{\"id\":\"SNK004\",\"name\":\"Mars\",\"sku\":\"SNK004\",\"category\":\"Snacks\",\"price\":45,\"stock\":45,\"reorderLevel\":20,\"status\":\"In Stock\",\"description\":\"Chocolate bar with caramel and nougat\",\"image\":\"uploads&#x2F;product-images&#x2F;product_1790956580_6bb29a235c9dbb82.jpg\",\"lastUpdated\":\"2026-10-02T15:56:32.165Z\",\"supplierId\":\"s2\",\"expirationDate\":\"2027-04-01\",\"batchNumber\":\"BT202608024\",\"archived\":false,\"unit\":\"Piece\",\"costingPrice\":45,\"srp\":55,\"minimumStock\":20,\"maximumStock\":100}', '2026-10-01 02:20:38', '2026-10-02 23:56:32');

-- --------------------------------------------------------

--
-- Table structure for table `proof_of_delivery`
--

CREATE TABLE `proof_of_delivery` (
  `id` varchar(40) NOT NULL,
  `transfer_id` varchar(40) NOT NULL,
  `transfer_number` varchar(50) NOT NULL,
  `qr_token` varchar(100) NOT NULL,
  `scanned_at` datetime DEFAULT NULL,
  `scanned_by` varchar(100) DEFAULT NULL,
  `received_by` varchar(100) DEFAULT NULL,
  `received_at` datetime DEFAULT NULL,
  `confirmation_notes` text DEFAULT NULL,
  `signature_data` text DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'Pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `proof_of_delivery`
--

INSERT INTO `proof_of_delivery` (`id`, `transfer_id`, `transfer_number`, `qr_token`, `scanned_at`, `scanned_by`, `received_by`, `received_at`, `confirmation_notes`, `signature_data`, `status`, `created_at`, `updated_at`) VALUES
('pod_1791109835275_5d6343', 'st_1791109197384_3e3715', 'ST-2026-2778', 'POD-36BD9830B7C39201', NULL, NULL, NULL, NULL, NULL, NULL, 'Pending', '2026-10-04 18:30:35', '2026-10-04 18:30:35'),
('pod_1791110554561_6c9bfd', 'st_1791110554559_4475a3', 'ST-DEMO-124234', 'POD-39A9B477F1F98F6E', NULL, NULL, 'Staff User', '2026-10-04 18:42:34', 'All items received in good condition - LOCAL DEMO', NULL, 'Received', '2026-10-04 18:42:34', '2026-10-04 18:42:34'),
('pod_test_1790943273', 'st_demo_003', 'ST-2026-0003', 'POD-23EB00422963F3E78A99FD34F0C65186', NULL, NULL, 'admin', '2026-10-02 20:14:33', 'Test delivery confirmation - all items received in good condition', NULL, 'Received', '2026-10-02 20:14:33', '2026-10-02 20:14:33');

-- --------------------------------------------------------

--
-- Table structure for table `proof_of_receiving`
--

CREATE TABLE `proof_of_receiving` (
  `id` varchar(40) NOT NULL,
  `por_number` varchar(50) NOT NULL,
  `purchase_order_id` varchar(40) NOT NULL,
  `po_number` varchar(50) NOT NULL,
  `receiving_id` varchar(40) DEFAULT NULL,
  `supplier_id` varchar(40) NOT NULL,
  `supplier_name` varchar(255) NOT NULL,
  `received_by` varchar(40) NOT NULL,
  `received_by_name` varchar(255) NOT NULL,
  `receiving_date` datetime NOT NULL,
  `receiving_time` time NOT NULL,
  `inspection_status` enum('Pending','In Progress','Completed','Failed') DEFAULT 'Pending',
  `status` enum('Draft','Completed','Cancelled') DEFAULT 'Draft',
  `total_items` int(11) DEFAULT 0,
  `total_ordered` decimal(10,2) DEFAULT 0.00,
  `total_received` decimal(10,2) DEFAULT 0.00,
  `total_accepted` decimal(10,2) DEFAULT 0.00,
  `total_rejected` decimal(10,2) DEFAULT 0.00,
  `total_value` decimal(10,2) DEFAULT 0.00,
  `inspection_notes` text DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `evidence_files` longtext DEFAULT NULL COMMENT 'JSON array of uploaded file paths',
  `inventory_updated` tinyint(1) DEFAULT 0 COMMENT 'Prevent duplicate inventory updates',
  `inventory_updated_at` datetime DEFAULT NULL,
  `completed_by` varchar(40) DEFAULT NULL,
  `completed_by_name` varchar(255) DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `cancelled_by` varchar(40) DEFAULT NULL,
  `cancelled_by_name` varchar(255) DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `cancellation_reason` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `proof_of_receiving`
--

INSERT INTO `proof_of_receiving` (`id`, `por_number`, `purchase_order_id`, `po_number`, `receiving_id`, `supplier_id`, `supplier_name`, `received_by`, `received_by_name`, `receiving_date`, `receiving_time`, `inspection_status`, `status`, `total_items`, `total_ordered`, `total_received`, `total_accepted`, `total_rejected`, `total_value`, `inspection_notes`, `remarks`, `evidence_files`, `inventory_updated`, `inventory_updated_at`, `completed_by`, `completed_by_name`, `completed_at`, `cancelled_by`, `cancelled_by_name`, `cancelled_at`, `cancellation_reason`, `created_at`, `updated_at`) VALUES
('por_1791099133652_bbd0a3', 'POR-2026-0001', 'purchase_orders_1791099110578_8f762f', 'PO-2026-0001', 'receiving_1791099133652_62562e', 's1', 'Seoul Food Distribution', 'u1', 'Admin User', '2026-10-04 09:32:13', '09:32:13', '', 'Completed', 1, 1.00, 1.00, 1.00, 0.00, 55.00, '', NULL, NULL, 1, '2026-10-04 09:32:13', 'u1', 'Admin User', '2026-10-04 09:32:13', NULL, NULL, NULL, NULL, '2026-10-04 15:32:13', '2026-10-04 15:32:13'),
('por_1791099457311_62b0ea', 'POR-2026-0002', 'purchase_orders_1791099449693_3bd2ef', 'PO-2026-0002', 'receiving_1791099457311_08bb3e', 's1', 'Seoul Food Distribution', 'u1', 'Admin User', '2026-10-04 09:37:37', '09:37:37', '', 'Completed', 1, 1.00, 1.00, 1.00, 0.00, 55.00, '', NULL, NULL, 1, '2026-10-04 09:37:37', 'u1', 'Admin User', '2026-10-04 09:37:37', NULL, NULL, NULL, NULL, '2026-10-04 15:37:37', '2026-10-04 15:37:37'),
('por_1791100675607_550eee', 'POR-2026-0003', 'purchase_orders_1791100667089_37dbdb', 'PO-2026-0003', 'receiving_1791100675607_cd3ff9', 's1', 'Seoul Food Distribution', 'u1', 'Admin User', '2026-10-04 09:57:55', '09:57:55', '', 'Completed', 1, 1.00, 1.00, 1.00, 0.00, 55.00, '', NULL, NULL, 1, '2026-10-04 09:57:55', 'u1', 'Admin User', '2026-10-04 09:57:55', NULL, NULL, NULL, NULL, '2026-10-04 15:57:55', '2026-10-04 15:57:55'),
('por_1791100707991_1bf342', 'POR-2026-0004', 'purchase_orders_1791100694238_6e3268', 'PO-2026-0004', 'receiving_1791100707991_f5eac4', 's1', 'Seoul Food Distribution', 'u1', 'Admin User', '2026-10-04 09:58:28', '09:58:28', 'Failed', 'Completed', 1, 1.00, 1.00, 0.00, 1.00, 0.00, '', NULL, NULL, 1, '2026-10-04 09:58:28', 'u1', 'Admin User', '2026-10-04 09:58:28', NULL, NULL, NULL, NULL, '2026-10-04 15:58:28', '2026-10-04 15:58:28'),
('por_1791100738784_825f4e', 'POR-2026-0005', 'purchase_orders_1791100725533_4b0c4f', 'PO-2026-0005', 'receiving_1791100738784_0d862f', 's1', 'Seoul Food Distribution', 'u1', 'Admin User', '2026-10-04 09:58:58', '09:58:58', 'Failed', 'Completed', 1, 1.00, 1.00, 0.00, 0.00, 0.00, '', NULL, NULL, 1, '2026-10-04 09:58:58', 'u1', 'Admin User', '2026-10-04 09:58:58', NULL, NULL, NULL, NULL, '2026-10-04 15:58:58', '2026-10-04 15:58:58'),
('por_1791108342900_949ff3', 'POR-2026-0006', 'purchase_orders_1791108329768_1a65a9', 'PO-2026-0006', 'receiving_1791108342900_3338ac', 's1', 'Seoul Food Distribution', 'u1', 'Admin User', '2026-10-04 12:05:42', '12:05:42', '', 'Completed', 1, 1.00, 1.00, 1.00, 0.00, 55.00, '', NULL, NULL, 1, '2026-10-04 12:05:42', 'u1', 'Admin User', '2026-10-04 12:05:42', NULL, NULL, NULL, NULL, '2026-10-04 18:05:42', '2026-10-04 18:05:42');

-- --------------------------------------------------------

--
-- Table structure for table `proof_of_receiving_items`
--

CREATE TABLE `proof_of_receiving_items` (
  `id` varchar(40) NOT NULL,
  `por_id` varchar(40) NOT NULL,
  `product_id` varchar(40) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `sku` varchar(100) DEFAULT NULL,
  `unit` varchar(50) DEFAULT 'pcs',
  `ordered_quantity` decimal(10,2) NOT NULL,
  `received_quantity` decimal(10,2) NOT NULL,
  `accepted_quantity` decimal(10,2) NOT NULL,
  `rejected_quantity` decimal(10,2) DEFAULT 0.00,
  `damaged_quantity` decimal(10,2) DEFAULT 0.00,
  `unit_cost` decimal(10,2) DEFAULT 0.00,
  `total_cost` decimal(10,2) DEFAULT 0.00,
  `batch_number` varchar(100) DEFAULT NULL,
  `lot_number` varchar(100) DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `manufacturing_date` date DEFAULT NULL,
  `inspection_result` enum('Pass','Fail','Conditional','Pending') DEFAULT 'Pending',
  `inspection_notes` text DEFAULT NULL,
  `rejection_reason` varchar(255) DEFAULT NULL,
  `damage_type` varchar(255) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `proof_of_receiving_items`
--

INSERT INTO `proof_of_receiving_items` (`id`, `por_id`, `product_id`, `product_name`, `sku`, `unit`, `ordered_quantity`, `received_quantity`, `accepted_quantity`, `rejected_quantity`, `damaged_quantity`, `unit_cost`, `total_cost`, `batch_number`, `lot_number`, `expiration_date`, `manufacturing_date`, `inspection_result`, `inspection_notes`, `rejection_reason`, `damage_type`, `remarks`, `created_at`, `updated_at`) VALUES
('por_item_1791099133652_dcf0d8', 'por_1791099133652_bbd0a3', 'DRK001', 'Welchs Grape', 'N/A', 'pcs', 1.00, 1.00, 1.00, 0.00, 0.00, 55.00, 55.00, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '2026-10-04 15:32:13', '2026-10-04 15:32:13'),
('por_item_1791099457311_d9d89c', 'por_1791099457311_62b0ea', 'DRK001', 'Welchs Grape', 'N/A', 'pcs', 1.00, 1.00, 1.00, 0.00, 0.00, 55.00, 55.00, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '2026-10-04 15:37:37', '2026-10-04 15:37:37'),
('por_item_1791100675607_439e01', 'por_1791100675607_550eee', 'DRK001', 'Welchs Grape', 'N/A', 'pcs', 1.00, 1.00, 1.00, 0.00, 0.00, 55.00, 55.00, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '2026-10-04 15:57:55', '2026-10-04 15:57:55'),
('por_item_1791100707991_d60a29', 'por_1791100707991_1bf342', 'DRK001', 'Welchs Grape', 'N/A', 'pcs', 1.00, 1.00, 0.00, 1.00, 0.00, 55.00, 0.00, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '2026-10-04 15:58:28', '2026-10-04 15:58:28'),
('por_item_1791100738784_47269a', 'por_1791100738784_825f4e', 'DRK001', 'Welchs Grape', 'N/A', 'pcs', 1.00, 1.00, 0.00, 0.00, 1.00, 55.00, 0.00, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '2026-10-04 15:58:58', '2026-10-04 15:58:58'),
('por_item_1791108342900_afbc05', 'por_1791108342900_949ff3', 'DRK001', 'Welchs Grape', 'N/A', 'pcs', 1.00, 1.00, 1.00, 0.00, 0.00, 55.00, 55.00, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '2026-10-04 18:05:42', '2026-10-04 18:05:42');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_orders`
--

CREATE TABLE `purchase_orders` (
  `id` varchar(40) NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`data`)),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `purchase_orders`
--

INSERT INTO `purchase_orders` (`id`, `data`, `created_at`, `updated_at`) VALUES
('purchase_orders_1791099110578_8f762f', '{\"poNumber\":\"PO-2026-0001\",\"supplier_name\":\"Seoul Food Distribution\",\"supplierId\":\"s1\",\"items\":[{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"quantity\":1,\"unitCost\":55,\"subtotal\":55,\"receivedQuantity\":0,\"remainingQuantity\":1}],\"subtotal\":55,\"total\":55,\"orderDate\":\"2026-10-04T07:31:50.562Z\",\"expectedDate\":null,\"status\":\"Received\",\"notes\":\"\",\"createdBy\":\"Admin User\",\"totalItems\":1,\"receivedItems\":1,\"remainingItems\":1,\"id\":\"purchase_orders_1791099110578_8f762f\",\"approvedBy\":\"Admin User\",\"approvedAt\":\"2026-10-04T07:31:53.372Z\",\"receivedDate\":\"2026-10-04T09:32:13.000Z\"}', '2026-10-04 15:31:50', '2026-10-04 15:32:13'),
('purchase_orders_1791099449693_3bd2ef', '{\"poNumber\":\"PO-2026-0002\",\"supplier_name\":\"Seoul Food Distribution\",\"supplierId\":\"s1\",\"items\":[{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"quantity\":1,\"unitCost\":55,\"subtotal\":55,\"receivedQuantity\":0,\"remainingQuantity\":1}],\"subtotal\":55,\"total\":55,\"orderDate\":\"2026-10-04T07:37:29.675Z\",\"expectedDate\":null,\"status\":\"Received\",\"notes\":\"\",\"createdBy\":\"Admin User\",\"totalItems\":1,\"receivedItems\":1,\"remainingItems\":1,\"id\":\"purchase_orders_1791099449693_3bd2ef\",\"approvedBy\":\"Admin User\",\"approvedAt\":\"2026-10-04T07:37:31.875Z\",\"receivedDate\":\"2026-10-04T09:37:37.000Z\"}', '2026-10-04 15:37:29', '2026-10-04 15:37:37'),
('purchase_orders_1791100667089_37dbdb', '{\"poNumber\":\"PO-2026-0003\",\"supplier_name\":\"Seoul Food Distribution\",\"supplierId\":\"s1\",\"items\":[{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"quantity\":1,\"unitCost\":55,\"subtotal\":55,\"receivedQuantity\":0,\"remainingQuantity\":1}],\"subtotal\":55,\"total\":55,\"orderDate\":\"2026-10-04T07:57:47.032Z\",\"expectedDate\":null,\"status\":\"Received\",\"notes\":\"\",\"createdBy\":\"Admin User\",\"totalItems\":1,\"receivedItems\":1,\"remainingItems\":1,\"id\":\"purchase_orders_1791100667089_37dbdb\",\"approvedBy\":\"Admin User\",\"approvedAt\":\"2026-10-04T07:57:49.769Z\",\"receivedDate\":\"2026-10-04T09:57:55.000Z\"}', '2026-10-04 15:57:47', '2026-10-04 15:57:55'),
('purchase_orders_1791100694238_6e3268', '{\"poNumber\":\"PO-2026-0004\",\"supplier_name\":\"Seoul Food Distribution\",\"supplierId\":\"s1\",\"items\":[{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"quantity\":1,\"unitCost\":55,\"subtotal\":55,\"receivedQuantity\":0,\"remainingQuantity\":1}],\"subtotal\":55,\"total\":55,\"orderDate\":\"2026-10-04T07:58:14.169Z\",\"expectedDate\":null,\"status\":\"Received\",\"notes\":\"\",\"createdBy\":\"Admin User\",\"totalItems\":1,\"receivedItems\":0,\"remainingItems\":1,\"id\":\"purchase_orders_1791100694238_6e3268\",\"approvedBy\":\"Admin User\",\"approvedAt\":\"2026-10-04T07:58:16.876Z\",\"receivedDate\":\"2026-10-04T09:58:28.000Z\"}', '2026-10-04 15:58:14', '2026-10-04 15:58:28'),
('purchase_orders_1791100725533_4b0c4f', '{\"poNumber\":\"PO-2026-0005\",\"supplier_name\":\"Seoul Food Distribution\",\"supplierId\":\"s1\",\"items\":[{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"quantity\":1,\"unitCost\":55,\"subtotal\":55,\"receivedQuantity\":0,\"remainingQuantity\":1}],\"subtotal\":55,\"total\":55,\"orderDate\":\"2026-10-04T07:58:45.485Z\",\"expectedDate\":null,\"status\":\"Received\",\"notes\":\"\",\"createdBy\":\"Admin User\",\"totalItems\":1,\"receivedItems\":0,\"remainingItems\":1,\"id\":\"purchase_orders_1791100725533_4b0c4f\",\"approvedBy\":\"Admin User\",\"approvedAt\":\"2026-10-04T07:58:49.120Z\",\"receivedDate\":\"2026-10-04T09:58:58.000Z\"}', '2026-10-04 15:58:45', '2026-10-04 15:58:58'),
('purchase_orders_1791108329768_1a65a9', '{\"poNumber\":\"PO-2026-0006\",\"supplier_name\":\"Seoul Food Distribution\",\"supplierId\":\"s1\",\"items\":[{\"productId\":\"DRK001\",\"productName\":\"Welchs Grape\",\"quantity\":1,\"unitCost\":55,\"subtotal\":55,\"receivedQuantity\":0,\"remainingQuantity\":1}],\"subtotal\":55,\"total\":55,\"orderDate\":\"2026-10-04T10:05:29.752Z\",\"expectedDate\":null,\"status\":\"Received\",\"notes\":\"\",\"createdBy\":\"Admin User\",\"totalItems\":1,\"receivedItems\":1,\"remainingItems\":1,\"id\":\"purchase_orders_1791108329768_1a65a9\",\"approvedBy\":\"Admin User\",\"approvedAt\":\"2026-10-04T10:05:38.424Z\",\"receivedDate\":\"2026-10-04T12:05:42.000Z\"}', '2026-10-04 18:05:29', '2026-10-04 18:05:42');

-- --------------------------------------------------------

--
-- Table structure for table `receivings`
--

CREATE TABLE `receivings` (
  `id` varchar(40) NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`data`)),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `receivings`
--

INSERT INTO `receivings` (`id`, `data`, `created_at`, `updated_at`) VALUES
('receiving_1791099133652_62562e', '{\"id\":\"receiving_1791099133652_62562e\",\"receivingNumber\":\"GR-2026-0001\",\"poId\":\"purchase_orders_1791099110578_8f762f\",\"poNumber\":\"PO-2026-0001\",\"supplierId\":\"s1\",\"supplier\":\"Seoul Food Distribution\",\"supplierName\":\"Seoul Food Distribution\",\"receivedDate\":\"2026-10-04T09:32:13.000Z\",\"receivedBy\":\"Admin User\",\"totalReceived\":1,\"totalAccepted\":1,\"totalRejected\":0,\"totalValue\":55,\"items\":[{\"product_id\":\"DRK001\",\"product_name\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"ordered_quantity\":1,\"received_quantity\":1,\"accepted_quantity\":1,\"rejected_quantity\":0,\"damaged_quantity\":0,\"unit_cost\":55,\"subtotal\":55,\"inspection_result\":\"Passed\",\"inspection_notes\":\"\",\"rejection_reason\":null,\"damage_type\":null}],\"inspectionStatus\":\"Passed\",\"notes\":\"\",\"status\":\"Completed\",\"porNumber\":\"POR-2026-0001\"}', '2026-10-04 15:32:13', '2026-10-04 15:32:13'),
('receiving_1791099457311_08bb3e', '{\"id\":\"receiving_1791099457311_08bb3e\",\"receivingNumber\":\"GR-2026-0002\",\"poId\":\"purchase_orders_1791099449693_3bd2ef\",\"poNumber\":\"PO-2026-0002\",\"supplierId\":\"s1\",\"supplier\":\"Seoul Food Distribution\",\"supplierName\":\"Seoul Food Distribution\",\"receivedDate\":\"2026-10-04T09:37:37.000Z\",\"receivedBy\":\"Admin User\",\"totalReceived\":1,\"totalAccepted\":1,\"totalRejected\":0,\"totalValue\":55,\"items\":[{\"product_id\":\"DRK001\",\"product_name\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"ordered_quantity\":1,\"received_quantity\":1,\"accepted_quantity\":1,\"rejected_quantity\":0,\"damaged_quantity\":0,\"unit_cost\":55,\"subtotal\":55,\"inspection_result\":\"Passed\",\"inspection_notes\":\"\",\"rejection_reason\":null,\"damage_type\":null}],\"inspectionStatus\":\"Passed\",\"notes\":\"\",\"status\":\"Completed\",\"porNumber\":\"POR-2026-0002\"}', '2026-10-04 15:37:37', '2026-10-04 15:37:37'),
('receiving_1791100675607_cd3ff9', '{\"id\":\"receiving_1791100675607_cd3ff9\",\"receivingNumber\":\"GR-2026-0003\",\"poId\":\"purchase_orders_1791100667089_37dbdb\",\"poNumber\":\"PO-2026-0003\",\"supplierId\":\"s1\",\"supplier\":\"Seoul Food Distribution\",\"supplierName\":\"Seoul Food Distribution\",\"receivedDate\":\"2026-10-04T09:57:55.000Z\",\"receivedBy\":\"Admin User\",\"totalReceived\":1,\"totalAccepted\":1,\"totalRejected\":0,\"totalValue\":55,\"items\":[{\"product_id\":\"DRK001\",\"product_name\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"ordered_quantity\":1,\"received_quantity\":1,\"accepted_quantity\":1,\"rejected_quantity\":0,\"damaged_quantity\":0,\"unit_cost\":55,\"subtotal\":55,\"inspection_result\":\"Passed\",\"inspection_notes\":\"\",\"rejection_reason\":null,\"damage_type\":null}],\"inspectionStatus\":\"Passed\",\"notes\":\"\",\"status\":\"Completed\",\"porNumber\":\"POR-2026-0003\"}', '2026-10-04 15:57:55', '2026-10-04 15:57:55'),
('receiving_1791100707991_f5eac4', '{\"id\":\"receiving_1791100707991_f5eac4\",\"receivingNumber\":\"GR-2026-0004\",\"poId\":\"purchase_orders_1791100694238_6e3268\",\"poNumber\":\"PO-2026-0004\",\"supplierId\":\"s1\",\"supplier\":\"Seoul Food Distribution\",\"supplierName\":\"Seoul Food Distribution\",\"receivedDate\":\"2026-10-04T09:58:27.000Z\",\"receivedBy\":\"Admin User\",\"totalReceived\":1,\"totalAccepted\":0,\"totalRejected\":1,\"totalValue\":0,\"items\":[{\"product_id\":\"DRK001\",\"product_name\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"ordered_quantity\":1,\"received_quantity\":1,\"accepted_quantity\":0,\"rejected_quantity\":1,\"damaged_quantity\":0,\"unit_cost\":55,\"subtotal\":0,\"inspection_result\":\"Failed\",\"inspection_notes\":\"\",\"rejection_reason\":null,\"damage_type\":null}],\"inspectionStatus\":\"Failed\",\"notes\":\"\",\"status\":\"Completed\",\"porNumber\":\"POR-2026-0004\"}', '2026-10-04 15:58:27', '2026-10-04 15:58:27'),
('receiving_1791100738784_0d862f', '{\"id\":\"receiving_1791100738784_0d862f\",\"receivingNumber\":\"GR-2026-0005\",\"poId\":\"purchase_orders_1791100725533_4b0c4f\",\"poNumber\":\"PO-2026-0005\",\"supplierId\":\"s1\",\"supplier\":\"Seoul Food Distribution\",\"supplierName\":\"Seoul Food Distribution\",\"receivedDate\":\"2026-10-04T09:58:58.000Z\",\"receivedBy\":\"Admin User\",\"totalReceived\":1,\"totalAccepted\":0,\"totalRejected\":0,\"totalValue\":0,\"items\":[{\"product_id\":\"DRK001\",\"product_name\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"ordered_quantity\":1,\"received_quantity\":1,\"accepted_quantity\":0,\"rejected_quantity\":0,\"damaged_quantity\":1,\"unit_cost\":55,\"subtotal\":0,\"inspection_result\":\"Failed\",\"inspection_notes\":\"\",\"rejection_reason\":null,\"damage_type\":null}],\"inspectionStatus\":\"Failed\",\"notes\":\"\",\"status\":\"Completed\",\"porNumber\":\"POR-2026-0005\"}', '2026-10-04 15:58:58', '2026-10-04 15:58:58'),
('receiving_1791108342900_3338ac', '{\"id\":\"receiving_1791108342900_3338ac\",\"receivingNumber\":\"GR-2026-0006\",\"poId\":\"purchase_orders_1791108329768_1a65a9\",\"poNumber\":\"PO-2026-0006\",\"supplierId\":\"s1\",\"supplier\":\"Seoul Food Distribution\",\"supplierName\":\"Seoul Food Distribution\",\"receivedDate\":\"2026-10-04T12:05:42.000Z\",\"receivedBy\":\"Admin User\",\"totalReceived\":1,\"totalAccepted\":1,\"totalRejected\":0,\"totalValue\":55,\"items\":[{\"product_id\":\"DRK001\",\"product_name\":\"Welchs Grape\",\"sku\":\"N\\/A\",\"ordered_quantity\":1,\"received_quantity\":1,\"accepted_quantity\":1,\"rejected_quantity\":0,\"damaged_quantity\":0,\"unit_cost\":55,\"subtotal\":55,\"inspection_result\":\"Passed\",\"inspection_notes\":\"\",\"rejection_reason\":null,\"damage_type\":null}],\"inspectionStatus\":\"Passed\",\"notes\":\"\",\"status\":\"Completed\",\"porNumber\":\"POR-2026-0006\"}', '2026-10-04 18:05:42', '2026-10-04 18:05:42');

-- --------------------------------------------------------

--
-- Table structure for table `security_logs`
--

CREATE TABLE `security_logs` (
  `id` int(11) NOT NULL,
  `event_type` varchar(100) NOT NULL,
  `user_id` varchar(40) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `ip_address` varchar(64) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `security_logs`
--

INSERT INTO `security_logs` (`id`, `event_type`, `user_id`, `username`, `details`, `ip_address`, `created_at`) VALUES
(1, 'LOGIN_FAILED', NULL, 'jeremiemugar7@gmail.com', '[]', '112.202.236.105', '2026-10-01 02:25:14'),
(2, 'LOGIN_FAILED', NULL, 'admin', '[]', '112.202.236.105', '2026-10-01 02:25:21'),
(3, 'LOGIN_FAILED', NULL, 'jeremiemugar7@gmail.com', '[]', '112.202.232.236', '2026-10-01 02:26:10'),
(4, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '112.202.246.6', '2026-10-01 02:30:47'),
(5, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '112.202.246.6', '2026-10-01 02:31:01'),
(6, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '112.202.246.6', '2026-10-01 02:31:02'),
(7, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '112.202.246.6', '2026-10-01 02:31:16'),
(8, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '112.202.246.6', '2026-10-01 02:31:59'),
(9, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '112.202.248.244', '2026-10-01 02:35:16'),
(10, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '112.202.248.244', '2026-10-01 02:35:22'),
(11, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '112.202.252.16', '2026-10-01 02:37:52'),
(12, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '175.158.206.208', '2026-10-01 08:10:23'),
(13, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '175.158.206.208', '2026-10-01 08:10:40'),
(14, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.208', '2026-10-01 08:10:41'),
(15, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.208', '2026-10-01 08:13:05'),
(16, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.208', '2026-10-01 08:13:19'),
(17, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.208', '2026-10-01 08:15:14'),
(18, 'AI_PREDICTIONS_GENERATED', 'u1', 'admin', '{\"count\":43}', '175.158.206.208', '2026-10-01 08:18:01'),
(19, 'AI_PREDICTIONS_GENERATED', 'u1', 'admin', '{\"count\":43}', '175.158.206.208', '2026-10-01 08:18:01'),
(20, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.208', '2026-10-01 08:21:23'),
(21, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.208', '2026-10-01 08:21:52'),
(22, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '175.158.206.208', '2026-10-01 08:28:05'),
(23, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '175.158.206.208', '2026-10-01 08:28:06'),
(24, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '175.158.206.208', '2026-10-01 08:28:42'),
(25, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.208', '2026-10-01 08:28:43'),
(26, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.208', '2026-10-01 08:28:51'),
(27, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.208', '2026-10-01 08:29:55'),
(28, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.204.128', '2026-10-01 09:06:18'),
(29, 'USER_UPDATED', 'u2', 'staff', '{\"updatedBy\":\"admin\"}', '175.158.204.128', '2026-10-01 09:08:28'),
(30, 'USER_UPDATED', 'u3', 'manager', '{\"updatedBy\":\"admin\"}', '175.158.204.128', '2026-10-01 09:09:09'),
(31, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.204.128', '2026-10-01 09:09:18'),
(32, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '175.158.203.211', '2026-10-01 09:49:10'),
(33, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '175.158.203.211', '2026-10-01 09:49:26'),
(34, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.203.211', '2026-10-01 09:49:26'),
(35, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.203.211', '2026-10-01 09:51:55'),
(36, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.203.211', '2026-10-01 09:52:21'),
(37, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.203.211', '2026-10-01 09:52:23'),
(38, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.203.211', '2026-10-01 09:53:27'),
(39, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.203.211', '2026-10-01 09:58:08'),
(40, 'AI_PREDICTIONS_GENERATED', 'u1', 'admin', '{\"count\":43}', '175.158.203.211', '2026-10-01 09:58:25'),
(41, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '175.158.203.211', '2026-10-01 10:14:16'),
(42, 'OTP_RESENT', 'u1', 'admin', '{\"mailed\":true}', '175.158.203.211', '2026-10-01 10:22:16'),
(43, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '175.158.203.211', '2026-10-01 10:22:30'),
(44, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.203.211', '2026-10-01 10:22:31'),
(45, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '175.158.206.102', '2026-10-01 12:09:57'),
(46, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '175.158.206.102', '2026-10-01 12:11:35'),
(47, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:11:39'),
(48, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:30:19'),
(49, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '175.158.206.102', '2026-10-01 12:30:20'),
(50, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '175.158.206.102', '2026-10-01 12:30:23'),
(51, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '175.158.206.102', '2026-10-01 12:30:50'),
(52, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:30:55'),
(53, 'AI_PREDICTIONS_GENERATED', 'u1', 'admin', '{\"count\":43}', '175.158.206.102', '2026-10-01 12:31:53'),
(54, 'AI_PREDICTIONS_GENERATED', 'u1', 'admin', '{\"count\":43}', '175.158.206.102', '2026-10-01 12:31:53'),
(55, 'AI_PREDICTIONS_GENERATED', 'u1', 'admin', '{\"count\":43}', '175.158.206.102', '2026-10-01 12:31:53'),
(56, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:31:55'),
(57, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:31:55'),
(58, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:32:04'),
(59, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:32:04'),
(60, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:32:51'),
(61, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:32:55'),
(62, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:32:59'),
(63, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:33:00'),
(64, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:33:00'),
(65, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:33:03'),
(66, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:33:03'),
(67, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:33:04'),
(68, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:33:04'),
(69, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:33:05'),
(70, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:33:06'),
(71, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:33:06'),
(72, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:33:07'),
(73, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:33:07'),
(74, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:44:43'),
(75, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:49:18'),
(76, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '175.158.206.102', '2026-10-01 12:56:25'),
(77, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '175.158.206.102', '2026-10-01 12:56:53'),
(78, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '175.158.206.102', '2026-10-01 12:56:53'),
(79, 'LOGIN_FAILED', NULL, 'alghazi', '[]', '27.49.10.162', '2026-10-01 15:20:36'),
(80, 'LOGIN_FAILED', NULL, 'alghazi', '[]', '27.49.10.162', '2026-10-01 15:20:44'),
(81, 'LOGIN_FAILED', NULL, 'alghazi', '[]', '27.49.10.162', '2026-10-01 15:20:44'),
(82, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '112.202.241.15', '2026-10-01 16:17:45'),
(83, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '112.202.241.15', '2026-10-01 16:17:58'),
(84, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '112.202.241.15', '2026-10-01 16:17:58'),
(85, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '112.202.254.174', '2026-10-01 16:28:29'),
(86, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '112.202.247.129', '2026-10-01 16:56:51'),
(87, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '::1', '2026-10-02 19:50:28'),
(88, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '::1', '2026-10-02 19:50:42'),
(89, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 19:50:42'),
(90, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 19:52:49'),
(91, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 19:55:49'),
(92, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 19:56:47'),
(93, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 19:58:38'),
(94, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 20:14:28'),
(95, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 20:20:39'),
(96, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 20:23:18'),
(97, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 20:23:46'),
(98, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 20:42:49'),
(99, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 21:03:15'),
(100, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 21:06:12'),
(101, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 21:19:21'),
(102, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 21:20:06'),
(103, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 21:37:28'),
(104, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 21:39:20'),
(105, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790949092_6c824e910cae99ca.jpg\",\"size\":187810,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 21:51:32'),
(106, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 21:51:36'),
(107, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790949108_c98139deded3b421.jpg\",\"size\":187810,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 21:51:48'),
(108, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 21:55:34'),
(109, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790949414_e04474e7471b004e.jpg\",\"size\":187810,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 21:56:54'),
(110, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 21:56:58'),
(111, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 21:57:00'),
(112, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790949668_bb03b5e894d3c3fc.jpg\",\"size\":187810,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 22:01:08'),
(113, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 22:01:11'),
(114, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790949681_57c1a7ea3896d761.jpg\",\"size\":187810,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 22:01:21'),
(115, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 22:07:38'),
(116, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790950064_969ec2646f8acab7.jpg\",\"size\":187810,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 22:07:44'),
(117, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 22:13:31'),
(118, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 22:14:08'),
(119, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790950457_f50ee67d00fb0eef.jpg\",\"size\":187810,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 22:14:17'),
(120, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790950467_960e82902795c938.jpg\",\"size\":187810,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 22:14:27'),
(121, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790950488_f4d0fab15bb52c10.jpg\",\"size\":187810,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 22:14:48'),
(122, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790950645_4db907cb01b40e83.jpg\",\"size\":187810,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 22:17:25'),
(123, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790950679_a3cc2b3e4759acbc.jpg\",\"size\":187810,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 22:17:59'),
(124, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790950715_a4e736473623ec2a.jpg\",\"size\":187810,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 22:18:35'),
(125, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790950843_46487fd41327a8b7.jpg\",\"size\":25222,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 22:20:43'),
(126, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790951112_c481bdddedc48c17.webp\",\"size\":22508,\"mime_type\":\"image\\/webp\"}', '::1', '2026-10-02 22:25:12'),
(127, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790951399_ef07b23800694dd7.jpg\",\"size\":55957,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 22:29:59'),
(128, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790951438_1b4c65534e2e64c6.jpg\",\"size\":53050,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 22:30:38'),
(129, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790951787_b8b14370d7aa0eb8.jpg\",\"size\":15576,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 22:36:27'),
(130, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790951861_c1112117803c98be.jpg\",\"size\":18892,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 22:37:41'),
(131, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 22:43:07'),
(132, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790952317_0a71807e5ef3e2bd.jpg\",\"size\":6738,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 22:45:17'),
(133, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790952536_eb1a2d89bf2ef9bf.jpg\",\"size\":19199,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 22:48:56'),
(134, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790952676_ce6c1df42c7c8149.jpg\",\"size\":17098,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 22:51:16'),
(135, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790952687_a600f6642242f94d.jpg\",\"size\":17098,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 22:51:27'),
(136, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 22:52:07'),
(137, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790953029_9f6512e1f96f9ac9.png\",\"size\":903696,\"mime_type\":\"image\\/png\"}', '::1', '2026-10-02 22:57:09'),
(138, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790953184_5eeeae4d56684f55.jpg\",\"size\":19414,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 22:59:44'),
(139, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 23:00:26'),
(140, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 23:01:39'),
(141, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 23:02:10'),
(142, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790953443_2df1a2acb6813045.jpg\",\"size\":197846,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 23:04:03'),
(143, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790953664_9654a96b2e49b084.jpg\",\"size\":82432,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 23:07:44'),
(144, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790953950_cf7893e012880294.jpg\",\"size\":44624,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 23:12:30'),
(145, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790954011_25e1b6c40e817509.jpg\",\"size\":35810,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 23:13:31'),
(146, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790954061_02d970d846b4f443.jpg\",\"size\":53975,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 23:14:21'),
(147, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790954099_4e2d40143a644a50.webp\",\"size\":92186,\"mime_type\":\"image\\/webp\"}', '::1', '2026-10-02 23:14:59'),
(148, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790954162_20a1b71c399db8ad.jpg\",\"size\":25889,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 23:16:02'),
(149, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790954209_b2466cc9900bef7e.png\",\"size\":167878,\"mime_type\":\"image\\/png\"}', '::1', '2026-10-02 23:16:49'),
(150, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790954362_bcb2e8c8fad58e2d.jpg\",\"size\":116210,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 23:19:22'),
(151, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790954397_e82bd9c797649dd8.jpg\",\"size\":44067,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 23:19:57'),
(152, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790954533_6a7c6172e1582ba1.jpg\",\"size\":43774,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 23:22:13'),
(153, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790954821_4e93bdd15870bf00.jpg\",\"size\":34586,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 23:27:01'),
(154, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790954934_f57e09025eb6798d.jpg\",\"size\":52532,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 23:28:54'),
(155, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790955039_d69992afdbb18f82.jpg\",\"size\":257283,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 23:30:39'),
(156, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790955464_644c032d351cc12a.jpg\",\"size\":37296,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 23:37:44'),
(157, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790955496_c59600326e30b759.png\",\"size\":617335,\"mime_type\":\"image\\/png\"}', '::1', '2026-10-02 23:38:16'),
(158, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 23:49:41'),
(159, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 23:49:59'),
(160, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 23:50:12'),
(161, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790956260_bcef6e02cb4f7f22.webp\",\"size\":87316,\"mime_type\":\"image\\/webp\"}', '::1', '2026-10-02 23:51:00'),
(162, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790956382_27046628550490cf.webp\",\"size\":58846,\"mime_type\":\"image\\/webp\"}', '::1', '2026-10-02 23:53:02'),
(163, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790956477_f86bd7beb0a35777.jpg\",\"size\":17435,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 23:54:37'),
(164, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790956523_0d1ab0371c090ea0.png\",\"size\":58963,\"mime_type\":\"image\\/png\"}', '::1', '2026-10-02 23:55:23'),
(165, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790956580_6bb29a235c9dbb82.jpg\",\"size\":74968,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-02 23:56:20'),
(166, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790956697_6b140ea03467e1d2.webp\",\"size\":50742,\"mime_type\":\"image\\/webp\"}', '::1', '2026-10-02 23:58:17'),
(167, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 23:59:13'),
(168, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 23:59:13'),
(169, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 23:59:24'),
(170, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-02 23:59:33'),
(171, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790956802_9db156e376736cab.png\",\"size\":92468,\"mime_type\":\"image\\/png\"}', '::1', '2026-10-03 00:00:02'),
(172, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790956954_87b1dfbbc1ce35c5.jpg\",\"size\":219766,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-03 00:02:34'),
(173, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790957027_5f5c9ba83078449b.webp\",\"size\":69718,\"mime_type\":\"image\\/webp\"}', '::1', '2026-10-03 00:03:47'),
(174, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790957064_1c2e7a2f2214c978.jpg\",\"size\":44196,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-03 00:04:24'),
(175, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790957167_69cdba400b4c13dc.jpg\",\"size\":41205,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-03 00:06:07'),
(176, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790957246_a90a6caee901e8bc.png\",\"size\":699555,\"mime_type\":\"image\\/png\"}', '::1', '2026-10-03 00:07:26'),
(177, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790957293_73bbf82dd302165e.jpg\",\"size\":13490,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-03 00:08:13'),
(178, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790957391_76a076262599719c.jpg\",\"size\":39165,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-03 00:09:51'),
(179, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790957447_a3e6a767d8805124.webp\",\"size\":42630,\"mime_type\":\"image\\/webp\"}', '::1', '2026-10-03 00:10:47'),
(180, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790957608_2ff2a51a21e77a0a.jpg\",\"size\":33219,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-03 00:13:28'),
(181, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790958199_9abd01bb189f8514.jpg\",\"size\":24828,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-03 00:23:19'),
(182, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790958248_6bc6763611b6f8b7.jpg\",\"size\":24828,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-03 00:24:08'),
(183, 'FILE_UPLOAD', 'u1', 'admin', '{\"type\":\"product\",\"filename\":\"product_1790958815_c6be0efdbc5b85ba.jpg\",\"size\":49200,\"mime_type\":\"image\\/jpeg\"}', '::1', '2026-10-03 00:33:35'),
(184, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 00:43:41'),
(185, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 01:11:15'),
(186, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 01:11:50'),
(187, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 01:14:16'),
(188, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 01:14:25'),
(189, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 01:15:47'),
(190, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 01:16:19'),
(191, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 01:16:25'),
(192, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 01:16:38'),
(193, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 01:18:37'),
(194, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 01:19:58'),
(195, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 01:21:07'),
(196, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 01:22:14'),
(197, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 01:29:32'),
(198, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 01:38:38'),
(199, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 01:54:03'),
(200, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '::1', '2026-10-03 02:13:57'),
(201, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '::1', '2026-10-03 02:14:44'),
(202, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 02:14:45'),
(203, 'LOGIN_FAILED', 'u1', 'jeremiemugar6@gmail.com', '[]', '::1', '2026-10-03 02:22:57'),
(204, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '::1', '2026-10-03 02:23:11'),
(205, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '::1', '2026-10-03 02:23:20'),
(206, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 02:23:21'),
(207, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 02:25:14'),
(208, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 02:28:31'),
(209, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 02:32:50'),
(210, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 02:34:15'),
(211, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 02:37:22'),
(212, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '::1', '2026-10-03 10:50:18'),
(213, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '::1', '2026-10-03 10:50:32'),
(214, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 10:50:32'),
(215, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 11:02:38'),
(216, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '::1', '2026-10-03 11:06:52'),
(217, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '::1', '2026-10-03 11:07:02'),
(218, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 11:07:03'),
(219, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 11:21:50'),
(220, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 11:28:37'),
(221, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 11:32:04'),
(222, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '::1', '2026-10-03 11:33:11'),
(223, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '::1', '2026-10-03 11:33:21'),
(224, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 11:33:21'),
(225, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 12:30:41'),
(226, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 12:30:47'),
(227, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '::1', '2026-10-03 12:36:42'),
(228, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '::1', '2026-10-03 12:36:50'),
(229, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 12:36:50'),
(230, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 12:47:49'),
(231, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 12:47:52'),
(232, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 12:47:53'),
(233, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 12:47:53'),
(234, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 12:47:53'),
(235, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 12:47:59'),
(236, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 12:48:00'),
(237, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 12:48:00'),
(238, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 12:48:00'),
(239, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 12:48:06'),
(240, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 12:48:06'),
(241, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 12:48:06'),
(242, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '::1', '2026-10-03 12:48:53'),
(243, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '::1', '2026-10-03 12:49:04'),
(244, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 12:49:04'),
(245, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 12:49:37'),
(246, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 12:49:37'),
(247, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 12:49:38'),
(248, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 12:49:38'),
(249, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 12:49:38'),
(250, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 12:55:54'),
(251, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 13:02:26'),
(252, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 13:02:26'),
(253, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 13:02:26'),
(254, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 13:02:27'),
(255, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '::1', '2026-10-03 13:06:05'),
(256, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '::1', '2026-10-03 13:58:57'),
(257, 'OTP_FAILED', 'u1', 'admin', '[]', '::1', '2026-10-03 14:05:03'),
(258, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '::1', '2026-10-03 14:05:22'),
(259, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 14:05:23'),
(260, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 14:13:01'),
(261, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 14:14:02'),
(262, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 14:27:52'),
(263, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 14:49:09'),
(264, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 15:29:00'),
(265, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 18:02:25'),
(266, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 18:18:54'),
(267, 'LOGIN_FAILED', 'u1', 'admin', '[]', '::1', '2026-10-03 18:27:18'),
(268, 'LOGIN_FAILED', 'u1', 'admin', '[]', '::1', '2026-10-03 18:28:48'),
(269, 'LOGIN_FAILED', NULL, 'juremiemugar6@gmail.com', '[]', '::1', '2026-10-03 18:28:56'),
(270, 'LOGIN_FAILED', NULL, 'juremiemugar6@gmail.com', '[]', '::1', '2026-10-03 18:29:44'),
(271, 'LOGIN_FAILED', 'u1', 'jeremiemugar6@gmail.com', '[]', '::1', '2026-10-03 18:30:36'),
(272, 'LOGIN_FAILED', 'u1', 'jeremiemugar6@gmail.com', '[]', '::1', '2026-10-03 18:31:25'),
(273, 'LOGIN_FAILED', 'u1', 'jeremiemugar6@gmail.com', '[]', '::1', '2026-10-03 18:31:51'),
(274, 'LOGIN_FAILED', 'u1', 'jeremiemugar6@gmail.com', '[]', '::1', '2026-10-03 18:33:17'),
(275, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 18:38:43'),
(276, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 18:39:24'),
(277, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 19:09:46'),
(278, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 19:10:50'),
(280, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 19:27:35'),
(281, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 19:50:32'),
(282, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 20:28:19'),
(283, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 20:34:19'),
(284, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 20:38:59'),
(285, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 20:39:50'),
(286, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 20:40:23'),
(287, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 21:08:56'),
(288, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 21:09:55'),
(289, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 21:13:15'),
(290, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 21:27:12'),
(291, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 21:28:09'),
(292, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 21:33:05'),
(293, 'LOGIN_FAILED', 'u1', 'jeremiemugar6@gmail.com', '[]', '::1', '2026-10-03 21:36:09'),
(294, 'LOGIN_FAILED', 'u1', 'jeremiemugar6@gmail.com', '[]', '::1', '2026-10-03 21:36:18'),
(295, 'LOGIN_FAILED', 'u1', 'jeremiemugar6@gmail.com', '[]', '::1', '2026-10-03 21:36:24'),
(296, 'LOGIN_FAILED', 'u1', 'jeremiemugar6@gmail.com', '[]', '::1', '2026-10-03 21:36:29'),
(297, 'LOGIN_FAILED', 'u1', 'jeremiemugar6@gmail.com', '[]', '::1', '2026-10-03 21:36:57'),
(298, 'LOGIN_BLOCKED_LOCKOUT', NULL, 'jeremiemugar6@gmail.com', '[]', '::1', '2026-10-03 21:37:23'),
(299, 'LOGIN_FAILED', 'u1', 'admin', '[]', '::1', '2026-10-03 21:37:41'),
(300, 'LOGIN_BLOCKED_LOCKOUT', NULL, 'jeremiemugar6@gmail.com', '[]', '::1', '2026-10-03 21:39:52'),
(301, 'LOGIN_FAILED', 'u1', 'admin', '[]', '::1', '2026-10-03 21:41:28'),
(302, 'LOGIN_FAILED', 'u2', 'staff', '[]', '::1', '2026-10-03 21:42:03'),
(303, 'LOGIN_FAILED', 'u3', 'jeremiemugar7@gmail.com', '[]', '::1', '2026-10-03 21:42:40'),
(304, 'LOGIN_BLOCKED_LOCKOUT', NULL, 'jeremiemugar6@gmail.com', '[]', '::1', '2026-10-03 21:49:36'),
(305, 'LOGIN_BLOCKED_LOCKOUT', NULL, 'jeremiemugar6@gmail.com', '[]', '::1', '2026-10-03 21:49:53'),
(306, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '::1', '2026-10-03 21:51:00'),
(307, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '::1', '2026-10-03 21:51:13'),
(308, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 21:51:14'),
(309, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 21:51:41'),
(310, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 21:51:41'),
(311, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 21:53:35'),
(312, 'LOGOUT', 'u1', 'admin', '[]', '::1', '2026-10-03 21:53:40'),
(313, 'LOGIN_FAILED', 'u1', 'admin', '[]', '::1', '2026-10-03 21:53:49'),
(314, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '::1', '2026-10-03 21:54:01'),
(315, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '::1', '2026-10-03 21:54:09'),
(316, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 21:54:10'),
(317, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 21:54:14'),
(318, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 21:58:52'),
(319, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:05:48'),
(320, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:06:19'),
(321, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:06:19'),
(322, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:21:38'),
(323, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:23:50'),
(324, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:26:36'),
(325, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:26:37'),
(326, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:29:07'),
(327, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:29:27'),
(328, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:29:27'),
(329, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:29:27'),
(330, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:29:28'),
(331, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:29:28'),
(332, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:29:28'),
(333, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:29:28'),
(334, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:29:28'),
(335, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:29:43'),
(336, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:29:44'),
(337, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:29:44'),
(338, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:29:44'),
(339, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:29:44'),
(340, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:29:44'),
(341, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:29:44'),
(342, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:29:44'),
(343, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:29:45'),
(344, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:29:45'),
(345, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:29:45'),
(346, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:29:45'),
(347, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:29:45'),
(348, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:30:09'),
(349, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:16'),
(350, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:17'),
(351, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:17'),
(352, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:17'),
(353, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:17'),
(354, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:17'),
(355, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:24'),
(356, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:24'),
(357, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:24'),
(358, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:24'),
(359, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:24'),
(360, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:24'),
(361, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:24'),
(362, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:25'),
(363, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:25'),
(364, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:28'),
(365, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:28'),
(366, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:28'),
(367, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:28'),
(368, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:28'),
(369, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:28'),
(370, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:29'),
(371, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:29'),
(372, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:29'),
(373, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:29'),
(374, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:29'),
(375, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:29'),
(376, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:30'),
(377, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:36:30'),
(378, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:37:02'),
(379, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:37:02'),
(380, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:37:02'),
(381, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:37:02'),
(382, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:37:03'),
(383, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:42:02'),
(384, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:42:03'),
(385, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:42:03'),
(386, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:42:03'),
(387, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:42:03'),
(388, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:42:03'),
(389, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:42:07'),
(390, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:42:07'),
(391, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:42:08'),
(392, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:42:08'),
(393, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:42:08'),
(394, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:42:08'),
(395, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:42:08'),
(396, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:17'),
(397, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:17'),
(398, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:17'),
(399, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:18'),
(400, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:18'),
(401, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:18'),
(402, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:18'),
(403, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:18'),
(404, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:19'),
(405, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:19'),
(406, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:19'),
(407, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:19'),
(408, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:20'),
(409, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:20'),
(410, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:20'),
(411, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:20'),
(412, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:20'),
(413, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:21'),
(414, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:21'),
(415, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:21'),
(416, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:21'),
(417, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:21'),
(418, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:22'),
(419, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:22'),
(420, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:43:22'),
(421, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '::1', '2026-10-03 22:44:10'),
(422, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '::1', '2026-10-03 22:44:18'),
(423, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:44:18'),
(424, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:44:31'),
(425, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:44:31'),
(426, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:44:31'),
(427, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:44:31'),
(428, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:44:31'),
(429, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:44:32'),
(430, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:44:32'),
(431, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:44:32'),
(432, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:44:32'),
(433, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:44:32'),
(434, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:44:32'),
(435, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:44:33'),
(436, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:44:33'),
(437, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:44:33'),
(438, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:45:22'),
(439, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:45:22'),
(440, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:45:22'),
(441, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:45:23'),
(442, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:47:45'),
(443, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:47:45'),
(444, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:47:45'),
(445, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:47:45'),
(446, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:51:14'),
(447, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:51:14'),
(448, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:51:14'),
(449, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:51:14'),
(450, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:51:15'),
(451, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:55:57'),
(452, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:56:15'),
(453, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 22:56:22'),
(454, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:06:54'),
(455, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:11:17'),
(456, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:11:17'),
(457, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:11:29'),
(458, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:11:29'),
(459, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:11:29'),
(460, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:11:29'),
(461, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:11:29'),
(462, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:12:54'),
(463, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:15:01'),
(464, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:15:02'),
(465, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:15:02'),
(466, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:33:40'),
(467, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:34:03'),
(468, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:35:24'),
(469, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:36:22'),
(470, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:36:28'),
(471, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:36:28'),
(472, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:36:28'),
(473, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:36:28');
INSERT INTO `security_logs` (`id`, `event_type`, `user_id`, `username`, `details`, `ip_address`, `created_at`) VALUES
(474, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:36:29'),
(475, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:40:26'),
(476, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:40:26'),
(477, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:56:59'),
(478, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:56:59'),
(479, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:58:26'),
(480, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:58:26'),
(481, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-03 23:59:50'),
(482, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:09:28'),
(483, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:09:28'),
(484, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:09:32'),
(485, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:09:32'),
(486, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:10:43'),
(487, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:11:06'),
(488, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:11:13'),
(489, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:11:33'),
(490, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:11:52'),
(491, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:11:52'),
(492, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:12:27'),
(493, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:12:27'),
(494, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:12:27'),
(495, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:12:27'),
(496, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:12:27'),
(497, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:15:10'),
(498, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:15:10'),
(499, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:15:10'),
(500, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:15:13'),
(501, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:15:13'),
(502, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:15:14'),
(503, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:15:14'),
(504, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:15:14'),
(505, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:15:14'),
(506, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:15:14'),
(507, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:15:14'),
(508, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:15:15'),
(509, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:15:15'),
(510, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:15:15'),
(511, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:15:22'),
(512, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:15:22'),
(513, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:19:56'),
(514, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:19:57'),
(515, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:20:02'),
(516, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:20:03'),
(517, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:20:36'),
(518, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:20:43'),
(519, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:20:50'),
(520, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:21:03'),
(521, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:21:15'),
(522, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:21:17'),
(523, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:21:53'),
(524, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:25:13'),
(525, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:28:45'),
(526, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:30:44'),
(527, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:43:33'),
(528, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:43:33'),
(529, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:43:33'),
(530, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:45:05'),
(531, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:46:33'),
(532, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:46:33'),
(533, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:46:33'),
(534, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 00:47:51'),
(535, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 01:07:15'),
(536, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 01:07:16'),
(537, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 01:07:16'),
(538, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 01:21:14'),
(539, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 01:21:14'),
(540, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 01:22:20'),
(541, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 01:22:20'),
(542, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 01:22:25'),
(543, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 01:22:25'),
(544, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 01:23:10'),
(545, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 01:42:06'),
(546, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 01:42:07'),
(547, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 01:42:07'),
(548, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 01:56:06'),
(549, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 01:57:01'),
(550, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 01:57:08'),
(551, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 01:58:00'),
(552, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 01:59:04'),
(553, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 01:59:47'),
(554, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 01:59:49'),
(555, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:01:04'),
(556, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:02:46'),
(557, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:02:47'),
(558, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:03:07'),
(559, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:06:20'),
(560, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:06:20'),
(561, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:06:20'),
(562, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:06:42'),
(563, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:06:42'),
(564, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:06:46'),
(565, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:07:44'),
(566, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:08:03'),
(567, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:08:32'),
(568, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:08:32'),
(569, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:08:33'),
(570, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:08:33'),
(571, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:08:33'),
(572, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:09:40'),
(573, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:11:51'),
(574, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:12:05'),
(575, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:12:11'),
(576, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:12:11'),
(577, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:16:21'),
(578, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:16:21'),
(579, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:16:21'),
(580, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:16:22'),
(581, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:16:31'),
(582, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:16:32'),
(583, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:20:12'),
(584, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:20:12'),
(585, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:20:13'),
(586, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:20:33'),
(587, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:28:50'),
(588, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:28:50'),
(589, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:29:46'),
(590, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:29:46'),
(591, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:29:47'),
(592, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:32:42'),
(593, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:32:42'),
(594, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:32:42'),
(595, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:32:42'),
(596, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:32:42'),
(597, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:32:42'),
(598, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:32:43'),
(599, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:32:43'),
(600, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:32:43'),
(601, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:32:43'),
(602, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:32:43'),
(603, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:32:43'),
(604, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:32:44'),
(605, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:32:44'),
(606, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:32:45'),
(607, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:32:45'),
(608, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:33:26'),
(609, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:33:26'),
(610, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:34:56'),
(611, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:37:33'),
(612, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:38:07'),
(613, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:38:26'),
(614, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:42:06'),
(615, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:42:26'),
(616, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:42:32'),
(617, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:47:09'),
(618, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:47:09'),
(619, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:47:09'),
(620, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:47:33'),
(621, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:47:34'),
(622, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:47:34'),
(623, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:48:13'),
(624, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:48:21'),
(625, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:50:43'),
(626, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:50:54'),
(627, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:55:45'),
(628, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:55:46'),
(629, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:55:53'),
(630, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:55:53'),
(631, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:55:53'),
(632, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:55:53'),
(633, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:55:53'),
(634, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:55:54'),
(635, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:55:54'),
(636, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:55:54'),
(637, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:55:54'),
(638, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:55:55'),
(639, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 02:55:55'),
(640, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:03:36'),
(641, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:03:36'),
(642, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:03:48'),
(643, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:04:00'),
(644, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:04:01'),
(645, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:04:01'),
(646, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:06:01'),
(647, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:06:01'),
(648, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:06:09'),
(649, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:06:55'),
(650, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:06:55'),
(651, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:08:52'),
(652, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:14:41'),
(653, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:15:31'),
(654, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:15:31'),
(655, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:18:32'),
(656, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:18:32'),
(657, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:18:32'),
(658, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:18:32'),
(659, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:14'),
(660, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:15'),
(661, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:21'),
(662, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:21'),
(663, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:22'),
(664, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:22'),
(665, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:22'),
(666, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:22'),
(667, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:22'),
(668, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:22'),
(669, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:23'),
(670, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:23'),
(671, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:23'),
(672, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:23'),
(673, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:23'),
(674, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:24'),
(675, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:24'),
(676, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:24'),
(677, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:24'),
(678, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:24'),
(679, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:25'),
(680, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:25'),
(681, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:25'),
(682, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:25'),
(683, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:27'),
(684, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:27'),
(685, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:27'),
(686, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:27'),
(687, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:27'),
(688, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:53'),
(689, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:53'),
(690, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:19:53'),
(691, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:31:09'),
(692, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:31:10'),
(693, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:31:49'),
(694, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:31:49'),
(695, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:31:50'),
(696, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:32:15'),
(697, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:32:15'),
(698, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:32:15'),
(699, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:34:59'),
(700, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:34:59'),
(701, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:34:59'),
(702, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:35:40'),
(703, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:35:40'),
(704, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:37:58'),
(705, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:37:59'),
(706, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:37:59'),
(707, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:40:35'),
(708, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:40:36'),
(709, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:41:42'),
(710, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:41:42'),
(711, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:41:42'),
(712, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:42:28'),
(713, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:42:28'),
(714, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:43:27'),
(715, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:43:27'),
(716, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:44:22'),
(717, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:45:43'),
(718, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:45:43'),
(719, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:47:51'),
(720, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:47:51'),
(721, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:47:51'),
(722, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:47:55'),
(723, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:20'),
(724, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:20'),
(725, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:24'),
(726, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:41'),
(727, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:43'),
(728, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:43'),
(729, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:43'),
(730, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:43'),
(731, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:44'),
(732, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:44'),
(733, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:44'),
(734, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:44'),
(735, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:44'),
(736, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:44'),
(737, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:45'),
(738, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:45'),
(739, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:45'),
(740, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:45'),
(741, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:46'),
(742, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:46'),
(743, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:46'),
(744, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:46'),
(745, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:47'),
(746, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:47'),
(747, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:47'),
(748, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:48'),
(749, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:48'),
(750, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:48'),
(751, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:48:48'),
(752, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:50:33'),
(753, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:50:33'),
(754, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:50:34'),
(755, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:50:39'),
(756, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:50:39'),
(757, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:50:39'),
(758, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:52:47'),
(759, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:52:47'),
(760, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:52:47'),
(761, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:52:47'),
(762, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:52:48'),
(763, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:52:48'),
(764, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:52:48'),
(765, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:52:48'),
(766, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:52:48'),
(767, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:52:48'),
(768, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:53:30'),
(769, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:55:50'),
(770, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:55:50'),
(771, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:56:36'),
(772, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 03:56:36'),
(773, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 04:00:41'),
(774, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 04:00:41'),
(775, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 04:09:57'),
(776, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 04:09:57'),
(777, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 04:10:00'),
(778, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 04:10:00'),
(779, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 04:10:00'),
(780, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 04:10:00'),
(781, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 04:10:00'),
(782, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 04:10:24'),
(783, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 04:10:24'),
(784, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 04:10:24'),
(785, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 04:10:24'),
(786, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 04:10:24'),
(787, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '::1', '2026-10-04 14:44:28'),
(788, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '::1', '2026-10-04 14:44:44'),
(789, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 14:44:45'),
(790, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 14:49:56'),
(791, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 14:50:04'),
(792, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 14:50:40'),
(793, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 14:54:23'),
(794, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 14:54:23'),
(795, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 14:54:23'),
(796, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 14:57:47'),
(797, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 14:57:51'),
(798, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 14:57:51'),
(799, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 14:57:51'),
(800, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 14:57:55'),
(801, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 14:57:55'),
(802, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 14:57:55'),
(803, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 14:57:55'),
(804, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 14:57:55'),
(805, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 14:58:17'),
(806, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:00:42'),
(807, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:00:42'),
(808, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:00:42'),
(809, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:00:48'),
(810, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:00:48'),
(811, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:00:48'),
(812, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:01:12'),
(813, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:05:41'),
(814, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:05:45'),
(815, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:05:45'),
(816, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:05:59'),
(817, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:10:03'),
(818, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:10:04'),
(819, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:10:04'),
(820, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:10:12'),
(821, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:10:13'),
(822, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:10:13'),
(823, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:10:13'),
(824, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:10:13'),
(825, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:10:13'),
(826, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:10:13'),
(827, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:10:13'),
(828, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:10:14'),
(829, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:10:14'),
(830, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:12:13'),
(831, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:12:13'),
(832, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:23:44'),
(833, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:23:44'),
(834, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:23:44'),
(835, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:23:52'),
(836, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:23:52'),
(837, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:23:52'),
(838, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:23:52'),
(839, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:23:52'),
(840, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:23:52'),
(841, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:23:53'),
(842, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:25:11'),
(843, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:25:13'),
(844, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:29:11'),
(845, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:29:40'),
(846, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:31:17'),
(847, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:31:36'),
(848, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:34:45'),
(849, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:35:10'),
(850, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:35:15'),
(851, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:35:15'),
(852, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:35:15'),
(853, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:35:15'),
(854, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:35:16'),
(855, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:35:16'),
(856, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:35:41'),
(857, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:37:16'),
(858, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:37:16'),
(859, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:37:40'),
(860, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:37:41'),
(861, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:42:32'),
(862, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:42:32'),
(863, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:43:12'),
(864, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:43:24'),
(865, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:54:20'),
(866, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:57:31'),
(867, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:57:32'),
(868, 'ITEMS_RECEIVED_AND_INSPECTED', 'u1', 'Admin User', '{\"receiving_number\":\"GR-2026-0003\",\"por_number\":\"POR-2026-0003\",\"po_number\":\"PO-2026-0003\",\"total_ordered\":1,\"total_received\":1,\"total_accepted\":1,\"total_rejected\":0,\"inspection_status\":\"Passed\",\"inventory_updated\":true}', '::1', '2026-10-04 15:57:55'),
(869, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:58:00'),
(870, 'ITEMS_RECEIVED_AND_INSPECTED', 'u1', 'Admin User', '{\"receiving_number\":\"GR-2026-0004\",\"por_number\":\"POR-2026-0004\",\"po_number\":\"PO-2026-0004\",\"total_ordered\":1,\"total_received\":1,\"total_accepted\":0,\"total_rejected\":1,\"inspection_status\":\"Failed\",\"inventory_updated\":true}', '::1', '2026-10-04 15:58:28'),
(871, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:58:35'),
(872, 'ITEMS_RECEIVED_AND_INSPECTED', 'u1', 'Admin User', '{\"receiving_number\":\"GR-2026-0005\",\"por_number\":\"POR-2026-0005\",\"po_number\":\"PO-2026-0005\",\"total_ordered\":1,\"total_received\":1,\"total_accepted\":0,\"total_rejected\":0,\"inspection_status\":\"Failed\",\"inventory_updated\":true}', '::1', '2026-10-04 15:58:58'),
(873, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:59:06'),
(874, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:59:12'),
(875, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:59:15'),
(876, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 15:59:23'),
(877, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:06:01'),
(878, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:17:47'),
(879, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:17:47'),
(880, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:19:53'),
(881, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:20:22'),
(882, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:20:23'),
(883, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:37:30'),
(884, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:37:30'),
(885, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:37:34'),
(886, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:37:34'),
(887, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:37:34'),
(888, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:37:34'),
(889, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:37:53'),
(890, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:37:53'),
(891, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:37:53'),
(892, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:37:54'),
(893, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:37:54'),
(894, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:37:59'),
(895, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:38:31'),
(896, 'AI_PREDICTIONS_GENERATED', 'u1', 'admin', '{\"count\":43}', '::1', '2026-10-04 16:40:29'),
(897, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:40:39'),
(898, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:40:52'),
(899, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:40:52'),
(900, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:50:50'),
(901, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:50:50'),
(902, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:50:57'),
(903, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:50:57'),
(904, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:50:57'),
(905, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:50:57'),
(906, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:50:57'),
(907, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:50:57'),
(908, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:50:58'),
(909, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:50:58'),
(910, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:50:58'),
(911, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:50:58'),
(912, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:51:08'),
(913, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:51:08'),
(914, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:51:08'),
(915, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 16:51:08'),
(916, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 17:03:09'),
(917, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 17:03:33'),
(918, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 17:03:41'),
(919, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 17:07:38'),
(920, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 17:07:38'),
(921, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 17:08:19'),
(922, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 17:26:08'),
(923, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 17:31:39'),
(924, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 17:31:39'),
(925, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '::1', '2026-10-04 17:34:16'),
(926, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '::1', '2026-10-04 17:34:57'),
(927, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 17:34:58'),
(928, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 17:39:03'),
(929, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 17:44:04'),
(930, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 17:44:09'),
(931, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 17:44:27'),
(932, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 17:52:54'),
(933, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 17:52:54'),
(934, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 17:52:54'),
(935, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 17:52:55'),
(936, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 17:52:55'),
(937, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 17:53:50'),
(938, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:05:17'),
(939, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:05:17'),
(940, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:05:18'),
(941, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:05:18'),
(942, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:05:35'),
(943, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:05:35'),
(944, 'ITEMS_RECEIVED_AND_INSPECTED', 'u1', 'Admin User', '{\"receiving_number\":\"GR-2026-0006\",\"por_number\":\"POR-2026-0006\",\"po_number\":\"PO-2026-0006\",\"total_ordered\":1,\"total_received\":1,\"total_accepted\":1,\"total_rejected\":0,\"inspection_status\":\"Passed\",\"inventory_updated\":true}', '::1', '2026-10-04 18:05:42'),
(945, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:13:20'),
(946, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:13:20'),
(947, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:13:21'),
(948, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:13:45'),
(949, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:32:22'),
(950, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:32:22'),
(951, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:32:23'),
(952, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:33:01'),
(953, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:33:01'),
(954, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:33:02'),
(955, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:33:04'),
(956, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:33:04'),
(957, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:33:04'),
(958, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:33:05'),
(959, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:33:05'),
(960, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:33:05'),
(961, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:33:05'),
(962, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:33:05'),
(963, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:34:00'),
(964, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:34:23'),
(965, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:34:24'),
(966, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:34:24'),
(967, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:34:24'),
(968, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:34:24'),
(969, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:34:25'),
(970, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:34:25'),
(971, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:34:25'),
(972, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:34:25'),
(973, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:34:25'),
(974, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:34:25'),
(975, 'LOGOUT', 'u1', 'admin', '[]', '::1', '2026-10-04 18:34:27'),
(976, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '::1', '2026-10-04 18:34:40'),
(977, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '::1', '2026-10-04 18:35:02'),
(978, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:35:02'),
(979, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:45:44'),
(980, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:45:44'),
(981, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 18:45:44'),
(982, 'OTP_SENT', 'u1', 'admin', '{\"mailed\":true}', '::1', '2026-10-04 19:08:27'),
(983, 'LOGIN_SUCCESS', 'u1', 'admin', '[]', '::1', '2026-10-04 19:08:38'),
(984, 'PAGE_ACCESS', 'u1', 'admin', '{\"page\":\"dashboard\"}', '::1', '2026-10-04 19:08:39');

-- --------------------------------------------------------

--
-- Table structure for table `stock_adjustments`
--

CREATE TABLE `stock_adjustments` (
  `id` varchar(40) NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`data`)),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stock_transfers`
--

CREATE TABLE `stock_transfers` (
  `id` varchar(40) NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`data`)),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stock_transfers`
--

INSERT INTO `stock_transfers` (`id`, `data`, `created_at`, `updated_at`) VALUES
('st_1791108816975_991567', '{\"id\":\"st_1791108816975_991567\",\"transferNumber\":\"ST-2026-0001\",\"transferDate\":\"2026-10-04\",\"sourceLocationId\":\"loc2\",\"sourceLocationName\":\"Branch 1 - Makati\",\"destinationLocationId\":\"loc3\",\"destinationLocationName\":\"Branch 2 - Quezon City\",\"requestedBy\":\"u1\",\"requestedByName\":\"Admin User\",\"status\":\"Approved\",\"remarks\":\"\",\"items\":[{\"productId\":\"p1\",\"productName\":\"\\n                Samyang Buldak Original\\n                \\n                    SKU: SB-001 | Available: 30 pcs\\n                \\n            \",\"sku\":\"SB-001\",\"quantity\":10,\"unit\":\"pcs\",\"sourceStock\":30},{\"productId\":\"p10\",\"productName\":\"\\n                Korean Seaweed Snack\\n                \\n                    SKU: KS-010 | Available: 50 pcs\\n                \\n            \",\"sku\":\"KS-010\",\"quantity\":10,\"unit\":\"pcs\",\"sourceStock\":50},{\"productId\":\"p2\",\"productName\":\"\\n                Shin Ramyun\\n                \\n                    SKU: SR-002 | Available: 25 pcs\\n                \\n            \",\"sku\":\"SR-002\",\"quantity\":10,\"unit\":\"pcs\",\"sourceStock\":25}],\"totalItems\":30,\"createdAt\":\"2026-10-04T12:13:36.000Z\",\"submittedAt\":\"2026-10-04T12:13:36.000Z\",\"approvedBy\":\"usr_test_admin\",\"approvedByName\":\"Test Admin\",\"approvedAt\":\"2026-10-04T12:23:54.000Z\",\"approvalRemarks\":\"Test approval\"}', '2026-10-04 18:13:36', '2026-10-04 18:23:54'),
('st_1791109197384_3e3715', '{\"id\":\"st_1791109197384_3e3715\",\"transferNumber\":\"ST-2026-2778\",\"sourceLocationId\":\"loc1\",\"sourceLocationName\":\"Main Warehouse\",\"destinationLocationId\":\"loc2\",\"destinationLocationName\":\"Branch 1 - Makati\",\"items\":[{\"productId\":\"p1\",\"productName\":\"Samyang Buldak Original\",\"sku\":\"SB-001\",\"quantity\":10,\"unit\":\"Piece\",\"sourceStock\":150}],\"totalItems\":1,\"status\":\"Approved\",\"requestedBy\":\"usr_test_admin\",\"requestedByName\":\"Test Admin\",\"createdAt\":\"2026-10-04T12:19:57.000Z\",\"submittedAt\":\"2026-10-04T12:19:57.000Z\",\"transferDate\":\"2026-10-04\",\"remarks\":\"Test transfer for debugging\",\"approvedBy\":\"usr_test_admin\",\"approvedByName\":\"Test Admin\",\"approvedAt\":\"2026-10-04T12:30:35.000Z\",\"approvalRemarks\":\"Test approval\"}', '2026-10-04 18:19:57', '2026-10-04 18:30:35'),
('st_1791109962907_f7c462', '{\"id\":\"st_1791109962907_f7c462\",\"transferNumber\":\"ST-2026-2779\",\"transferDate\":\"2026-10-04\",\"sourceLocationId\":\"loc2\",\"sourceLocationName\":\"Branch 1 - Makati\",\"destinationLocationId\":\"loc3\",\"destinationLocationName\":\"Branch 2 - Quezon City\",\"requestedBy\":\"u1\",\"requestedByName\":\"Admin User\",\"status\":\"Pending Approval\",\"remarks\":\"\",\"items\":[{\"productId\":\"p1\",\"productName\":\"\\n                Samyang Buldak Original\\n                \\n                    SKU: SB-001 | Available: 30 pcs\\n                \\n            \",\"sku\":\"SB-001\",\"quantity\":10,\"unit\":\"pcs\",\"sourceStock\":30},{\"productId\":\"p10\",\"productName\":\"\\n                Korean Seaweed Snack\\n                \\n                    SKU: KS-010 | Available: 50 pcs\\n                \\n            \",\"sku\":\"KS-010\",\"quantity\":10,\"unit\":\"pcs\",\"sourceStock\":50},{\"productId\":\"p2\",\"productName\":\"\\n                Shin Ramyun\\n                \\n                    SKU: SR-002 | Available: 25 pcs\\n                \\n            \",\"sku\":\"SR-002\",\"quantity\":10,\"unit\":\"pcs\",\"sourceStock\":25}],\"totalItems\":30,\"createdAt\":\"2026-10-04T12:32:42.000Z\",\"submittedAt\":\"2026-10-04T12:32:42.000Z\"}', '2026-10-04 18:32:42', '2026-10-04 18:32:42'),
('st_1791110554559_4475a3', '{\"id\":\"st_1791110554559_4475a3\",\"transferNumber\":\"ST-DEMO-124234\",\"sourceLocationId\":\"loc1\",\"sourceLocationName\":\"Main Warehouse\",\"destinationLocationId\":\"loc2\",\"destinationLocationName\":\"Branch 1 - Makati\",\"items\":[{\"productId\":\"p1\",\"productName\":\"Samyang Buldak Original\",\"sku\":\"SAM-001\",\"quantity\":10,\"unit\":\"pcs\",\"sourceStock\":150}],\"totalItems\":1,\"status\":\"Completed\",\"requestedBy\":\"usr_demo\",\"requestedByName\":\"Demo User\",\"createdAt\":\"2026-10-04T12:42:34.000Z\",\"submittedAt\":\"2026-10-04T12:42:34.000Z\",\"transferDate\":\"2026-10-04\",\"remarks\":\"Local demo transfer - testing complete workflow\",\"approvedBy\":\"usr_admin\",\"approvedByName\":\"Admin User\",\"approvedAt\":\"2026-10-04T12:42:34.000Z\",\"approvalRemarks\":\"Approved for demo\",\"completedAt\":\"2026-10-04T12:42:34.000Z\"}', '2026-10-04 18:42:34', '2026-10-04 18:42:34'),
('st_1791110766399_ef1c0b', '{\"id\":\"st_1791110766399_ef1c0b\",\"transferNumber\":\"ST-2026-2780\",\"transferDate\":\"2026-10-04\",\"sourceLocationId\":\"loc3\",\"sourceLocationName\":\"Branch 2 - Quezon City\",\"destinationLocationId\":\"loc1\",\"destinationLocationName\":\"Main Warehouse\",\"requestedBy\":\"u1\",\"requestedByName\":\"Admin User\",\"status\":\"Pending Approval\",\"remarks\":\"\",\"items\":[{\"productId\":\"p1\",\"productName\":\"\\n                Samyang Buldak Original\\n                \\n                    SKU: SB-001 | Available: 20 pcs\\n                \\n            \",\"sku\":\"SB-001\",\"quantity\":10,\"unit\":\"pcs\",\"sourceStock\":20},{\"productId\":\"p3\",\"productName\":\"\\n                Ottogi Jin Ramen Spicy\\n                \\n                    SKU: OJ-003 | Available: 40 pcs\\n                \\n            \",\"sku\":\"OJ-003\",\"quantity\":10,\"unit\":\"pcs\",\"sourceStock\":40}],\"totalItems\":20,\"createdAt\":\"2026-10-04T12:46:06.000Z\",\"submittedAt\":\"2026-10-04T12:46:06.000Z\"}', '2026-10-04 18:46:06', '2026-10-04 18:46:06');

-- --------------------------------------------------------

--
-- Table structure for table `stock_transfer_audit`
--

CREATE TABLE `stock_transfer_audit` (
  `id` int(11) NOT NULL,
  `transfer_id` varchar(100) NOT NULL,
  `action_type` varchar(50) NOT NULL,
  `user_id` varchar(40) NOT NULL,
  `user_name` varchar(150) NOT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `ip_address` varchar(64) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stock_transfer_audit`
--

INSERT INTO `stock_transfer_audit` (`id`, `transfer_id`, `action_type`, `user_id`, `user_name`, `details`, `ip_address`, `created_at`) VALUES
(14, 'st_1791108816975_991567', 'TRANSFER_CREATED', 'u1', 'Admin User', '{\"transferNumber\":\"ST-2026-0001\",\"sourceLocation\":\"Branch 1 - Makati\",\"destinationLocation\":\"Branch 2 - Quezon City\",\"itemCount\":3}', '::1', '2026-10-04 18:13:36'),
(15, 'st_1791108816975_991567', 'TRANSFER_SUBMITTED', 'u1', 'Admin User', '{\"transferNumber\":\"ST-2026-0001\",\"status\":\"Pending Approval\"}', '::1', '2026-10-04 18:13:36'),
(16, 'st_1791109962907_f7c462', 'TRANSFER_CREATED', 'u1', 'Admin User', '{\"transferNumber\":\"ST-2026-2779\",\"sourceLocation\":\"Branch 1 - Makati\",\"destinationLocation\":\"Branch 2 - Quezon City\",\"itemCount\":3}', '::1', '2026-10-04 18:32:42'),
(17, 'st_1791109962907_f7c462', 'TRANSFER_SUBMITTED', 'u1', 'Admin User', '{\"transferNumber\":\"ST-2026-2779\",\"status\":\"Pending Approval\"}', '::1', '2026-10-04 18:32:42'),
(18, 'st_1791110766399_ef1c0b', 'TRANSFER_CREATED', 'u1', 'Admin User', '{\"transferNumber\":\"ST-2026-2780\",\"sourceLocation\":\"Branch 2 - Quezon City\",\"destinationLocation\":\"Main Warehouse\",\"itemCount\":2}', '::1', '2026-10-04 18:46:06'),
(19, 'st_1791110766399_ef1c0b', 'TRANSFER_SUBMITTED', 'u1', 'Admin User', '{\"transferNumber\":\"ST-2026-2780\",\"status\":\"Pending Approval\"}', '::1', '2026-10-04 18:46:06');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` varchar(40) NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`data`)),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `data`, `created_at`, `updated_at`) VALUES
('s1', '{\"id\": \"s1\", \"company\": \"Seoul Food Distribution\", \"contactPerson\": \"Minji Kim\", \"email\": \"minji@seoulfood.co.kr\", \"phone\": \"+82 10 1234 5678\", \"address\": \"456 Hongdae-ro, Mapo-gu, Seoul, South Korea\", \"taxId\": \"KR-123-45-67890\", \"paymentTerms\": \"Net 30\", \"notes\": \"Primary supplier for Korean instant noodles and snacks. Specializes in Samyang, Nongshim, and Ottogi products.\", \"productCount\": 8, \"status\": \"Active\", \"rating\": 4.8, \"deliveryDays\": 7, \"minimumOrder\": 25000, \"created_at\": \"2026-10-01T02:21:06.000Z\"}', '2026-10-01 02:21:06', '2026-10-01 02:21:06'),
('s2', '{\"id\": \"s2\", \"company\": \"K-Food Wholesale Trading\", \"contactPerson\": \"Park Jin-woo\", \"email\": \"jinwoo@kfoodtrading.kr\", \"phone\": \"+82 2 9876 5432\", \"address\": \"789 Gangnam-daero, Gangnam-gu, Seoul, South Korea\", \"taxId\": \"KR-987-65-43210\", \"paymentTerms\": \"Net 15\", \"notes\": \"Premium Korean food products distributor. Known for authentic traditional items and modern convenience foods.\", \"productCount\": 12, \"status\": \"Active\", \"rating\": 4.9, \"deliveryDays\": 5, \"minimumOrder\": 50000, \"created_at\": \"2026-10-01T02:21:06.000Z\"}', '2026-10-01 02:21:06', '2026-10-01 02:21:06'),
('s3', '{\"id\": \"s3\", \"company\": \"Asia Grocery Supply\", \"contactPerson\": \"Lee Soo-jin\", \"email\": \"soojin@asiagrocery.ph\", \"phone\": \"+63 2 8555 1234\", \"address\": \"123 Binondo, Manila, Philippines\", \"taxId\": \"PH-555-123-789\", \"paymentTerms\": \"Net 21\", \"notes\": \"Local distributor for Asian grocery products. Handles both Korean and Japanese imports with competitive pricing.\", \"productCount\": 15, \"status\": \"Active\", \"rating\": 4.5, \"deliveryDays\": 3, \"minimumOrder\": 15000, \"created_at\": \"2026-10-01T02:21:06.000Z\"}', '2026-10-01 02:21:06', '2026-10-01 02:21:06'),
('s4', '{\"id\": \"s4\", \"company\": \"Korean-Japanese Food Distributor\", \"contactPerson\": \"Tanaka Hiroshi\", \"email\": \"hiroshi@kjfood.com\", \"phone\": \"+81 3 5555 7890\", \"address\": \"321 Shibuya, Tokyo, Japan\", \"taxId\": \"JP-321-654-987\", \"paymentTerms\": \"Net 30\", \"notes\": \"Specialized distributor for both Korean and Japanese food products. Excellent for variety and authentic flavors.\", \"productCount\": 20, \"status\": \"Active\", \"rating\": 4.7, \"deliveryDays\": 10, \"minimumOrder\": 30000, \"created_at\": \"2026-10-01T02:21:06.000Z\"}', '2026-10-01 02:21:06', '2026-10-01 02:21:06');

-- --------------------------------------------------------

--
-- Table structure for table `transfer_proof`
--

CREATE TABLE `transfer_proof` (
  `id` varchar(40) NOT NULL,
  `proof_number` varchar(50) NOT NULL,
  `transfer_id` varchar(40) NOT NULL,
  `transfer_number` varchar(50) NOT NULL,
  `source_location_id` varchar(40) NOT NULL,
  `source_location_name` varchar(255) NOT NULL,
  `destination_location_id` varchar(40) NOT NULL,
  `destination_location_name` varchar(255) NOT NULL,
  `transfer_date` datetime NOT NULL,
  `delivered_by` varchar(40) NOT NULL,
  `delivered_by_name` varchar(255) NOT NULL,
  `received_by` varchar(40) DEFAULT NULL,
  `received_by_name` varchar(255) DEFAULT NULL,
  `delivery_date` datetime DEFAULT NULL,
  `completion_date` datetime DEFAULT NULL,
  `status` enum('Pending','In Transit','Delivered','Completed','Cancelled') DEFAULT 'Pending',
  `total_items` int(11) DEFAULT 0,
  `total_quantity` decimal(10,2) DEFAULT 0.00,
  `delivery_notes` text DEFAULT NULL,
  `receiving_notes` text DEFAULT NULL,
  `evidence_files` longtext DEFAULT NULL COMMENT 'JSON array of uploaded file paths',
  `signature_delivered` text DEFAULT NULL COMMENT 'Base64 signature',
  `signature_received` text DEFAULT NULL COMMENT 'Base64 signature',
  `remarks` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `transfer_proof`
--

INSERT INTO `transfer_proof` (`id`, `proof_number`, `transfer_id`, `transfer_number`, `source_location_id`, `source_location_name`, `destination_location_id`, `destination_location_name`, `transfer_date`, `delivered_by`, `delivered_by_name`, `received_by`, `received_by_name`, `delivery_date`, `completion_date`, `status`, `total_items`, `total_quantity`, `delivery_notes`, `receiving_notes`, `evidence_files`, `signature_delivered`, `signature_received`, `remarks`, `created_at`, `updated_at`) VALUES
('tp_1791021193150_457b29', 'TP-2026-0001', 'st_demo_003', 'ST-2026-0003', 'loc2', 'Branch 1 - Makati', 'loc3', 'Branch 2 - Quezon City', '2026-10-01 11:53:13', 'admin', 'System Admin', 'manager', 'Branch Manager', '2026-10-01 11:53:13', '2026-10-01 11:53:13', 'Completed', 1, 30.00, 'All items packaged securely. Ready for delivery.', 'All items received in good condition. Quantities verified.', '[{\"type\":\"photo\",\"filename\":\"delivery_photo_001.jpg\",\"description\":\"Products loaded for delivery\",\"timestamp\":\"2026-10-03 11:53:13\"},{\"type\":\"photo\",\"filename\":\"delivery_photo_002.jpg\",\"description\":\"Products received at destination\",\"timestamp\":\"2026-10-03 11:53:13\"}]', NULL, NULL, NULL, '2026-10-03 17:53:13', '2026-10-03 17:53:13'),
('tp_1791021193153_28df14', 'TP-2026-0002', 'st_1791021193152_2972ae', 'ST-2026-0007', 'loc1', 'Main Warehouse', 'loc2', 'Branch 1 - Makati', '2026-10-02 11:53:13', 'admin', 'System Admin', 'manager', 'Branch Manager - Makati', '2026-10-02 08:30:00', '2026-10-03 11:53:13', 'Completed', 3, 45.00, 'All items securely packaged. Temperature-controlled transport for perishables. Estimated delivery time: 2 hours.', 'All items received and inspected. No damages. Quantities verified and match transfer document. Items placed in storage immediately.', '[{\"type\":\"photo\",\"filename\":\"transfer_loading_001.jpg\",\"description\":\"Products being loaded at Main Warehouse\",\"timestamp\":\"2026-10-02 11:53:13\"},{\"type\":\"photo\",\"filename\":\"transfer_transit_001.jpg\",\"description\":\"Items in transit - secured packaging\",\"timestamp\":\"2026-10-02 11:53:13\"},{\"type\":\"photo\",\"filename\":\"transfer_delivery_001.jpg\",\"description\":\"Delivery at Makati branch\",\"timestamp\":\"2026-10-03 11:53:13\"},{\"type\":\"photo\",\"filename\":\"transfer_inspection_001.jpg\",\"description\":\"Branch manager inspecting received items\",\"timestamp\":\"2026-10-03 11:53:13\"}]', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==', NULL, '2026-10-03 17:53:13', '2026-10-03 17:53:13');

-- --------------------------------------------------------

--
-- Table structure for table `transfer_proof_items`
--

CREATE TABLE `transfer_proof_items` (
  `id` varchar(40) NOT NULL,
  `proof_id` varchar(40) NOT NULL,
  `product_id` varchar(40) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `sku` varchar(100) DEFAULT NULL,
  `unit` varchar(50) DEFAULT 'pcs',
  `quantity_transferred` decimal(10,2) NOT NULL,
  `quantity_received` decimal(10,2) DEFAULT 0.00,
  `condition_notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `transfer_proof_items`
--

INSERT INTO `transfer_proof_items` (`id`, `proof_id`, `product_id`, `product_name`, `sku`, `unit`, `quantity_transferred`, `quantity_received`, `condition_notes`, `created_at`, `updated_at`) VALUES
('tpi_1791021193151_577cfd', 'tp_1791021193150_457b29', 'p3', 'Ottogi Jin Ramen', 'OJ-003', 'pcs', 30.00, 30.00, 'Good condition', '2026-10-03 17:53:13', '2026-10-03 17:53:13'),
('tpi_1791021193157_5fc24c', 'tp_1791021193153_28df14', 'MEAT001', 'Beef Bulgogi (500g)', 'MEAT001', 'Piece', 15.00, 15.00, 'Excellent condition - no damage during transit', '2026-10-03 17:53:13', '2026-10-03 17:53:13'),
('tpi_1791021193161_ff95f1', 'tp_1791021193153_28df14', 'RAM001', 'Samyang Buldak Cheese', 'RAM001', 'Piece', 15.00, 15.00, 'Excellent condition - no damage during transit', '2026-10-03 17:53:13', '2026-10-03 17:53:13'),
('tpi_1791021193164_48b998', 'tp_1791021193153_28df14', 'RAM002', 'Samyang Buldak Quattro Cheese', 'RAM002', 'Piece', 15.00, 15.00, 'Excellent condition - no damage during transit', '2026-10-03 17:53:13', '2026-10-03 17:53:13');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` varchar(40) NOT NULL,
  `name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','manager','staff') NOT NULL DEFAULT 'staff',
  `verified` tinyint(1) NOT NULL DEFAULT 1,
  `profile_picture` longtext DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `username`, `password_hash`, `role`, `verified`, `profile_picture`, `created_at`, `updated_at`) VALUES
('u1', 'Admin User', 'jeremiemugar6@gmail.com', 'admin', '$2y$10$nymLB6Q53aUgKOIcPZLtv.VpjAwlddDiEHYE4NA9o16umdDkdKZN.', 'admin', 1, NULL, '2026-10-01 02:29:55', '2026-10-03 21:49:30'),
('u2', 'Staff User', 'jeremiemugar8@gmail.com', 'staff', '$2y$10$ooyOVNTjpIiQ6qw/x4IJlOrn5bZKTleFue11bccuzWzi7JyWlEVce', 'staff', 1, NULL, '2026-10-01 02:29:55', '2026-10-03 21:49:30'),
('u3', 'Manager User', 'jeremiemugar7@gmail.com', 'manager', '$2y$10$efDrMd25nsuu9a32Xm.gredH5EcBFhofEsqp0ZD5RvZzTrwS/v/D6', 'manager', 1, NULL, '2026-10-01 02:29:55', '2026-10-03 21:49:30');

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_por_supplier_validation`
-- (See below for the actual view)
--
CREATE TABLE `v_por_supplier_validation` (
`por_id` varchar(40)
,`por_number` varchar(50)
,`purchase_order_id` varchar(40)
,`por_supplier_id` varchar(40)
,`por_supplier_name` varchar(255)
,`po_supplier_id` longtext
,`po_supplier_name` longtext
,`supplier_master_id` varchar(40)
,`supplier_master_name` longtext
,`validation_status` varchar(8)
);

-- --------------------------------------------------------

--
-- Structure for view `v_por_supplier_validation`
--
DROP TABLE IF EXISTS `v_por_supplier_validation`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_por_supplier_validation`  AS SELECT `por`.`id` AS `por_id`, `por`.`por_number` AS `por_number`, `por`.`purchase_order_id` AS `purchase_order_id`, `por`.`supplier_id` AS `por_supplier_id`, `por`.`supplier_name` AS `por_supplier_name`, json_unquote(json_extract(`po`.`data`,'$.supplierId')) AS `po_supplier_id`, json_unquote(json_extract(`po`.`data`,'$.supplier')) AS `po_supplier_name`, `s`.`id` AS `supplier_master_id`, json_unquote(json_extract(`s`.`data`,'$.company')) AS `supplier_master_name`, CASE WHEN `por`.`supplier_id` = json_unquote(json_extract(`po`.`data`,'$.supplierId')) THEN 'VALID' ELSE 'MISMATCH' END AS `validation_status` FROM ((`proof_of_receiving` `por` join `purchase_orders` `po` on(`por`.`purchase_order_id` = `po`.`id`)) left join `suppliers` `s` on(`por`.`supplier_id` = `s`.`id`)) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `damage_evidence`
--
ALTER TABLE `damage_evidence`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_receiving_id` (`receiving_id`),
  ADD KEY `idx_po_id` (`po_id`),
  ADD KEY `idx_product_id` (`product_id`),
  ADD KEY `idx_recorded_at` (`recorded_at`);

--
-- Indexes for table `inventory_locations`
--
ALTER TABLE `inventory_locations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `inventory_movements`
--
ALTER TABLE `inventory_movements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `inventory_predictions`
--
ALTER TABLE `inventory_predictions`
  ADD PRIMARY KEY (`prediction_id`),
  ADD UNIQUE KEY `uniq_product` (`product_id`),
  ADD KEY `idx_prediction_date` (`prediction_date`),
  ADD KEY `idx_demand_status` (`demand_status`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`identifier`),
  ADD KEY `idx_last_attempt` (`last_attempt`);

--
-- Indexes for table `otp_codes`
--
ALTER TABLE `otp_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_expires_at` (`expires_at`);

--
-- Indexes for table `pod_items`
--
ALTER TABLE `pod_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_pod_id` (`pod_id`),
  ADD KEY `idx_transfer_id` (`transfer_id`),
  ADD KEY `idx_product_id` (`product_id`),
  ADD KEY `idx_condition_status` (`condition_status`),
  ADD KEY `idx_pod_items_condition` (`pod_id`,`condition_status`);

--
-- Indexes for table `pod_photos`
--
ALTER TABLE `pod_photos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_pod_id` (`pod_id`),
  ADD KEY `idx_pod_item_id` (`pod_item_id`),
  ADD KEY `idx_transfer_id` (`transfer_id`),
  ADD KEY `idx_photo_type` (`photo_type`),
  ADD KEY `idx_photos_pod_type` (`pod_id`,`photo_type`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_created_at` (`created_at`),
  ADD KEY `idx_sku_normalized` (`sku_normalized`);

--
-- Indexes for table `proof_of_delivery`
--
ALTER TABLE `proof_of_delivery`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `qr_token` (`qr_token`),
  ADD KEY `idx_transfer_id` (`transfer_id`),
  ADD KEY `idx_qr_token` (`qr_token`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_scanned_at` (`scanned_at`),
  ADD KEY `idx_pod_status_transfer` (`status`,`transfer_id`);

--
-- Indexes for table `proof_of_receiving`
--
ALTER TABLE `proof_of_receiving`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `por_number` (`por_number`),
  ADD KEY `idx_por_number` (`por_number`),
  ADD KEY `idx_purchase_order` (`purchase_order_id`),
  ADD KEY `idx_po_number` (`po_number`),
  ADD KEY `idx_supplier` (`supplier_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_receiving_date` (`receiving_date`),
  ADD KEY `idx_received_by` (`received_by`);

--
-- Indexes for table `proof_of_receiving_items`
--
ALTER TABLE `proof_of_receiving_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_por_id` (`por_id`),
  ADD KEY `idx_product_id` (`product_id`),
  ADD KEY `idx_sku` (`sku`),
  ADD KEY `idx_batch_number` (`batch_number`),
  ADD KEY `idx_expiration` (`expiration_date`);

--
-- Indexes for table `purchase_orders`
--
ALTER TABLE `purchase_orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `receivings`
--
ALTER TABLE `receivings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `security_logs`
--
ALTER TABLE `security_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_event_type` (`event_type`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `stock_adjustments`
--
ALTER TABLE `stock_adjustments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `stock_transfers`
--
ALTER TABLE `stock_transfers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `stock_transfer_audit`
--
ALTER TABLE `stock_transfer_audit`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_transfer_id` (`transfer_id`),
  ADD KEY `idx_action_type` (`action_type`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `transfer_proof`
--
ALTER TABLE `transfer_proof`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `proof_number` (`proof_number`),
  ADD KEY `idx_proof_number` (`proof_number`),
  ADD KEY `idx_transfer_id` (`transfer_id`),
  ADD KEY `idx_transfer_number` (`transfer_number`),
  ADD KEY `idx_source_location` (`source_location_id`),
  ADD KEY `idx_destination_location` (`destination_location_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_transfer_date` (`transfer_date`);

--
-- Indexes for table `transfer_proof_items`
--
ALTER TABLE `transfer_proof_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_proof_id` (`proof_id`),
  ADD KEY `idx_product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_username` (`username`),
  ADD KEY `idx_role` (`role`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `security_logs`
--
ALTER TABLE `security_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=985;

--
-- AUTO_INCREMENT for table `stock_transfer_audit`
--
ALTER TABLE `stock_transfer_audit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `otp_codes`
--
ALTER TABLE `otp_codes`
  ADD CONSTRAINT `fk_otp_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `proof_of_receiving`
--
ALTER TABLE `proof_of_receiving`
  ADD CONSTRAINT `fk_por_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `proof_of_receiving_items`
--
ALTER TABLE `proof_of_receiving_items`
  ADD CONSTRAINT `proof_of_receiving_items_ibfk_1` FOREIGN KEY (`por_id`) REFERENCES `proof_of_receiving` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `transfer_proof_items`
--
ALTER TABLE `transfer_proof_items`
  ADD CONSTRAINT `transfer_proof_items_ibfk_1` FOREIGN KEY (`proof_id`) REFERENCES `transfer_proof` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
