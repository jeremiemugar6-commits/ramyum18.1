<?php
/**
 * Test POR API Call
 * Simulate actual AJAX call to find real error
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/database.php';
require_once 'includes/functions.php';

$db = getDB();

echo "POR API CALL TEST\n";
echo str_repeat("=", 80) . "\n\n";

// Find a receiving record that doesn't have a POR yet
echo "1. Finding receivings WITHOUT existing POR...\n";
echo str_repeat("-", 80) . "\n";

$stmt = $db->query("
    SELECT r.id, r.data
    FROM receivings r
    LEFT JOIN proof_of_receiving por ON r.id = por.receiving_id
    WHERE por.id IS NULL
    LIMIT 1
");

$receiving = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$receiving) {
    echo "⚠ All receivings already have PORs!\n";
    echo "\nLet's check existing PORs:\n";
    $stmt = $db->query("
        SELECT por.id, por.por_number, por.receiving_id, r.data
        FROM proof_of_receiving por
        LEFT JOIN receivings r ON por.receiving_id = r.id
        LIMIT 5
    ");
    $pors = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($pors as $por) {
        $rData = json_decode($por['data'] ?? '{}', true);
        echo "  POR: {$por['por_number']} → Receiving: {$por['receiving_id']}\n";
    }
    
    echo "\n\nTrying to create POR for an existing receiving to see the actual error...\n";
    $receiving = ['id' => 'demo_gr_001'];
} else {
    echo "✓ Found receiving without POR: {$receiving['id']}\n";
}

// Simulate the API call
echo "\n2. SIMULATING API CALL...\n";
echo str_repeat("-", 80) . "\n";

// Create a test user
$currentUser = [
    'id' => 'admin',
    'name' => 'System Admin',
    'role' => 'admin'
];

// Simulate POST request
$input = [
    'receiving_id' => $receiving['id']
];

echo "Request:\n";
echo "  Action: create-from-receiving\n";
echo "  Receiving ID: {$input['receiving_id']}\n";
echo "  User: {$currentUser['name']} ({$currentUser['role']})\n";

echo "\n3. EXECUTING CREATE LOGIC...\n";
echo str_repeat("-", 80) . "\n";

try {
    // Get receiving data
    $stmt = $db->prepare("SELECT data FROM receivings WHERE id = ?");
    $stmt->execute([$input['receiving_id']]);
    $result = $stmt->fetch();
    
    if (!$result) {
        throw new Exception("Receiving record not found: {$input['receiving_id']}");
    }
    
    $receivingData = json_decode($result['data'], true);
    echo "✓ Receiving data loaded\n";
    echo "  PO: {$receivingData['poNumber']}\n";
    echo "  Supplier: {$receivingData['supplier']}\n";
    echo "  Items: " . count($receivingData['items'] ?? []) . "\n";
    
    // Check if POR already exists
    $checkStmt = $db->prepare("SELECT id, por_number FROM proof_of_receiving WHERE receiving_id = ?");
    $checkStmt->execute([$input['receiving_id']]);
    $existingPOR = $checkStmt->fetch();
    
    if ($existingPOR) {
        throw new Exception("POR already exists for this receiving record: {$existingPOR['por_number']}");
    }
    
    echo "✓ No existing POR found\n";
    
    // Start transaction
    $db->beginTransaction();
    echo "✓ Transaction started\n";
    
    // Generate POR number
    $stmt = $db->query("SELECT COUNT(*) as count FROM proof_of_receiving");
    $count = $stmt->fetch()['count'];
    $porNumber = 'POR-' . date('Y') . '-' . str_pad($count + 1, 4, '0', STR_PAD_LEFT);
    echo "✓ POR Number generated: $porNumber\n";
    
    $porId = generate_id('por');
    echo "✓ POR ID generated: $porId\n";
    
    // Calculate totals
    $totals = [
        'ordered' => 0,
        'received' => 0,
        'accepted' => 0,
        'rejected' => 0,
        'value' => 0
    ];
    
    foreach ($receivingData['items'] ?? [] as $item) {
        $ordered = floatval($item['orderedQuantity'] ?? $item['quantity'] ?? 0);
        $received = floatval($item['quantityReceived'] ?? $item['quantityDelivered'] ?? $received ?? 0);
        $accepted = floatval($item['quantityAccepted'] ?? $item['accepted'] ?? $received ?? 0);
        $rejected = floatval($item['quantityRejected'] ?? 0);
        $unitCost = floatval($item['unitCost'] ?? 0);
        
        $totals['ordered'] += $ordered;
        $totals['received'] += $received;
        $totals['accepted'] += $accepted;
        $totals['rejected'] += $rejected;
        $totals['value'] += $accepted * $unitCost;
    }
    
    echo "✓ Totals calculated:\n";
    echo "    Ordered: {$totals['ordered']}\n";
    echo "    Received: {$totals['received']}\n";
    echo "    Accepted: {$totals['accepted']}\n";
    echo "    Value: ₱" . number_format($totals['value'], 2) . "\n";
    
    // Insert POR
    $stmt = $db->prepare("
        INSERT INTO proof_of_receiving (
            id, por_number, purchase_order_id, po_number, receiving_id,
            supplier_id, supplier_name, received_by, received_by_name,
            receiving_date, receiving_time, inspection_status, status,
            total_items, total_ordered, total_received, total_accepted, total_rejected,
            total_value, remarks, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
    ");
    
    $receivingDate = $receivingData['receivedDate'] ?? date('Y-m-d H:i:s');
    
    $params = [
        $porId,
        $porNumber,
        $receivingData['poId'],
        $receivingData['poNumber'],
        $input['receiving_id'],
        $receivingData['supplierId'],
        $receivingData['supplier'],
        $currentUser['id'],
        $currentUser['name'],
        $receivingDate,
        date('H:i:s', strtotime($receivingDate)),
        'Pending',
        'Draft',
        count($receivingData['items'] ?? []),
        $totals['ordered'],
        $totals['received'],
        $totals['accepted'],
        $totals['rejected'],
        $totals['value'],
        $receivingData['notes'] ?? null
    ];
    
    $stmt->execute($params);
    echo "✓ POR record inserted\n";
    
    // Insert items
    $itemStmt = $db->prepare("
        INSERT INTO proof_of_receiving_items (
            id, por_id, product_id, product_name, sku, unit,
            ordered_quantity, received_quantity, accepted_quantity, rejected_quantity,
            damaged_quantity, unit_cost, total_cost,
            inspection_result, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
    ");
    
    $itemCount = 0;
    foreach ($receivingData['items'] ?? [] as $item) {
        $itemId = generate_id('por_item');
        $ordered = floatval($item['orderedQuantity'] ?? $item['quantity'] ?? 0);
        $received = floatval($item['quantityReceived'] ?? $item['quantityDelivered'] ?? $received ?? 0);
        $accepted = floatval($item['quantityAccepted'] ?? $item['accepted'] ?? $received ?? 0);
        $rejected = floatval($item['quantityRejected'] ?? 0);
        $damaged = floatval($item['quantityDamaged'] ?? 0);
        $unitCost = floatval($item['unitCost'] ?? 0);
        
        $itemStmt->execute([
            $itemId,
            $porId,
            $item['productId'],
            $item['productName'],
            $item['sku'] ?? null,
            $item['unit'] ?? 'pcs',
            $ordered,
            $received,
            $accepted,
            $rejected,
            $damaged,
            $unitCost,
            $accepted * $unitCost,
            'Pending'
        ]);
        $itemCount++;
    }
    
    echo "✓ $itemCount POR items inserted\n";
    
    // Commit
    $db->commit();
    echo "✓ Transaction committed\n";
    
    echo "\n✓✓✓ SUCCESS! ✓✓✓\n";
    echo "\nPOR Created:\n";
    echo "  POR ID: $porId\n";
    echo "  POR Number: $porNumber\n";
    echo "  Receiving: {$input['receiving_id']}\n";
    echo "  Items: $itemCount\n";
    
} catch (Exception $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
        echo "✗ Transaction rolled back\n";
    }
    echo "\n✗✗✗ ERROR! ✗✗✗\n";
    echo "Message: " . $e->getMessage() . "\n";
    echo "Code: " . $e->getCode() . "\n";
    echo "File: " . $e->getFile() . ":" . $e->getLine() . "\n";
    
    if ($e instanceof PDOException) {
        echo "\nPDO Error Info:\n";
        echo "  SQL State: " . $e->errorInfo[0] . "\n";
        echo "  Error Code: " . $e->errorInfo[1] . "\n";
        echo "  Error Message: " . $e->errorInfo[2] . "\n";
    }
}

echo "\n" . str_repeat("=", 80) . "\n";
