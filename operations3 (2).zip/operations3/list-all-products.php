<?php
require_once 'config/database.php';

$db = getDB();

$prods = $db->query('SELECT id, data FROM products ORDER BY id')->fetchAll();

echo "TOTAL PRODUCTS: " . count($prods) . "\n\n";

foreach($prods as $p) {
    $d = json_decode($p['data'], true);
    echo sprintf("%-10s %-40s %-10s Stock: %d\n", 
        $p['id'], 
        $d['name'], 
        'SKU: ' . $d['sku'],
        $d['stock'] ?? 0
    );
}
