/**
 * DataService — PHP + MySQL backed version.
 *
 * This preserves the exact same interface the app's modules were
 * originally written against (findAll / findById / create / update /
 * delete against a named "collection"), so dashboard.js, inventory.js,
 * catalog.js, purchase-orders.js, receiving.js, reports.js,
 * stock-transfer.js, and suppliers.js all work unchanged.
 *
 * Instead of reading/writing localStorage, every call now goes through
 * api/data.php, which persists records as real rows in MySQL.
 */
export class DataService {
    constructor() {
        this.baseUrl = 'api/data.php';
    }

    async _handle(response) {
        let body;
        try {
            body = await response.json();
        } catch (e) {
            throw new Error('Unexpected server response.');
        }
        if (!response.ok || !body.success) {
            throw new Error(body.error || 'Request failed.');
        }
        return body.data;
    }

    async findAll(collection) {
        const res = await fetch(`${this.baseUrl}?collection=${encodeURIComponent(collection)}`);
        return this._handle(res);
    }

    async findById(collection, id) {
        const res = await fetch(`${this.baseUrl}?collection=${encodeURIComponent(collection)}&id=${encodeURIComponent(id)}`);
        return this._handle(res);
    }

    async create(collection, data) {
        const res = await fetch(`${this.baseUrl}?collection=${encodeURIComponent(collection)}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        return this._handle(res);
    }

    async update(collection, id, data) {
        const res = await fetch(`${this.baseUrl}?collection=${encodeURIComponent(collection)}&id=${encodeURIComponent(id)}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        return this._handle(res);
    }

    async delete(collection, id) {
        const res = await fetch(`${this.baseUrl}?collection=${encodeURIComponent(collection)}&id=${encodeURIComponent(id)}`, {
            method: 'DELETE'
        });
        return this._handle(res);
    }
}
